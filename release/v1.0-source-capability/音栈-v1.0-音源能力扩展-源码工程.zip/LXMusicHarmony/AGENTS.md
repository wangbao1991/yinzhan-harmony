# AGENTS.md · 音栈工程规则（接手必读）

> 本文件供 AI 工具自动读取。**完整上下文见交接包 `音栈-交接包/01-项目交接说明.md`**；
> 若本文件与源码冲突，以源码与 `AppScope/app.json5` 为准。

## 项目

「音栈」：HarmonyOS 原生音乐聚合播放器，ArkTS / ArkUI，API 26 (26.0.0) / OpenHarmony 7.0 SDK，Stage 模型，**零三方依赖、命令行离线构建**。
工作副本 `LXMusicHarmony/`，包名 `com.yinzhan.music`。

---

## ⚠️ 最新事实（2026-11-12，**优先于以下全部历史记录**）

下面「当前状态」及后续各版记录形成于 2026-11-09 ~ 11-10，**不包含其后三轮改动**。读历史段落时请以本节为准：

### 🔴 2026-11-13 增补（接手必读，覆盖本轮第 1 / 3 / 6 点）

上块写于 2026-11-12，之后的「账号栏置顶」与「实时同步修正（注释批次 v2.67）」两轮已落地，以下为最新真实状态：

- **A. 自检现状**：已是 **67 项（PASS 65 / WARN 2 / FAIL 0）**，不是 62 项。新增 `check_fav_sync_real`（BP 组，见 `scripts/selfcheck.py`）锁死「状态不撒谎 + 前台定时对账 + 酷狗受限项剥离」。两条 WARN 仍是 `themeMode` / `activeSourceName` 的历史冗余广播，**不要修**。
- **B. 歌单↔账号同步已被重写**（原第 3 点「五处触发 + pending 重放 + 状态看云端是否拉到」已作废）。当前是「真实双向对齐状态机」：
  - `ok` 收紧为「云端读成功 **且** 待写队列真清空」，否则降级 `partial` 且**不刷时间戳**；启动首帧不继承旧 `ok`。
  - 统一聚合 `FavSyncStatus`（`core/FavSyncHub.ets` 的 `status(scope)` / `label(scope)` / `toastText(scope)`，scope 取 `'all' | 'wy' | 'qq' | 'kg'`），三处 UI（收藏页 / 网易云页 / QQ·酷狗面板）消费同一结论。`clean` 严格到「有登录 + 无在途 + 无失败 + 每已登录平台都 ok + 队列空 + 有过成功同步」才允许说「已与账号同步 HH:mm」——**clean 时队列必空，绝不再出现"已同步"拖"待上传"**。
  - 前台 **12 秒定时对账**：`EntryAbility.onForeground` 启、`onBackground`/`onDestroy` 停；叠加「进页 / 回前台 / 登录 / 本地变更即时写云端并回读确认 / 手动点状态条」触发。
  - 酷狗「取消收藏」官方需 RSA+AES，纯客户端写不了 → 该项标 `manual` **剥离出待上传队列**，如实提示「N 项需在酷狗 APP 内取消」；用户去 APP 端处理后回读确认自动出队。
  - toast 等三平台 `reconcileAllAwait()` 跑完再报，只要还有未同步/失败绝不弹「已一致」。
  - 不变红线：失败 / 风控 / 空列表 / Cookie 失效一律**不动本地**；云端回写不触发 hook（防死循环）。
- **C. 路由表现状**：`Index.ets` pageMap **12 个**（比上块多 `discoverSection`，来自「板块更多全量页」那轮）；一级 Tab 仍 3（首页 / 发现 / 设置），**无「我的」一级页**（MinePage / MyAccountPage 已删）。`check_tab_routes` 精确匹配，加路由会 FAIL。
- **D. 账号栏位置**：设置页**顶部第一组**即为账号栏，单行 `push('wyAccount', …)` 直达二级页；`WyAccountPage` 内三 Tab（网易云 / QQ 音乐 / 酷狗）切 `PlatformAccountPanel`。
- **E. 版本**：仍是 `versionCode 67 / versionName 2.56`（沿用基线应用版本，构建脚本有硬编码断言），注释批次 v2.67；**基线仍是 v2.48（59 / 2.48）不动**，`build_release.sh` 的 `[0/5]` 每轮复核其 SHA256。
- **F. 已知 P0 仍未修**：扫码登录——QQ 二维码能出、轮询报「网络异常」；酷狗取不到二维码。根因与实测见 `docs/` 与历史交付的待办文档。**这是下一个要做的头等事**。
- **G. 实时边界（务必告知下一个 AI）**：第三方 App 收不到网易云/QQ/酷狗**服务端推送**，纯客户端做不到官方 APP 那种推送级实时。本版是客户端上限：本地操作即时写云端并回读确认 + 前台 12s 周期对账 + 五既有触发点。酷狗云端取消收藏受官方加密限制，按「需 APP 端处理」如实降级，绝不假装成功。

1. **静态自检已是 62 项**（PASS 60 / WARN 2 / FAIL 0），不是文中反复出现的 51 / 55 / 59 / 61 项。
   两条 WARN 固定为 `themeMode`、`activeSourceName` 的「只写没人读」，**不要修**。
   末尾新增的 `check_qq_kg_fav_sync`（BK 组）锁定三平台账号与同步链路。
2. **新增网易云本人账号**（`core/WyApi.ets` / `WyAccount.ets` / `WyRecommend.ets`）：
   weapi 双 AES-128-CBC 原生加密（`cryptoFramework`，无三方库），二维码 + Cookie 两路登录，
   本人账号「每日推荐 / 我的歌单 / 我喜欢」。
3. **新增「歌单收藏 ↔ 账号」双向同步**，三平台各自独立引擎：
   - `core/WyFavSync.ets`（wy，2026-11-11 上线，BJ 组断言锁定，**不要改这个文件**）
   - `core/FavSyncHub.ets`（QQ / 酷狗，内含通用 `FavSyncEngine`，`platform: 'qq' | 'kg'`）
   - 共同不变量：失败 / 风控 / 空列表 / Cookie 失效一律**不动本地**；本地乐观更新 + pending 队列重放；
     首次只补不删；按纯数字 id 对账去重；云端回写不触发 hook（防死循环）；
     进收藏页 / 回前台 / 登录成功 / 退出 / 手动点状态条 五处触发。
4. **新增 QQ 音乐、酷狗账号**（`core/QqApi.ets` / `QqAccount.ets` / `KgApi.ets` / `KgAccount.ets`，
   共用 `core/AccountCrypto.ets` 的 MD5 / Cookie / 签名 / 请求工具）。
   - 平台隔离：`wy` 只动网易云歌单、`tx` 只动 QQ、`kg` 只动酷狗；`Library.syncPlatform()` 判定。
   - 酷狗「云端取消收藏」需官方 RSA+AES，纯客户端**如实降级**：返回失败、留 pending、UI 提示去 APP 内确认。
   - 账号凭证（`v4_wy_*` / `v4_qq_*` / `v4_kg_*`）与同步中间态（`*_FAV_PENDING/CLOUD/INIT/AT`）
     **一律不进 `core/Backup.ets` 白名单**，避免备份恢复串账号。这条不要"补齐"。
5. **设置页入口改名「账号与同步」**，仍 `push('wyAccount', …)`；`WyAccountPage` 内用三 Tab
   （网易云 / QQ 音乐 / 酷狗）切 `PlatformAccountPanel`，**未新增任何路由**，
   `Index.ets` 的 `pageMap` 仍是 11 个名字（`check_tab_routes` 精确匹配，加路由会 FAIL）。

   > **v2.71 更新（用户决定，覆盖上面第 5 条的界面部分）**：QQ / 酷狗歌单同步在客户端
   > 写不通，账号页收口为**仅网易云** —— 去掉三 Tab 与两个 `PlatformAccountPanel` 入口，
   > 设置页入口标题改回「网易云账号」、摘要只反映网易云登录态。`core/` 下的 QQ / 酷狗
   > 账号与同步代码、已收藏的 `tx` / `kg` 歌单一律保留不动（不删用户数据、不降质），
   > 路由表仍不新增。`WyRecommendHub` 成为推荐数据唯一数据源，首页与账号页订阅同一份
   > `wyRecVersion` 实时快照（v2.71 当时）首页只显示前 5 首与最多 8 张推荐歌单卡。

   > **v2.72 更新（用户决定，覆盖上面 v2.71 的展示部分，以本条口径为准）**：
   > ① 首页「每日推荐」由纵向前 5 首改成**横向轨**，铺满完整 30 首（`WyRecommendSection`
   > 去掉 `limit`，`ForEach(this.songList)` 全量 + 水平 `Scroll`），与「为你推荐歌单」两条横向轨并列；
   > ② 网易云账号页的「每日推荐 / 推荐歌单 / 我的歌单」三块**整体隐藏**，本页只留账号头与
   > 歌单收藏同步卡，登录成功后仍预热 `WyRecommendHub` 供首页用，底层 `WyRecommend` 接口不删；
   > ③ 首页四宫格第四格由「下载管理」换成「歌单收藏」（与其余三格同为方块图标），下载改到
   > 顶栏问候语右侧小图标（图 2 标记处），仍走 `downloads` 路由，不新增路由；
   > ④ 「导入歌单」从首页并排方卡**整套搬到「歌单收藏」二级页标题栏右上角**（图 3 标记处），
   > 通过 `Common.PageBar` / `ImmersiveBar` 新增的默认关闭 `showTrailing` 参数承载，只有收藏页
   > 打开，其它二级页顶栏一字不改。导入链路（解析 / 加收藏 / 打开详情）逐字保留。
   > 自检新增 BT 组锁死以上四项；`AC/AD/AM/AZ/BI/BS` 相关旧断言按新口径同步更新。

   > **v2.73 更新（用户纠正上一轮口径，以本条为准）**：
   > ① 首页每日推荐不是「每首一张小卡连续横滑」，而是**「5 个一排、可以滑动」**——
   > 改成 `Swiper` 分页轨：一页一整块 5 首纵向列表（序号 / 封面 / 歌名·歌手 / 时长），
   > 30 首按 `REC_PAGE_SIZE = 5` 切成 6 组，左右滑按组翻页，下方显示「第 N / M 组 · 共 30 首」；
   > 点播仍传全量 `songList` + 全局下标 `page * 5 + row`，翻到任意组都从正确那首开始；
   > ② 网易云账号登录后**显示本人头像**：`account/get` 的 `profile.avatarUrl` 在 `adopt()`
   > 落盘 `WY_AVATAR`，账号页读出、升 https、圆形裁切，加载失败回退人形占位，退出登录清除；
   > ③ 网易云账号二级页**恢复「我的歌单」**，单独走 `WyRecommend.mySheets()`
   > （`/weapi/user/playlist` 真实数据）横向展示，页面销毁丢弃异步结果、退出清残留；
   > 每日推荐与推荐歌单仍只在首页，账号页不订阅 `wyRecVersion`、不复制首页推荐。
   > 自检新增 BU 组锁死三项；`BI/BS/BT` 三组旧断言按本口径同步校正（分页轨不再要求
   > 两条水平 Scroll，`mySheetRail` / `GlassSheetCard` 重新成为账号页合法实现）。

   > **v2.74 更新（用户三项诉求）**：
   > ① 搜索页「大家都在搜」原是 `Constants.HOT_WORDS` 写死常量，故几天不变 —— 删除该常量，
   > 新增 `core/HotSearch.ets` 拉网易云官方 `GET /api/search/hot?type=1&limit=10`（实测可用，
   > `type=1` 必带；旧 `/api/search/hot/web`、`/api/hotsearch/get` 已 404），解析
   > `result.hots[].first` 去重取前 10；10 分钟 TTL + 在途锁 +「刷新」+「更新于 HH:mm」；
   > 失败只给可重试提示、保留上次成功数据，**绝不用写死词顶上（不造数）**；
   > ② 长歌名跑马灯 `marqueeOptions.step` 由 4 降到 2（约减半），SongRow / 队列弹层 /
   > 迷你条 / 下载任务行共 7 处统一；
   > ③ 青绿液态玻璃做成**第二套可切换主题**：参数依据 `docs/音栈-液态玻璃整页-预览.html`
   > 与本文件 v2.51 段记录的旧描边真值，全部收在 `Constants.ets` 末尾 `liquid*` 配方；
   > `glass* / palette / lightSense` 按 `glassTheme()` 分发，**纸墨默认分支一字未改**；
   > `PrefKeys.GLASS_THEME` 落盘 + `AppStorage('glassTheme')` 广播 + `App.init` 首帧恢复，
   > 所有订阅 `isDark` 的组件同步订阅 `glassTheme` 才能即时重绘；外观页「风格」两档 Chip。
   > 青绿主题保留信号琥珀主色（旧版品牌蓝会让 onSignal 墨字对比度掉到 2.3:1）。
   > 自检 BE 组加速度断言、新增 BV 组锁死三项；AC/AI/AJ 的 v2.52 墨栈守断言继续成立
   > （青绿色值用 ARGB 十六进制、只在 Constants.ets，未碰纸墨主色与中性实色分支）。
   >
   > **v2.75 更新（修正上条「订阅即重绘」的误判）**：用户实测「切换界面风格时只有重启
   > 才全部界面生效」。根因：v2.74 批量加的 44 处 `@StorageProp('glassTheme')` 全是
   > **哑订阅** —— 除外观页外，`build()` 里一次都没读 `this.glassTheme`，ArkUI 不建立 UI
   > 依赖；且 `Constants.palette/glass*` 读的是模块级普通变量 `activeGlassTheme`，
   > 框架更无从追踪（`PlayerPage` 里 `coverUrl` 的注释早写过同一类坑：普通函数调
   > 用不是响应式依赖）。于是切换时只有外观页自己重绘，其余页面保持旧配色，冷启动
   > 首帧 `App.init` 设好模块变量后才全量生效。
   > 修法沿用工程里 `coverVersion @Watch('onCoverVersion')` 的既有有效模式：44 处订阅
   > 全部挂 `@Watch('onGlassTheme')`，每个 struct 加自有 `@State glassTick`，回调里
   > `this.glassTick += 1` 强制 `build()` 重跑，重跑时取色函数重新读 `setGlassTheme`
   > 已更新的主题；inactive 页面返回时同样重绘。**430 处取色调用点与 Constants 函数
   > 签名一字未改**，因此 30+ 处调用形态断言与 v2.52 墨栈守断言零冲击。
   > 自检新增 BW 组锁死「订阅 / Watch / tick / 回调 / 落盘 / 广播 / 首帧恢复」全链路。
   > 教训：**`@StorageProp` 只声明不读等于没订阅**。
   >
   > **v2.76 更新（v2.75 仍不完整，用户实测分层生效）**：反馈「只有底栏立即生效、
   > 播控页点击后才生效、其他页面只有重启才生效」。根因比哑订阅更深一层：
   > v2.75 的 `@Watch + @State glassTick` 里，`glassTick` 从没在 `build()` 被读取，
   > ArkUI 不为未读取的状态变量注册 UI 依赖 —— 只有常驻 active 的底栏、以及被
   > 别的操作顺带重绘的播控页会刷新；一级页是 `Swiper` 常驻实例，切主题时被外观
   > 二级页盖住，返回后实例和参数都没变，`build()` 不重跑，于是「要重启才全量生效」。
   > 更根本的是 `this.glassTheme` 从没出现在任何 `build()` 表达式里：取色函数读的是
   > `Constants` 模块级普通变量 `activeGlassTheme`，不是组件状态。
   > 修法：**把 `this.glassTheme` 作为末位实参传进 10 个取色函数**（`palette` /
   > `glassCardBase` / `glassSurface` / `glassFill` / `glassDepth` / `glassEdgeWidth` /
   > `glassEdgeColor` / `glassShadow` / `glassRowShadow` / `lightSense`），函数签名加
   > `theme?: number`，函数体 `const t = theme === undefined ? glassTheme() : theme;`
   > 优先用传入值。共 **436 处调用**把主题值写进 `.backgroundColor(...)` 等 UI 属性
   > 表达式，43/43 个取色组件全覆盖（含只走 `p()` 辅助方法的 11 个 —— 深浅色切换
   > 本就靠 `p()` 里的 `this.isDark` 即时生效，证明普通方法链同样登记依赖）。
   > 这样 active 页切换即重绘、inactive 一级页返回时用最新值重绘，`p()` 里也带
   > `this.glassTheme` 双保险；v2.75 的 Watch / 落盘 / 广播 / 首帧恢复链路保留。
   > 自检：`load()` 增加 `strip_theme_arg()` 归一化视图，让 v2.75 及更早那 30+ 处
   > 「有没有铺玻璃四件套」的调用形态断言继续成立（它们只关心语义、不关心参数）；
   > 新增 **BX 组读磁盘原文 `load_raw()`** 严格锁死参数链，防止归一化掩盖回归。
   > BV / AC / BW 三组按新签名口径校正。教训：**换肤必须让状态值真正出现在
   > `build()` 的 UI 表达式里**；`@Watch` + 未被读取的 `@State` 救不了 inactive 页面。
   >
   > **v2.77 更新（设置页账号摘要）**：用户指设置页「网易云账号」右侧 `wang210207`
   > 像 bug。核查为网易云 `account/get` 返回的 `profile.nickname`（默认分配的用户名
   > 样式，非内部 ID / 非 Cookie 片段 / 非写死占位），显示链路本身正确。用户口径选
   > 「只显示已登录」：`SettingsPage.accountSummary()` 改返回固定
   > `'已登录' / '未登录'`，不再把昵称明文挂到列表摘要。`wyNick` 订阅、登录态判据、
   > `push('wyAccount')` 入口一字不动（登录/退出广播仍即时刷新本行）；真实昵称与
   > 头像继续由二级页展示。新增 **BY 组**锁死「摘要不含昵称明文 + 订阅链路完整 +
   > 二级页昵称/头像未被牵连删除」。一次只改一个主题，不新增路由、不造数据。
   >
   > **v2.78 更新（首页四宫格图标配色统一，注释批次）**：用户截图圈出首页四宫格的
   > 「我喜欢」「歌单收藏」两个心形，一个灰褐、一个琥珀金，不统一，要求都改成
   > 「本地音乐 / 最近播放」那种灰褐色。根因：`HomePage.ets` 的 `quickGrid()`
   > 里前三格 tint 均为 `#FF6F6960`（灰褐），唯独第四格「歌单收藏」单独用了
   > `#FFE29A26`（品牌琥珀），连图标带淡黄底方块一起染色。改动：**只把第四格 tint
   > 改回 `#FF6F6960`**，四格归一；两个 heart_fill、四个入口 / 标题 / 数字、
   > `Constants.ets` 的品牌琥珀主色（搜索按钮、底栏选中态仍用）一字未动。
   > 新增 **BZ 组**（`check_home_grid_tint_uniform`）锁死「四格 tint 全灰褐 +
   > HomePage 无琥珀色值 + 品牌主色保留 + 两心形图标仍在 + tint 驱动链路完整」。
   > 自检 **77 项 PASS 75 / WARN 2 / FAIL 0**。应用版本仍 `67 / 2.56` 不变。
   >
   > **v2.79 更新（首页四宫格图标线框统一，注释批次）——取代上条 v2.78 的图标部分**：
   > 用户装机后反馈「心形改的颜色有点深，对比最近播放和本地音乐的颜色深度，
   > 按它们的标准来做」。放大截图 + 像素采样核实：**四格 tint 其实完全相同**
   > （都是 `#FF6F6960`，四者最深色 (83,80,71)/(84,79,73) 几乎一致），显深是因为
   > 「我喜欢」「歌单收藏」用了**实心填充** `sys.symbol.heart_fill`（深色像素量
   > 3564/2839，约为线框 1599/1591 的 2 倍），而「最近播放 clock」「本地音乐 folder」
   > 是**细线描边**。用户在 A/B/C 里选了 **A「四格统一改线框」**。改动：仅把两处
   > `icon: $r('sys.symbol.heart_fill')` 换成 `$r('sys.symbol.heart')`（空心线框），
   > **tint / 入口 / 标题 / 数字 / 品牌主色全部不动**，注释里的 `heart_fill` 字面量
   > 也清掉（让"无实心残留"断言可严格检查）。BZ 组同步改为锁死「四格全线框描边 +
   > HomePage 无 heart_fill 残留 + 空心爱心 3 处（默认值 1 + 四宫格 2）+ 时钟/文件夹在」。
   > 自检 **77 项 PASS 75 / WARN 2 / FAIL 0**。**红线：勿把四宫格图标改回实心
   > heart_fill（会再次显深）；勿动 `#FF6F6960` 与 `Constants.ets` 品牌主色。**
   > `sys.symbol.heart`（线框）在工程里已多处使用（PlayerPage / Common / SongMenu 等），
   > 是已验证的合法资源。应用版本仍 `67 / 2.56` 不变。
   >
   > **v2.80 更新（青绿液态玻璃整套引擎连根删除，注释批次）**：用户看外观页反馈
   > 「青绿液态玻璃风格有点不搭，去除；下面红圈标记的两段说明文字也一并去掉」，
   > 并在 A/B 里选了 **B「连根删除整套引擎」**（不是只去 UI 入口）。这套风格是
   > v2.74~v2.76 三轮做出来的完整换肤引擎，**27 文件 / 429 处引用**：Constants 的
   > `glassTheme()/setGlassTheme()/activeGlassTheme`、`LIQUID_LIGHT/DARK` 色板、8 个
   > `liquid*` 配方、10 个取色函数的 `theme?: number` 参数与 `if(t===1)` 分发、
   > `PrefKeys.GLASS_THEME`、Settings 落盘+广播、App.init 首帧恢复、44 个组件的
   > `@StorageProp('glassTheme') @Watch('onGlassTheme')` + `@State glassTick` 重绘锚、
   > 436 处 `, this.glassTheme)` 取色实参、外观页「风格」两档 Chip。**全部删除**，
   > 取色函数签名精简为只按 `isDark` 返回纸墨实色（纸墨实现一字未改）。界面固定纸墨。
   > 外观页「主题」分组只剩「模式」三档（跟随系统/浅色/深色），两段说明文字删除；
   > **v2.56 的 lightNotice 光感迁移提示条是独立功能，保留不误删**（AC 组仍锁）。
   > 自检改造：`strip_theme_arg()` 退化为恒等（源码已无主题实参，旧断言零冲击）；
   > **整组删除 BW(v2.75)/BX(v2.76)** 两组强制双主题的断言、BV 只留①②热搜/跑马灯；
   > 新增 **CA 组**（`check_glass_theme_removed`，读磁盘原文）锁死「引擎符号零残留 +
   > 纸墨取色链路完整 + 风格行/说明已删 + 模式三档在 + lightNotice 保留 + 品牌主色在」。
   > 自检 **76 项 PASS 74 / WARN 2 / FAIL 0**（比 v2.79 少 1 项：净删 2 组加 1 组）。
   > **红线：勿再引入第二套主题 / glassTheme / 青绿配方 / 风格切换 Chip；界面固定纸墨，
   > 深浅色「模式」是唯一的主题维度。** 应用版本仍 `67 / 2.56` 不变。
6. **已知未修问题：扫码登录**。QQ 二维码能出、轮询报「网络异常」；酷狗取不到二维码。
   根因与实测证据见交接包 `02-待办与已知问题.md` 的 P0 段。**这是下一个要做的头等事。**

---

## 当前状态（v2.56 / versionCode 67）（历史记录，2026-11-09 起）

- v2.4 起**整套统计展示层已拆除**：首页「音栈·驿站」看板、月·回响报告卡与二级页、设置页「统计」分组。
- **刻意保留** `core/PlayStats.ets`、播放器三处埋点与 400 天真实收听数据，只是不进任何界面。
- 设置页 7 组：音源 / 播放 / 外观 / 歌词 / 发现 / 数据 / 关于（「数据」组是 v2.22 加的备份 / 恢复入口）。
- 自检 `python3 scripts/selfcheck.py .` → 51 项 PASS 49 / WARN 2 / FAIL 0（**2 项 WARN 不要修**）。
- **正式基线 v2.48（59 / 2.48）**，2026-11-09 按用户决定由 v2.39 切换：**v2.39（50 / 2.39）及更早的所有基线约定全部作废**，不再复核、不再保护；旧三副本（HAP / 源码快照 / 图解）与根目录的 v2.39 可构建源码包已移入 `archive/baseline/legacy/v2.39/`（只作回溯，不当基线用）。
  - 基线副本固定在工程内 `archive/baseline/`，不受根目录「只留最新 1 个 HAP」规则约束：
    - `音栈-v2.48-基线.hap` — SHA256 `b8b7e7b125da2a2e430c7704579689424b308a6747a2ed2fac0d9a6c71e52741`（3,729,852 字节）
    - `LXMusicHarmony-v2.48-基线源码快照.zip`（= 交付给用户的「可构建源码工程包」同一份，约 7.3 MB / 顶层目录 `LXMusicHarmony/` / **不含任何证书密钥材料**）— SHA256 见 `archive/baseline/SHA256SUMS`。**不在本文件写死该哈希**：源码包内含本文件，写死会自指（改一次记录→包变→哈希变），故哈希单独落在不随包分发的 `SHA256SUMS`。
    - `音栈-v2.48-基线-图解.html` — SHA256 `1d896f33ba7bda76e793cef9f55bbad90ab549d4ca1ac8bd6cb31c2392a0732c`（顶部带「正式基线 · v2.48」标识条）
  - 三份**禁止移动/删除/覆盖**；`scripts/env/build_release.sh` 的 `[0/5]` 每轮出包前 `sha256sum` 复核基线 HAP 哈希，不一致即中止构建。基线段路径 / 哈希写死在脚本里，改基线必须同时改三处（脚本 + 本文件 + 基线目录），不允许「改脚本哈希迁就文件」。
- **v2.54 搜索可达与诊断闭环（65 / 2.54）**：`音栈-v2.54-搜索可达与诊断闭环.hap`（65 / 2.54），SHA256 `cf323e1a427557e21eb810c7e14f6ec8c06f7e6176bdd890d7ea79d11fde2e06`（2,971,944 字节）；**基线仍是 v2.48（59 / 2.48）不动**，本轮未切基线、未重打源码包。本轮做交互方案包 2「导航与诊断闭环」，三件事都属「功能早就在、用户走不到」：①**搜索从二级页变成全局动作** —— `PageBar` 增默认关闭的 `showSearch`/`onSearch`，`ImmersiveBar` 透传，榜单 / 歌手 / 歌单详情三页顶栏接放大镜，发现页因是一级 Tab、没有顶栏，入口落在「排行榜 / 推荐歌单」分段行右侧；**路由表 7 个名字一个未加**，仍走既有 `openSearch()`。②**失败现场直达诊断** —— 播放失败面板底部加一行「查看音源状态」→ `App.openSources()`，补掉 v2.46「自检、刷新都显示正常，为什么就是播不出来」那条断链。③**来源与失败都显式** —— `Player` 增 `sourceKind`（`normal`/`local`/`substitute`/`manual`/`switch`）+ `getSourceKind()`，替补 / 换源时播放页来源行左侧出现 2vp 琥珀竖线；`SearchPage` 把 `searchSongsBySource` 内部的 `.catch(() => [])` 拆掉，三个 tab 各自记名失败源并给一条「N 个源本次没返回结果」的可展开提示；空态 / 失败态文案统一成「发生了什么 / 影响什么 / 下一步做什么」三段式，空态页那段约 120 字的「小提示」默认只留「怎么选源」，取链与替补细节收到「展开」后面。`Resolver.ets` / `Constants.ets` / `SourceRepo.ets` / `Library.ets` / `PlayerCard.ets` 零改动；包 3–5 当时未开始（包 3 已在 v2.55 落地）。根目录只留最新一组：v2.54 HAP + 图解 + `音栈-v2.48-可构建源码工程.zip`；v2.53 HAP / 图解与旧签名副产物分别入 `archive/hap/`、`archive/diagrams/`、`archive/signing-artifacts/`。
- **v2.55 返回与选择统一（66 / 2.55）**：`音栈-v2.55-返回与选择统一.hap`（66 / 2.55），SHA256 `8e39755a9400d3e871bc39f15fd08a74a3b1af9d4c587a655e15a1b606882a08`（2,972,623 字节）；**基线仍是 v2.48（59 / 2.48）不动**，本轮未切基线、未重打源码包。本轮做交互方案包 3「返回与选择统一」，落三件事：①**返回优先级只在 App 定义一次** —— 新增 `App.consumeBack(local)`，顺序固定「页内临时态 → 根级浮层」，原 `consumeBackIfQueueOpen()` 原样保留、降为其中一段；`App.back(local = null)` 同源（被临时态消费时不 pop）。音源管理 / 歌单收藏 / 歌单详情三页删掉各自 `if (selectMode) { exitSelect(); return true; }`，改为 `localBack(): boolean` + `.onBackPressed(() => App.get().consumeBack((): boolean => this.localBack()))`，顶栏箭头同参数。**歌手页不并入**：它的「专辑内 → 专辑列表 → 作品列表」是页内视图层级，v2.34 定的「先收可见浮层、再退视图层级」顺序保留（播放页全屏盖住时先退视图用户看不出变化）。②**选择条收成 `Common.SelectionBar`** —— 上排「取消 / 已选 N / M / 全选（取消全选）」、下排「[次要动作] + 删除所选」，`selectedCount <= 0 || busy || disabled` 统一禁用并压 0.45，四件套与 v2.50 布局照旧；音源页传 `secondaryLabel: this.exporting ? '导出中…' : '导出所选'` + `busy: this.removing`，收藏页无次要动作；**歌单详情页的选择条从头部卡片挪到列表下方**（原来跟着列表滚走），头部胶囊改成「选择」且进入后收起（原来写「完成」，三页两种说法）。③**下载页死代码清零** —— 「选择」入口早已移除，但 `selectMode` / `selectedIds` / `toggleSelect` / `toggleSelectAll` / `confirmDeleteSelected` 与勾选圈、工具栏全选/删除一整段仍留着，按方案推荐做法整段删除；左滑单条删除（`downloads.remove`）、行尾播放/重试/取消、「清除 / 清空失败」全部保留；`Downloader.removeMany()` 留在仓库层未被调用（恢复入口即可复用）。`Constants.ets` / `Resolver.ets` / `SourceRepo.ets` / `Library.ets` / `PlayerCard.ets` 零改动，`pageMap` 七个路由名一个未增未减，批量删除落库方法一行未改。根目录只留最新一组：v2.55 HAP + 图解 + `音栈-v2.48-可构建源码工程.zip`；v2.54 HAP / 图解与旧签名副产物分别入 `archive/hap/`、`archive/diagrams/`、`archive/signing-artifacts/`。包 4–5 当时未开始（包 4 已在 v2.56 落地）。
- 最新包 `音栈-v2.56-无障碍与响应式.hap`（67 / 2.56），SHA256 `6338a41228675cfab1d9fa2257735f7c1e7c5f766adbc1c81c50aa9acd7c0942`（2,989,289 字节）；**基线仍是 v2.48（59 / 2.48）不动**，本轮未切基线；源码工程包按当前源码重打（交付时补做，非本包主题改动）。本轮做交互方案包 4「无障碍与响应式」，落五件事：①**读屏语义收成一个出口** —— `Common.IconTap` 新增 `@Prop label` 与 `@Prop minHit = 48`，`label` 非空才 `accessibilityLevel('yes')`，空则 `'auto'`（装饰图标不进焦点树）；`SongRow` 的歌名区、`PageBar` 的标题区用 `accessibilityGroup(true)` 各合并为一句（`rowLabel()` 拼「名称，歌手，歌曲，专辑，时长，正在播放」），行尾收藏 / 下载 / 更多、顶栏返回 / 搜索、`SelectionBar` 三个动作全部带名称，选择条「删除所选，N 项」带数量。**开关与行尾按钮不被 group 吞掉**：group 只合并只读信息，可点动作仍单列。②**触控目标 ≥48×48** —— 全部走 `responseRegion` 外扩，视觉尺寸一个像素没改：`IconTap` 按 `hitPad() = (minHit − visualSize)/2` 外扩（26→48 外扩 11，40→48 外扩 4，已达标则 0），操作行四颗按钮与选择条按钮视觉 44、热区 48；自检结果区的 26vp 关闭按钮四角各扩 11。③**操作行窄屏 / 大字号 2×2** —— `SourcesPage.actionBar` 拆成 `actionLocal / actionNet / actionCheck / actionSelect` 四个**无参** Builder（带参 Builder 按值快照，`导入中…` 会停在旧文案），`onAreaChange` 量容器宽缓存进 `@State actionW`，`actionG() = (actionW − 24) / 4`，`G < 60` 或 `@StorageProp('fontScale') ≥ 1.5` 时两行两列；宽度没量到前先按四列画，避免闪一下 2×2。`EntryAbility` 在 `onCreate` 与 `onConfigurationUpdate` 写 `fontScale` 进 AppStorage，**字号处理放在深浅色早退之前**（否则只调字号会被 return 吞掉）。④**光感四档一次性迁移提示** —— `Constants.PREF` 新增 `LIGHT_SENSE_NOTICE = 'v4_light_sense_notice'`，`Settings.lightSenseNoticeSeen() / setLightSenseNoticeSeen()` 读写；`SettingsPage.needLightNotice()` 只在「旧档位 ≠ 3（真选过）且没看过」为真时显示提示条（左侧 3vp 信号色竖线 + 「知道了」热区 48），点过即落盘；旧 key `v4_light_sense` 仍只读不删，回滚可用。⑤**歌手页部分失败可见** —— `AlbumPage.fetchSongs` 兜底搜索的 12 个并发请求不再 `catch → []`，失败平台记进 `failedBuf`，`load / loadMore` 汇总到 `@State failedSources`，列表底部一行「有 N 个源本次没返回结果（酷我、QQ 音乐），这部分作品暂时看不到」；文案不写「加载失败」，因为作品确实加载到了、只是不全。`Constants` 只加一个 key、`Resolver` / `SourceRepo` / `Library` / `PlayerCard` 零改动，`pageMap` 七个路由名一个未增未减。根目录只留最新一组：v2.56 HAP + 图解 + `音栈-v2.56-可构建源码工程.zip`（按 v2.56 当前源码重打，解压即 `build_release.sh` 构建通过，版本双向 67 / 2.56；v2.48 源码包转入 `archive/source/` 备回滚）；v2.55 HAP / 图解与旧签名副产物分别入 `archive/hap/`、`archive/diagrams/`、`archive/signing-artifacts/`。包 5（大屏索引栏，方案标「待确认」）未开始，下一版 `v2.57（68 / 2.57）`。


- v2.5 已完成「播放栏 → 全屏播放页」官方 `geometryTransition` 共享元素转场（一镜到底）改造。
- **v2.11 按用户决定移除整套「沉浸光感 / 流光跟随」功能，不再做该功能**：v2.6~v2.10 引入的自绘 `flowLight/flowPeak/flowStops`、底栏 `onTouch/onAreaChange` 触点采集、官方 `uiMaterial.ImmersiveMaterial` + `systemMaterial` + `lightEffect`、应用级 `ohos.arkui.UIMaterial.state` metadata、设置页「沉浸光感」四档开关与官方材质能力探针，全部清除。`Shell.ets` / `Constants.ets` / `SettingsPage.ets` / `module.json5` / `Index.ets` 已**回到 v2.5 基线**（逐文件 diff 一致），仅注释措辞中性化与版本号递增。**保留** v2.5 既有的自绘玻璃质感（`lightSense` 档位链路，属原有设计系统，非本功能）、v2.5 共享元素转场，以及 v2.7 的 **API 26 工具链升级**（`build-profile.json5` 用 `26.0.0`、`downloadsToolbar` 改名）。该功能的 HAP 与图解仅存于 `archive/`，不再随工程文档分发。**不要恢复该功能，也不要再评估官方材质接入路径。**
- **v2.12 修复「搜索 → 歌手」头像全空**：此前 `txSearchArtists` / `wySearchArtists` 把 `avatar` 硬写空，酷狗搜索接口实测不返回 `imgurl`、咪咕不返回 `img`，酷我未实现歌手搜索。现 QQ 取 `singer.itemlist[].pic`、网易云取 `artists[].img1v1Url`（补 `WyArtist` 字段）、酷狗按 `singerid` 查 `/api/v3/singer/info` 的 `imgurl` 并发补前 8 个（**不能**按 id 拼 `singerimg.kugou.com/uploadpic/softhead/400/<id>.jpg`，实测不同 id 返回同一张兜底图）。`Cover` 新增 `fallbackText`（歌手名首字）与 `placeholderGradient`（十六进制渐变）：原 `seededGradient` 返回 `hsl()` 字符串，ArkUI 的 `linearGradient` 不解析导致深色下占位整块不渲染、只剩黑圈。咪咕无图字段，走首字占位；酷我歌手搜索当时未实现（这一判断在 v2.13 已纠正并实现）。搜索「歌手」分类出来的是歌手卡片（主流做法），点进 `ArtistPage` 列热门歌曲，工程无独立「专辑」tab（`SearchType.ALBUM=3` 定义未启用，QQ 专辑仅作「歌单」兜底混入）。
- **v2.13 修复「歌手作品只有 30 / 50 首」与「酷我搜不出歌手」**：
  - 30 首 = `artistSongs()` 此前只实现网易云、其余平台返回空 → 详情页退化成「按名搜第 1 页 30 条」；50 首 = 网易云老接口 `/api/artist/{id}` 的 `hotSongs` 固定 50 首。**都不是接口上限**，实测真实作品量：网易云 407 / QQ 417 / 酷狗 680 / 酷我 472。
  - `PlatformApi.artistSongs(artist, page)` 改为返回 `PagedSongs`：网易云走 `/api/v1/artist/songs`（`offset/limit=100`，带 `WY_COOKIE`）、QQ 走 `musicu.fcg` 的 `GetSingerSongList`（`begin/num=100`）、酷狗走 `/api/v3/singer/song`（`page/pagesize=100`）、酷我走 `r.s?artistid=`（`pn` 页码 / `rn=30`）；咪咕无公开作品接口，保持按名搜索兜底（并发 3 页）。`ArtistPage` 新增 `@State page/hasMore/loadingMore/total` + `List.onReachEnd` 加载更多，副标题显示真实总数。
  - 酷我歌手搜索补 `kwSearchArtists()`：`r.s?ft=artist` 是单引号伪 JSON，用新增 `parseKwArtists()` 按 `{'AARTIST'` 切块 + 正则提取（与 `parseKwItems` 同思路），头像 = `BASEPICPATH + PICPATH`。**上一轮「非标 JSON 会带崩搜索页」的注释是错的**，已删。
  - 坑：网易云 v1 连续请求会 `-462` 风控（带 Cookie 缓解，失败回退 hotSongs 50 首）；QQ 老接口 `fcg_v8_singer_track_cp.fcg` 已 404，必须用 `musicu.fcg`；酷我 `r.s` 歌手搜索是单引号、作品查询是标准双引号 JSON，两者解析方式不同；酷我 `rn` 调大反而返回更少，固定 30；酷狗歌手接口歌名在 `filename`（`kgSong` 已支持拆分）；QQ `songInfo` 字段与 `client_search_cp` 不同，用 `txSongFromMusicu` 单独转换。
- **v2.14 修复「搜歌手结果位置显示不对」（咪咕 / QQ 两平台截图）**，两处都是布局问题，与数据无关：
  - **结果区整体垂直居中**：`SearchPage.artistList()` / `sheetList()` / `idleView()` 三个 `Scroll` 都用 `layoutWeight(1)` 撑满剩余高度，ArkUI 的 `Scroll` 在内容短于视口时默认 `Alignment.Center` **垂直居中**，于是结果卡片整体飘到页面中部、筛选栏下方留大片空白，且结果越少空白越大（截图像素实测：咪咕 4 条内容高约 905px 起点 y≈1083、QQ 2 条高约 381px 起点 y≈1344，起点差 261px ≈ 半内容高差 262px，正是居中特征）。三处 `Scroll` 统一加 `.align(Alignment.Top)` 顶对齐。`songList` 用的是 `List`，不受此影响。
  - **无图占位首字跑到圆右下角被裁**：`Cover` 的 `Stack({ alignContent: Alignment.BottomEnd })` 本为把角标钉在右下角，但 `alignContent` 对**所有**子组件生效，v2.12 新增的无图占位 `Text(fallbackText)` 没单独指定对齐，被一起推到右下角、再被圆形 `clip(true)` 裁掉半边（咪咕无头像字段，4 个圆里「周」字都贴在右下）。QQ 有真图（`Image` 铺满 100%）所以看不到。修法：占位文字外包一层 `width/height 100%` 的 `Column` + `justifyContent(FlexAlign.Center)` + `alignItems(HorizontalAlign.Center)`，100% 尺寸容器不受 Stack 对齐影响，角标位置保持不变。
- **v2.15 音源排序改为「长按 2 秒激活 + 上下拖动」**（用户要求去掉操作菜单里的「上移（更优先）/ 下移」，改成长按触发拖动）：
  - 菜单两项已删除，`menuSheet` 里改成一行文字说明「调整顺序：长按音源卡片 2 秒，上下拖动后松手」。`SourceRepo.move()` 保留但菜单不再调用；新增 `SourceRepo.moveTo(id, toIndex)` 一次性落位（纯下标搬运 + `reindex` + `persist` + `notify`）。
  - **为什么不用官方 `List.onItemDragStart/onItemDrop`**：那套拖拽由系统固定长按触发，时长不可配，没法精确做到「长按 2 秒」。改用 `GestureGroup(Parallel, TapGesture, GestureGroup(Sequence, LongPressGesture({duration:2000}), PanGesture({direction:Vertical})))`：短按走显式 `TapGesture`（`onCardTap`，逻辑同原 `onClick`），长按满 2 秒 `beginDrag()` 激活，之后同一手势序列内 Pan 接管纵向拖动。**不能把 `PanGesture` 直接和 `onClick` 挂同一节点**，点击会被吃掉（`PlayerPage` 已踩过，故用显式 Tap + Parallel）。
  - 关键坑：**`GestureMode.Sequence` 组里只有最后一个手势能触发 `onActionEnd`**，所以 `LongPressGesture` 上不要挂 `onActionEnd`——若在长按交棒给 Pan 时触发会误清拖动态。落位靠 `Pan.onActionEnd → endDrag()`，异常复原靠 `Pan.onActionCancel` + `Sequence.onCancel → cancelDrag()`。`suppressTap` 延后 260ms 放开，避免抬手被判成点击设为首选。
  - 拖动中**不重排数据**：只让被拖卡片 `translate/scale/zIndex/opacity/品牌蓝描边`浮起跟手，`List.enableScrollInteraction(!this.dragActive)` 停用滚动避免抢手势；`ForEach` key 不变，手势不中断。松手时 `dragTargetIndex(from, offsetY)` 按各卡片实测高度（`onAreaChange` 采集到 `cardHeights: Map<string,number>`，兜底 132vp 含 12vp 间距）逐格累加「当前半高 + 相邻半高」算目标下标，一次 `moveTo`。选择模式 `selectMode` 下不激活拖动。`dragActive` 时 `sourceCardEdgeWidth/Color` 给 2vp 品牌蓝高亮边框，呼应历史「没开关、没感觉」的反馈教训。
  - 真机手感（2 秒等待、跟手、落位精度）沙箱无设备未实测，属唯一未验证项。
- **v2.16 三件事：拖动交互重做 + 歌单收藏 + 音源左滑四玻璃圆钮**（用户反馈 v2.15「长按时间太长、交互不行」，并参考视频与两张图给出新规格）：
  - **拖动排序**：`LongPressGesture({ duration: 220 })` 短触发（原 2000ms）；Pan 每帧算 `dragToIndex`，其余卡片用 `shiftY(index)` 朝 from 方向顺次平移一格，跨格时 `animateTo(160ms, EaseOut)` 平滑让位，被拖卡片 `dragOffsetY` 仍 1:1 跟手不吃动画；`.translate` 改为 `(拖动卡 ? dragOffsetY : shiftY(index))`。松手仍是一次 `moveTo` 落库、不重排 ForEach，菜单「2 秒」文案同步改成「约 0.2 秒」。
  - **歌单收藏**（与歌曲收藏分开存）：`PrefKeys.FAVORITE_SHEETS` + `Library.favoriteSheets` / `sheetKey(platform|kind|id)` / `getFavoriteSheets()` / `isSheetFavorite()` / `toggleSheetFavorite()` / `removeSheetFavorite()`，统一走 `notify()` 广播 `libraryVersion`。首页四宫格下方新增通栏玻璃卡「歌单收藏」`favSheetsEntry()`（实时数量）→ 新二级页 `FavoriteSheetsPage`（`GlassSheetCard` 两列 + `EmptyView` + `ImmersiveBar` + `.onBackPressed`）；`SheetDetailPage.head()` 新增「收藏 / 已收藏」胶囊（只对平台歌单 / 榜单 / 专辑显示，本地列表不进收藏表）；`SheetCard` 右上角心形角标订阅 `libraryVersion`。首页计数、详情页按钮、卡片角标、收藏列表页四处同源实时刷新。路由 `App.openFavoriteSheets()` → `Index.pageMap('favoriteSheets')`。
  - **音源左滑改造**：删掉卡片右侧蓝色开关旁的 `more` 四宫格图标（图一）；`swipeDelete()` 换成 `swipeActions()` —— 2×2 四枚 40vp 青绿→蓝液态玻璃圆钮（`SourceSwipeButton`：135° 实体渐变 + 180° 上沿弧光 + 亮边 + 外投影 + 白图标 + 小字），顺序「自检、刷新、导出、删除」，分别接 `checkOne()` / 新增 `reloadOne()`（`repo.reload`）/ 新增 `exportOne()`（单文件保存面板）/ `confirmRemove()`（仍带确认弹窗）。左滑区玻璃卡座复用四件套；`.swipeAction(` / `ListItem` / `confirmRemove` / 单源自检 / 全部自检等自检断言全部保留。`IconTap` 已从本页 import 移除。
  - 整体 UI 全部沿用 `glassCardBase / glassSurface / glassEdgeWidth / glassEdgeColor / glassShadow` 青绿液态玻璃四件套，风格一致。
- **v2.17 两件事：左滑四钮配色统一 + 拖动越出当前页面的自动滚屏**（用户反馈「四个图标颜色不统一」「按住上下移动时屏幕应该跟着移动，超出屏幕显示的地方就无能为力」）：
  - **左滑配色**：`SourceSwipeButton` 新增 `@StorageProp('isDark')` 订阅同一份深浅色；`SymbolGlyph` 显式 `.renderingStrategy(SymbolRenderingStrategy.SINGLE)` 强制整枚符号只吃第一色 —— `sys.symbol` 里部分图标自带分层 / 多色绘制，只给一个 `fontColor` 时各层仍按默认色与不透明度出图，这正是「四个图标颜色不统一」的根因。图标色 `iconColor()` 统一成低饱和青蓝（浅色 `#C0135A6E` 半透明深青 / 深色 `#CCBFE7E1` 淡青），与旁边青绿玻璃同色系、比纯白淡一档；小字 `labelColor()` 不再是白，浅色用深蓝近黑 `#FF123A47`、深色用淡蓝 `#FFA9D8E4`。四枚按钮共用这两个方法，深浅色都跟随全局。
  - **拖动自动滚屏**：`List({ space: 12, scroller: this.listScroller })` 绑 `Scroller`；`List.onAreaChange` 采集 `Area.globalPosition.y` 与 `height` 得到窗口坐标系下的可视区。`Pan.onActionUpdate` 用 `GestureEvent.fingerList[0].globalY`（同为窗口坐标系）判定手指是否进入上下 `AUTO_EDGE=110vp` 触发带，`updateAutoZone()` 按深入比例算方向 `autoDir(-1/0/1)` 与速度（3→14vp/帧），`setInterval(16ms)` 驱动 `autoScrollTick()` 每帧 `scroller.scrollBy(0, dy)`。
  - **核心等式**：`dragOffsetY = panOffsetY + scrollAccum`。列表向下滚 S，被拖卡片自然随内容上移 S，translate 补 +S 后仍贴在手指底下；同一份位移继续喂 `dragTargetIndex`，目标下标可越过当前视口一路推进到列表端点，`shiftY` 让位同步生效。松手一次 `moveTo` 后 `scrollToIndex(to + listHeaderCount(), true, CENTER)` 把落位项带回视口（`listHeaderCount()` 动态算 ForEach 之前的固定 ListItem 数，避免下标错位）。
  - 边界保护：`autoScrollTick` 每帧检查 `to <= 0 / >= n-1`、`scroller.currentOffset().yOffset <= 0.5`、`scroller.isAtEnd()`，到端点即停，避免 `scrollBy` 已无效时补偿量继续累加把卡片拽出屏幕。`beginDrag/endDrag/cancelDrag/aboutToDisappear` 都 `stopAutoScroll()` 清定时器并复位 `panOffsetY/scrollAccum/autoDir`。
  - **官方语义核对**：`List.enableScrollInteraction(false)` 只禁用手指 / 鼠标滚动，**不影响 `Scroller` 的 `scrollBy/scrollToIndex`**（SDK `list.d.ts` 注释明确），故拖动中保留 `!dragActive` 仍可程序化滚屏。`GestureEvent.fingerList: FingerInfo[]` 的 `globalY: number`、`Area.globalPosition: Position`、`Scroller.scrollBy(dx,dy)/currentOffset(): OffsetResult/yOffset/isAtEnd()/scrollToIndex()`、`SymbolRenderingStrategy.SINGLE` 均在 API 26 SDK 声明中逐一核对过。
  - 排序提示文案补上「拖到屏幕上下边缘会自动滚动，可移到屏幕外的音源」。整体 UI 仍全部沿用青绿液态玻璃四件套，未引入 `backgroundBlurStyle`。
- **v2.18 三件事：自动滚屏白块 + 图标再淡化 + 歌曲行收藏实时反馈**（用户反馈「超出屏幕开始自动滚动后按住的音源显示空白色，松手又恢复」「左滑 4 个图标颜色再淡一点」「歌曲列表页点收藏图标不能实时反馈，提示已收藏但动画不实时」）：
  - **拖动白块根因与修复**：`List` 用 `ForEach`（非懒加载），官方 `cachedCount` 说明明确「无论懒加载与否，只布局『显示区 + cachedCount』范围内的 ListItem」。v2.17 自动滚屏用 `scroller.scrollBy` 推进列表，被拖卡片靠 `.translate` 贴手指，但 **translate 只改绘制位置、不改 ListItem 布局位置**；列表滚过一屏后它的槽位滑出布局窗口，ArkUI 不再绘制该 item（即官方所谓「减少滑动白块」的另一端），手指底下只剩一块空白。松手 `moveTo + scrollToIndex` 把落位项带回视口才恢复。修复：给 `List` 加 `.cachedCount(this.items.length + 8)`，让整份音源列表在拖动全程保持布局，白块不再出现。音源最多几十条，常驻布局开销可忽略。
  - **左滑图标再淡一档**：`SourceSwipeButton.iconColor()` 不透明度由 `~0.75/0.8`（`#CCBFE7E1`/`#C0135A6E`）降到 `~0.41/0.46`（深色 `#76CBE7DF` / 浅色 `#693A8C90`），色相往圆钮青绿主色靠，不再和上沿弧光抢对比度；`renderingStrategy(SINGLE)` 单色渲染与 `labelColor()` 深蓝近黑/淡蓝保持不变，小字不动。
  - **歌曲行收藏实时反馈根因与修复**：`SongRow.isFav()` 原来只读 `Library.get().isFavorite(this.song)`，**没有读取任何 @StorageProp/@State**，ArkUI 依赖追踪认为这一行不依赖 `libraryVersion`，于是 `toggleFavorite → notify()` 改了库、toast 也弹了，心形图标却不重绘——正是「提示已收藏但不实时反馈」。同一工程里 `SheetCard.sheetFav()` 特意写了 `this.favVersion >= 0` 建立依赖、歌单角标能实时刷新，两者形成对照。修复：`isFav()` 改为 `(this.libVersion + this.favScale) >= 0 && Library.get().isFavorite(this.song)`，把跨页广播 `libVersion` 与新增 `@State favScale`（本行点击脉冲）一起读进依赖图；`toggleFav()` 用 `animateTo` 让心形先弹大到 1.28 再回弹，收藏按钮外包 `Stack().scale(favScale)`，点击同帧强制重绘并给出即时动画，`heart<->heart_fill`、`accent<->text3` 同步切换。播放页 `PlayerPage` 的收藏按钮本就用 `@State favorite` + `toggleFavorite()` 内即时回写，不在此问题范围，未改动。
  - 整体 UI 仍全部沿用青绿液态玻璃四件套，未引入 `backgroundBlurStyle`；`swipeAction` / `confirmRemove` / 单源与全部自检等约束全部保留。
- **v2.19 拖动白块换架构根治**（用户反馈 v2.18 加了 `cachedCount` 仍触发）：截图实测两张完整音源卡之间约 590px（≈20% 屏高）纯背景空白，取样 `#F5F6FA` 与页面背景一致、高度正好一张卡 —— 被拖 ListItem **整个没绘制**。
  - **v2.18 修法错在哪**：核对 API 26 `list.d.ts`，单参 `cachedCount(n)` 只把「显示区 ±n 行」**预布局**（原文 "only the content within the list display area plus the content equivalent to cachedCount outside the display area is laid out"）；双参 `cachedCount(count, show)` 的 `show` **默认 false**，注释明确「Whether to display the preloaded list items」「can be combined with clip / clipContent to display the preloaded nodes」。所以加大单参只解决布局、不解决绘制；而 `.translate` 改绘制位置、不改 ListItem 布局槽位，槽位滑出窗口后整块不画。**只要跟手卡片还挂在 ListItem 里靠 translate 离槽，就会一直和 List 的绘制/裁剪策略打架，调参数调不出来。**
  - **新架构**：抽出 `cardBody(item)` 供列表卡与浮层共用；新增 `ghostCard(item)`（品牌蓝 2vp 描边 + scale 1.03 + 重投影）与 `ghostLayer()`，挂页面最外层 `Stack`、与 `List` 平级并覆盖其上，用 `.position({x:0, y:ghostY})` 绝对定位 + `.hitTestBehavior(HitTestMode.Transparent)`（官方语义：自身与子节点响应命中测试但**不阻塞兄弟节点**，下层 ListItem 的 PanGesture 照常接手指）+ `.zIndex(20)`，且放在 Stack 最后不被 ImmersiveBar 压住。浮层是普通组件、不属于 List 的 item 树，列表滚到哪都按自身位置绘制，白块从机制上消失。
  - **原槽位与让位**：列表卡拖动期间 `.opacity(0)`、`.translate({y:0})`，不再跟手；其余卡片 `shiftY` 让位动画原样保留。浮层起始 `ghostBaseY = cardTops[id] - stackTop`（都是窗口坐标，由卡片 `onAreaChange` 与最外层 Stack `onAreaChange` 采集），之后 `ghostY = ghostBaseY + panOffsetY` **只跟手指、不随列表滚动，因此不需要任何滚动补偿**。`cardBody` 里名字点击与开关回调在 `dragActive && dragId === item.id` 时直接 return，浮层只画不接事件。用 ForEach 把 `dragCards`（长度 0/1）的项作为回调参数交给 `ghostCard`，避开「带参 @Builder 传 this 状态只生效一次」。
  - **补偿量改实测**：新增 `measureScroll()` 读 `listScroller.currentOffset().yOffset - dragStartOffsetY`，替掉 `autoScrollTick` 里 `scrollAccum += dy` 的「期望值累加」—— `scrollBy` 到端点或 `edgeEffect(Spring)` 回弹时实际滚动小于 dy，旧写法会一直高估，把 `dragOffsetY`／落位下标越推越偏。现在 `dragOffsetY` 只用于算落位下标，不承担绘制。
  - **缓存双参兜底**：`.cachedCount(this.items.length + 8, true)` 让预加载节点参与显示，作用是保住手势宿主 ListItem 不被回收、让位卡片跨屏连续，不再是白块的主修。
  - `HitTestMode.Transparent`、`cachedCount(count:number, show:boolean)`（@since 14）、`position(Position)`、`Scroller.currentOffset().yOffset` 均在 API 26 SDK 声明中逐一核对。整体仍沿用青绿玻璃四件套，`swipeAction` / `confirmRemove` / 220ms 短长按 / 边缘自动滚屏 / `favScale` / `renderingStrategy(SINGLE)` 等全部保留。
  - v2.19 干净 release 构建 33 tasks 通过、sign/verify 成功、`Digest verify result: true`、`pack.info ↔ module.json` 双向核对 `com.yinzhan.music` / 30 / 2.19、自检回到 `PASS 49 / WARN 2 / FAIL 0`（新增的「带参 @Builder 传 this 状态」WARN 已用 ForEach 在代码侧消掉，**未放宽自检**）、`modules.abc` 反查确认 `ghostLayer/ghostCard/cardBody/dragCards/HitTestMode/measureScroll` 落包且既有符号保持。HAP 3,570,633 字节，SHA256 `a95929ba…`。快照 `archive/snapshots/LXMusicHarmony-before-v2.19-ghostdrag-20261108-041549.zip`，SHA256 `365fd450…`。**沙箱无真机，真机拖动体感与自动滚屏画面未实测。**
- **v2.20 首页搜索框新增「听歌识曲」入口**（用户给了一张灰底 + 深酒红 `#551220` 的参考图标，要求「看看具体哪个位置适合增加」「图标按这个设计、颜色改变一下、保持整体风格」）—— **本段仅作历史记录：该功能已在 v2.21 按用户决定整套移除**：
  - **位置判断**：放在**搜索框内部最右端**，与「搜索」文字之间隔一道 1vp 细竖线。比选过顶栏问候语右侧（挤掉时间/日期/音源名，且和找歌无关）、四宫格下另起通栏卡（首页被拉长、栅格打散）、框外独立圆钮（与搜索条脱开成两个控件）——都不如框内右端：与「搜索」同属找歌动作、语义相邻，右端是视线终点，不新增行、不动四宫格与歌单收藏栅格。
  - **点击区拆分**：原 `searchBar()` 是「整行一个 `onClick`」。在其上再叠子按钮点击会产生父子响应归属歧义（点识曲可能同时触发搜索）。改为 `Row({space:0})` 内左右两个独立响应区各挂 `onClick`：左侧 `Row.layoutWeight(1)`（放大镜 + 占位文案 + 「搜索」）→ `onOpenSearch('')`，右侧 `Stack(30×30, primarySoft 圆座)` → `App.get().openRecognize()`，中间细竖分隔线。左侧行为与改造前完全一致。
  - **图标自绘**：新增 `ui/RecognizeGlyph.ets`，`@Component` + `@Prop glyphSize / color`。`sys.symbol` 无「识曲」符号，用声明式 `Shape + 6 个 Path` 自绘：`viewPort({x:0,y:0,width:48,height:48})` 固定逻辑坐标、`.width/.height(glyphSize)` 等比缩放。造型按参考稿拆三要素 —— 底部开口大圆环（一段 `A` 弧 + `stroke` + `LineCapStyle.Round`）、中央八分音符（菱形符旗 + 符干 + 椭圆符头，符干 `stroke`、符头/符旗 `fill`）、左右各一道向内收的声波短弧（两条 `Q` 贝塞尔）。线条与填充分 Path 单独设色，避免 `fill` 默认值污染。几何先用标准 SVG 离线渲染核对再落 ArkTS。
  - **编译期坑**：`@Prop` **不能叫 `size`** —— 与 `CustomComponent` 基类的通用属性方法 `size(SizeOptions)` 重名，ArkTS 报 `Property 'size' ... not assignable to same property in base type 'CustomComponent'`。已改名 `glyphSize`，三处调用同步。
  - **配色（按「保持整体风格」改掉酒红）**：参考稿酒红是灰底强调色，和青绿液态玻璃四件套不同色系。图标改吃 `palette(isDark).primary`（浅 `#FF335CFF` / 深 `#FF7C93FF`），与同框「搜索」文字、音源开关、链接图标同色；图标座用 `primarySoft`（主色 8% 透明）；深色模式靠 `@StorageProp('isDark')` 自动重绘。未引入 `backgroundBlurStyle`、未引入第三种强调色。
  - **路由与页面**：`App.openRecognize()` → `Index.pageMap("name === 'recognize'")` → 新增 `ui/pages/RecognizePage.ets`。该页 `NavDestination` + `ImmersiveBar` + 大号自绘图标玻璃座 + 说明卡 + 输入卡，`Scroll` 喂 `TabBarHider`，挂 `.onBackPressed(() => App.get().consumeBackIfQueueOpen())`（铁律 9）。
  - **能力边界（重要，别做成假功能）**：真「听歌识曲」需要麦克风权限 + 音频指纹/曲库比对；按铁律 2「按真实的，不要模拟」，本版**不做转圈动画再编歌名**：识曲页如实写明「未接入音频指纹识别服务」及原因，并给一条**真实可用**的替代路径 —— 输入记得的一句歌词/歌名 → `App.get().openSearch(kw)`（连着全部已导入音源）；空输入走 `toast`，不空转、不假跳转。**（v2.21 校正）** 硬约束不是权限、也不是联网：`ohos.permission.MICROPHONE` 与 `AudioCapturer` 在 API 26 SDK 都有声明；`module.json5` 里已有 `INTERNET`，音源搜索与图片加载都走网络，「命令行离线构建」的「离线」指构建方式而非运行时断网。真正缺的是**可比对的海量曲库指纹索引** —— 通用识曲要么引入第三方商业识别服务（推翻零三方依赖定位），要么只对已导入音源自建指纹库（只认库内歌曲）。
  - **自检**：守断言并入既有 AC 检查项（不新增检查项、51 项基线不变），卡住「自绘图标有 `Shape`/`viewPort`、首页挂了 `RecognizeGlyph` + `openRecognize`、`pageMap` 注册 `recognize`、二级页挂 `onBackPressed`、识曲页接了 `openSearch`」，少任一环入口即死键。保持 `PASS 49 / WARN 2 / FAIL 0`。
  - v2.20 干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、`pack.info ↔ module.json` 双向核对 `com.yinzhan.music` / 31 / 2.20、资源表「音栈」6 次「洛雪」0 次、`modules.abc` 反查确认 `RecognizeGlyph / RecognizePage / openRecognize / glyphSize / viewPort / commands / LineCapStyle /「听歌识曲」` 落包且 `ghostLayer / favScale / swipeActions / geometryTransition` 等既有能力保持。HAP 3,591,105 字节，SHA256 `2684fb8f…`。快照 `archive/snapshots/LXMusicHarmony-before-v2.20-recognize-20261108-080106.zip`，SHA256 `5b5496d2…`。**沙箱无真机，真机深浅色下图标观感、线宽比例与识曲页点击体感未实测。**
- **v2.21 按用户决定整套移除「听歌识曲」功能，不再做该功能**（技术讨论结论：通用识曲依赖云端曲库或商业识别服务，音栈不引三方依赖、不造数；用户确认后要求把功能去掉）：
  - **删除清单**：`ui/RecognizeGlyph.ets`（自绘图标）与 `ui/pages/RecognizePage.ets`（识曲二级页）两个文件；`HomePage.ets` 的识曲 import 与搜索框右端入口；`App.openRecognize()`；`Index.ets` 的识曲 import 与 `pageMap('recognize')` 分支；`selfcheck.py` 里 v2.20 的五条识曲守断言。删完 `entry/src/main/ets` 全目录 grep `Recognize|recognize|识曲|glyphSize` 为空。
  - **首页搜索框回到 v2.19 形态**：单一 `Row({space:8})` + 整行一个 `onClick → onOpenSearch('')`，去掉右侧识曲圆座与细竖分隔线，`padding right` 由 12 回 16。左侧行为与 v2.20 之前完全一致，青绿玻璃四件套与双层投影不变；`withAlpha` / `App` 两个 import 因其它位置仍在用而保留。
  - **自检换反向断言**：并入既有 AC 项（不新增检查项、51 项基线不变），检查「两个组件文件不存在」+「首页 / 路由表 / `core/App.ets` 三处无 `Recognize|recognize|识曲|openRecognize` 残留」，防止功能以半截形态复活。保持 `PASS 49 / WARN 2 / FAIL 0`。
  - 版本 31/2.20 → **32/2.21**（四处同步）。v2.20 的 HAP 与图解仅存于 `archive/`，不再随工程文档分发。**不要恢复该功能。**
- **v2.22 本地数据备份 / 恢复 + 遗留权限清理**（P0 第一批；动手前先按用户决定把正式基线由 v1.9 切到 v2.21，见上方基线条目）：
  - **备份模块**：新增 `core/Backup.ets`。纯端侧 JSON 走系统保存 / 选择面板（`DocumentViewPicker.save/select`），不联网、不引三方依赖、不申请新权限。导出文件名 `音栈备份-YYYYMMDD-HHmm.json`，取消选择不弹提示。
  - **白名单即安全边界**：`STRING_KEYS`(11) / `NUMBER_KEYS`(5) / `BOOL_KEYS`(9) 共 25 项，涵盖收藏 / 歌单收藏 / 自建歌单 / 最近播放 / 搜索历史 / 400 天收听统计 / 全部设置偏好；**不含**音源脚本、本地音乐、下载记录（都是沙箱路径，换机后失效）、播放队列与运行时状态。导入时校验 `app === 'yinzhan'`、`schema === 1`、key 在白名单、类型标记与值类型匹配，否则跳过——不让外部文件任意写 preferences。
  - **恢复后即时刷新**：新增 `Library.reload()` / `PlayStats.reload()` 重读盘（`Library` 再走 `notify()` 广播 `libraryVersion`），`Backup.refreshAfterRestore()` 重落 `qualityPref/lightSense/lyricSize/discoverPlatform`，设置页自身 `reload()` + `applyTheme()`。不重读的话「恢复成功但界面还是旧数字」会重演收藏实时反馈那类问题。
  - **设置页**：新增「数据」组两行入口（备份我的数据 / 从备份恢复）+ 一行范围说明，复用 `SettingArrowRow` 与青绿玻璃四件套；`APP_VERSION` 同步 2.22。
  - **权限清理**：`module.json5` 删除无任何代码调用的 `ohos.permission.ACCELEROMETER`（含 `reason_accelerometer` 文案）与 `ohos.permission.VIBRATE`，`string.json` 删对应条目；只留 `INTERNET` / `KEEP_BACKGROUND_RUNNING`。这是沉浸光感 / 流光下线后的遗留声明。
  - **基线自动化**：`scripts/env/build_release.sh` 新增 `[0/5]` 基线复核，`sha256sum` 比对 `archive/baseline/音栈-v2.21-基线.hap`，不一致即中止（`set -e`）；版本断言同步 33/2.22。
  - **自检**：守断言并入既有 AC 项（不新增检查项、51 项基线不变），卡住「`core/Backup.ets` 存在 / 走系统面板 / 导入有白名单 / 设置页两个入口接上 `doBackup`/`doRestore` / 两个 `reload()` / `module.json5` 无遗留权限」。保持 `PASS 49 / WARN 2 / FAIL 0`。
  - v2.22 干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、`pack.info ↔ module.json` 双向核对 `com.yinzhan.music` / 33 / 2.22、资源表「音栈」6 次「洛雪」0 次、包内 `module.json` 权限只剩 2 项且 `ACCELEROMETER`/`VIBRATE` 符号为 0、`modules.abc` 反查确认 `Backup / 备份我的数据 / 从备份恢复 / refreshAfterRestore / STRING_KEYS / reload` 落包且 `ghostLayer / favScale / swipeActions / geometryTransition` 等既有能力保持。HAP 3,575,425 字节，SHA256 `6d3c6b56…`。v2.21 HAP 与图解已归档（`archive/hap/` 与 `archive/diagrams/`），基线三份副本不动。**沙箱无真机，系统文件面板的真机交互与恢复后页面观感未实测。**
- **v2.23 桌面服务卡片补齐**（P0 第二批）：
  - **性质是「补齐」不是「新增」**：`form_config.json`（`player_card`，2*2 / 2*4、`updateDuration: 1`）与 `string.json` 的 `PlayerCard_label` / `PlayerCard_desc` / `PlayerCardAbility_desc` 早就在，但 `module.json5` 没注册 `extensionAbilities`、`ets/form/pages/PlayerCard.ets` 也不存在，属「配置在、实现缺」的半成品。
  - **按铁律 1 先核对 API 26**：`@kit.FormKit` 导出 `FormExtensionAbility / formBindingData / formProvider / formInfo`；`onAddForm(want): FormBindingData` / `onUpdateForm(formId)` / `onFormEvent` / `onRemoveForm` 声明齐全；`preferences.getPreferencesSync(context, {name})` 与全局 `postCardAction(component, action)` 均有声明 → 可行，再动手。
  - **新增** `ets/form/PlayerCardAbility.ets`：`onAddForm` 用 `getPreferencesSync` 同步读同一份 `yinzhan_v1` 里的 `v4_last_song`（Player 切歌写的是完整 SongInfo JSON），只取 `name`/`singer`；`onUpdateForm` 走 `formProvider.updateForm` 定时刷新；读不到偏好退回引导文案，不抛异常打断桌面。**不改 `Player`、不做跨进程监听、不主动推送、不引三方依赖、不申请新权限。**
  - **新增** `ets/form/pages/PlayerCard.ets`：ArkTS 卡片页面，`@Entry(storage)` + `@LocalStorageProp` 接歌名/歌手/状态，整卡 `postCardAction(router → EntryAbility)` 拉起主界面。卡片语法集合比普通页面窄，只用 `Row/Column/Text` + 基础背景/圆角/边框，**不用** `SymbolGlyph` / `linearGradient`，配色仍取青绿主色系。不做假播放按钮，卡片只显示「最近播放 / 最近一次落盘」，不伪造实时播放状态。
  - **注册**：`module.json5` 新增 `extensionAbilities`（`PlayerCardAbility`、`type: "form"`、`srcEntry: ./ets/form/PlayerCardAbility.ets`、`metadata: ohos.extension.form → $profile:form_config`）。
  - **自检**：守断言并入既有 AC 项（不新增检查项、51 项基线不变），卡住「Ability / 页面存在 / `onAddForm`+`onUpdateForm` / `getPreferencesSync` / `postCardAction`+`router` / `module.json5` 注册 / `form_config` 指向」。保持 `PASS 49 / WARN 2 / FAIL 0`。
  - v2.23 干净 release 构建通过（卡片页面通过 ArkTS 卡片编译）、sign/verify 成功、`Digest verify result: true`、`pack.info ↔ module.json` 双向核对 `com.yinzhan.music` / 34 / 2.23、资源表「音栈」6 次「洛雪」0 次。包内 `extensionAbilities` 注册与 `resources/base/profile/form_config.json` 实测存在，**除 `ets/modules.abc` 外新增 `ets/widgets.abc`**（卡片独立编译产物），`modules.abc + widgets.abc` 反查确认 `PlayerCardAbility / onAddForm / onUpdateForm / postCardAction / getPreferencesSync / songName` 落包，v2.22 的 `Backup / 备份我的数据 / refreshAfterRestore` 与 `ghostLayer / geometryTransition` 保持。权限仍只有 `INTERNET` / `KEEP_BACKGROUND_RUNNING`。HAP 3,593,929 字节，SHA256 `0a661dc0…`。v2.22 HAP 与图解已归档，v2.21 基线三份副本不动。**沙箱无真机，桌面卡片添加流程、尺寸适配与定时刷新观感未实测。**
- **v2.24「为你整理」整理型自动歌单**（P1 主题功能）：
  - **边界**：只重排用户已听过、且库里存有完整 `SongInfo` 的歌；不做猜你喜欢、不预测未听过的歌、不造数、不复活 v2.4 拆掉的统计看板 / 月·回响报告。产物是能直接播放的歌单，不是图表。
  - **不用 `PlayStats.meta` 快照**：它只存 name/singer/album/cover，缺播放必需字段，混进队列会变成点不动的死行；归档也只按天存每小时总时长，没有按歌曲拆时段的明细，拿不出来的维度就不做。
  - `PlayStats.ets` 新增 4 个纯聚合接口：`today()` / `playsInDays(days)` / `msTotal()` / `finishedTotal()` / `lastDayMap()`，返回 `Array<[songKey, 数值]>`，只把已落盘事件重新聚合。
  - 新增 `core/AutoSheets.ets`（歌曲池 = 最近播放 + 收藏，按 `songKey` 去重；生成「本周常听 / 累计听得最久 / 很久没听 / 单曲循环最多」四张歌单，各最多 50 首、空则如实显示空态）与 `ui/pages/AutoSheetsPage.ets`（挂 `.onBackPressed(() => App.get().consumeBackIfQueueOpen())`，铁律 9）；首页「歌单收藏」下方新增通栏玻璃卡「为你整理」（不显示会过期的数字）；`App.openAutoSheets()` → `Index.pageMap('autoSheets')`。
  - **自检**守断言并入既有 AC 项（51 项基线不变），卡住「不造数（无 `Math.random`/`setInterval`）/ 不接 `reportOf`/`MonthReport` / 取完整 SongInfo / 挂返回拦截 / 路由与首页入口闭环」。保持 `PASS 49 / WARN 2 / FAIL 0`。
  - v2.24 干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、`pack.info ↔ module.json` 双向核对 `com.yinzhan.music` / 35 / 2.24、`modules.abc + widgets.abc` 反查确认 `AutoSheets / 为你整理 / 四个歌单标题 / playsInDays / msTotal / lastDayMap / playAndOpen` 落包且 v2.22/v2.23 能力保持。HAP 3,620,681 字节，SHA256 `4c473625…`。**沙箱无真机，歌单真机观感与播放体感未实测，汇总数值取决于本机真实收听记录积累量。**
- **v2.25 专辑分类 + 跨平台同款合并**（P1 收官）：
  - **专辑 tab**：`SearchType.ALBUM = 3` 定义已久未启用，工程此前无独立专辑 tab（QQ 专辑只当歌单兜底混入），各平台也没有统一的专辑搜索接口。按铁律 1/2 不新造接口、不造假 tab：复用 `searchSheets` 各源第 1 页，只保留接口明确标 `sheet.kind === 'album'` 的真实结果，按 `platform + id` 去重，独立 `albumList()` 两列玻璃卡渲染；某源本次没返回专辑就如实显示空态，**不把歌单冒充专辑凑数**。
  - **同款合并**：原 `mergeSongs()` 按「歌名 + 首歌手」去重、命中即丢弃其它平台版本。改为 `mergeSongs(groups, reset)` 收成 `versionMap: Array<[key, SongInfo[]]>`，列表每组只显示代表版本，行下出现「N 个其它版本 · 展开选择」，展开列出全部版本（平台 · 音质）可 `playOne` 直接播；翻页把已有分组带进来，跨页同款也合并。键口径统一到 `songGroupKey()`，与原 normalizeText 口径一致。
  - **编译期两处坑**：`loadMore` 里漏改的一处 `mergeSongs(groups)` 补 `false` 参数；`ListItem` 只能有一个子组件，版本展开 UI 用 `Column` 包起来。两次修正后干净 release 构建通过。
  - **自检**守断言并入既有 AC 项（51 项基线不变），卡住「专辑 tab 入口 / `kind !== 'album'` 真实过滤 / 独立列表 / `versionMap`/`versionsOf`/`expandedKey` / 翻页分组」。保持 `PASS 49 / WARN 2 / FAIL 0`。
  - v2.25 干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、`pack.info ↔ module.json` 双向核对 `com.yinzhan.music` / 36 / 2.25、资源表「音栈」6 次「洛雪」0 次、包内 `extensionAbilities` 仍为 `PlayerCardAbility` 且权限只剩 2 项、`modules.abc + widgets.abc` 反查确认 `专辑 / albumList / versionMap / versionsOf / expandedKey / 其它版本` 落包且 `AutoSheets / Backup / PlayerCardAbility / ghostLayer / favScale / geometryTransition` 全保持。HAP 3,631,285 字节，SHA256 `dc11214e71842b990081e6fd1b8104157c99ec3da09b6bd0869823e40e1df318`。v2.22~v2.24 的 HAP 与图解已归档。**沙箱无真机，专辑 tab 真实覆盖率取决于各音源本次是否返回 album 项，所有新 UI 观感与播放体感未实测。**
- **v2.26 主题玻璃质感档位**（用户 2026-11-08 指定三件事之一；大屏适配按用户决定「只有手机」忽略不做）：
  - **性质是「接通」不是「新增视觉系统」**：`Settings.lightSense()`（0 关/1 柔和/2 标准/3 强）、`EntryAbility.onCreate` 用 `getPreferencesSync` 读 `v4_light_sense` 写进 `AppStorage('lightSense')`、`App.init` 再 `setOrCreate`、`Constants.lightSense(level)` 四档参数化——整条链路本就完整，缺的是「设置页可选入口」和「全站玻璃卡跟随」。
  - **不能只加开关**：全工程 163 处 `glassSurface/glassEdgeWidth/glassEdgeColor/glassShadow/glassDepth` 调用把档位写死成字面量 `2`，只有 `Shell/Index/PlayerPage` 订阅了 `lightSense`。只加设置开关会做成「切档后 13 个页面里 10 个没反应」的假档位（用户历史上反复否定「改了没感觉」）。本版把 163 处全部换成 `this.lightLevel`，给 12 个文件的相关组件补 `@StorageProp('lightSense') lightLevel: number = 2`（按 struct 分段精确注入，逐段自查「有引用必有订阅」）。切档 `applyLight()` → `settings.setLightSense()` + `AppStorage.setOrCreate('lightSense', level)`，常驻一级页一起重组（铁律 9）。
  - **设置页**：「外观」组主题行下新增「质感」四档 `Chip`（`LIGHT_SENSE_LABELS` = 关闭/柔和/标准/浓郁）+ 说明文案，复用青绿玻璃四件套、`Chip` 组件，不引入第三种强调色。设置页自身也订阅了 `lightLevel`，卡片质感跟着变。
  - **自检口径（重要）**：AL/AM/AN/AW/AK 一组「玻璃四件套铺齐」断言原本把 `glassSurface(this.isDark, 2)` 写成字面量，批量替换会误判 32 项。处理是**只在断言内部把判定文本归一化**（`.replace('this.lightLevel','2')`），断言语义一字未放宽；同时在 `check_tab_routes` 新增一条读**原始文本**的守断言，禁止任何含玻璃调用的文件再写死档位 2、且必须订阅 `lightSense`。检查项总数仍 51 项，保持 `PASS 49 / WARN 2 / FAIL 0`。
  - v2.26 干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、`pack.info ↔ module.json` 双向核对 `com.yinzhan.music` / 37 / 2.26、资源表「音栈」6 次「洛雪」0 次。源码写死档位 2 残留 0、订阅 `lightSense` 文件 15 个；包内 `modules.abc + widgets.abc` 反查确认 `LIGHT_SENSE_LABELS / applyLight / setLightSense / lightLevel / 玻璃质感档位` 落包且 v2.22~v2.25 能力全保持。HAP 3,637,217 字节，SHA256 `a8cd8a9e…`（补文案后重建为 3,637,217）。v2.25 HAP 与图解已归档。**沙箱无真机，四档深浅色真机观感与通透度差异的可辨程度未实测。**
- **v2.27 首页模块编排**（用户 2026-11-08 指定三件事之二）：
  - **编排对象**：四张内容卡 —— 搜索框 / 我的音乐四宫格 / 歌单收藏 / 为你整理，各自可显隐 + 上下移排序。顶部时间问候（页面身份）与「还没导入音源」提示（状态引导）**固定不参与编排**，否则卡片全隐藏后首页会连标题和导入引导都没有；全部隐藏是合法状态。
  - **新增** `core/HomeLayout.ets`：`HOME_MODULE_DEFS` 单一事实来源、`layout()` 自愈（只认已知 key / 去重 / 补齐缺失项，挡掉备份或手工文件的非法值）、`visibleKeys()`、`setLayout()` 规范化落盘、`broadcast()` 推 `AppStorage('homeLayout')`、`defaultTab()` / `setDefaultTab()`。
  - **新增** `ui/pages/HomeLayoutPage.ets`：一行一个模块（Toggle 显隐 + ↑↓ 交换顺序，整体替换数组触发 @State 刷新）+ 默认启动页三档 Chip；挂 `.onBackPressed(() => App.get().consumeBackIfQueueOpen())`（铁律 9）。所有改动即时落盘 + 广播，不设保存按钮。
  - **首页**：`@StorageProp('homeLayout')` 订阅，`visibleKeys()` 解析 JSON 交给 `ForEach` 按编排顺序渲染四个 @Builder 分支；常驻一级页不销毁，设置页广播后立即重排（铁律 9）。不缓存进 @State、不需 @Watch 二次搬运。
  - **默认启动页时序**：放在 `EntryAbility.onCreate` 用 `getPreferencesSync` 同步读 `v4_default_tab` 写进 `AppStorage('defaultTab')`（与主题/光感同批首帧），**不能等 `App.init()` 异步**否则会「先落首页再跳设置」闪一帧；`Index` 用 `@StorageProp('defaultTab')` 读，`switchTab(this.defaultTab)` + `Swiper.index(this.tab)` 共用同一 tab。运行中改不跳页，下次冷启动生效。
  - **闭环**：`PrefKeys` 新增 `HOME_LAYOUT` / `DEFAULT_TAB`；`App.init` 在 Store 就绪后补一次 broadcast 兜底；`Backup` 白名单纳入两个 key，`refreshAfterRestore()` 广播 `homeLayout` + `defaultTab`，避免「恢复成功但首页还是旧顺序」。设置页「外观」组加「首页编排」入口行 → `App.openHomeLayout()` → `Index.pageMap('homeLayout')`。
  - **自检**守断言并入既有 AC 项（51 项基线不变），卡住「数据层 + 广播 / 首页订阅 / 编排页 onBackPressed / 路由闭环 / 设置入口 / 默认启动页首帧 / 备份白名单」。保持 `PASS 49 / WARN 2 / FAIL 0`。
  - **编译期坑**：路由分支插入多写了一个 `}`，把 `pageMap` 提前截断（v2.24 同类），去掉后干净构建通过。
  - v2.27 干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、`pack.info ↔ module.json` 双向核对 `com.yinzhan.music` / 38 / 2.27、资源表「音栈」6 次「洛雪」0 次。包内 `modules.abc + widgets.abc` 反查确认 `HomeLayout / HOME_MODULE_DEFS / homeLayout / visibleKeys / setDefaultTab / 首页编排 / 默认启动页 / HomeLayoutPage / openHomeLayout` 落包（`HomeModuleSetting` 是 interface 编译期擦除不进 abc，正常）且 v2.22~v2.26 能力全保持。HAP 3,662,611 字节，SHA256 `21f3e65b…`。v2.26 HAP 与图解已归档。**沙箱无真机，开关/上下移手感、默认启动页冷启动落位、隐藏全部模块后的首页观感未实测。**
- **v2.28 本机音乐多维分类**（用户 2026-11-08 指定三件事之三；**大屏适配按用户「只有手机」决定忽略不做**）：
  - **数据源只有两份真实集合**：`LocalRepo.toSongs()`（导入后拷进沙箱的本地音乐）与 `Downloader.list()` 里 `status === 'done'` 的任务。不联网、不造数、不新增下载/导入能力，只是换个维度重排。
  - **五个真实可推出的维度**：歌手（取首歌手，空→未知歌手）/ 专辑（album/albumName，空→未知专辑）/ 格式（下载任务真实 `format` 优先，否则 filePath 扩展名，异常→未知格式）/ 时长（duration 分 4 档 + 未知时长）/ 来源（本地导入 vs 已下载）。分组按标题排序、组内按歌名排序；点歌用当前分类铺平的队列 `App.play()`。
  - **诚实边界（铁律 2）**：① 不做「文件夹」维度 —— 导入后统一拷进沙箱平铺、下载落固定目录，都不保留原始目录结构，拿不到真实值，不做假分层；② 不伪造拼音首字母 —— 工程无拼音库，改做真实「首字索引」：英文首字母大写 / 中文取标题首字 / 数字符号归 `#`，右侧索引条 `scrollToIndex` 跳组；③ 「合并同名歌曲」开关按「歌名 + 首歌手」去重，**只影响浏览、不删文件**，与搜索页同口径。
  - **新增** `core/LocalLibrary.ets`（纯聚合层：`collect()` / `group()` / `initialOf()` / `indexEntries()`）与 `ui/pages/LocalLibraryPage.ets`（维度 Chip + 去重开关 + 分组列表复用 `SongRow` + 首字索引条 + 空态 + `.onBackPressed`，铁律 9）。订阅 `localVersion` / `downloadVersion` 实时刷新。
  - **接进 v2.27 编排**：`HOME_MODULE_DEFS` 新增第 5 个模块 `localLibrary`（编排页从该表派生，无需改代码），首页新增通栏玻璃卡 `localLibraryEntry()` 并接进 `ForEach(visibleKeys())` 分支；`SheetDetailPage` 本地 / 下载两种 kind 顶部加一条「按维度浏览」入口行（首页把模块隐藏后仍可进入，其它 5 种列表不加）。路由 `App.openLocalLibrary()` → `Index.pageMap('localLibrary')`。
  - **自检**守断言并入既有 AC 项（51 项基线不变），卡住「不造数（无 Math.random/setInterval）/ 取两份真实数据 / 首字不伪造拼音 / 文件夹维度不成立 / 返回拦截 + 索引跳转 / 首页入口与路由闭环」。保持 `PASS 49 / WARN 2 / FAIL 0`。
  - v2.28 一次干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、`pack.info ↔ module.json` 双向核对 `com.yinzhan.music` / 39 / 2.28、资源表「音栈」6 次「洛雪」0 次。包内 `modules.abc + widgets.abc` 反查确认 `LocalLibrary / LOCAL_DIMS / initialOf / indexEntries / durationBucket / 合并同名歌曲 / 本机分类` 落包且 v2.26~v2.27 与更早能力全保持；权限仍只有 `INTERNET / KEEP_BACKGROUND_RUNNING` 两项、`PlayerCardAbility` 注册保持。HAP 3,701,405 字节，SHA256 `1790a4c5…`。v2.26/v2.27 HAP 与图解已归档。**沙箱无真机，分类页索引跳转、分组观感、维度切换后播放体感与分组数量（取决于本机真实歌曲量）未实测。**
- **三版总览**：v2.26（37）主题玻璃质感档位 → v2.27（38）首页模块编排 → v2.28（39）本机音乐多维分类，每版一个主题一个包，旧 HAP/图解入 `archive/hap/` 与 `archive/diagrams/`，根目录只留最新一组。**仍未做、也不在三版范围**：大屏适配（用户忽略）、设置项搜索、播放小件（定时关闭/倍速/淡入淡出/无缝/音量均衡，需先按铁律 1 评估 AVPlayer 能力边界）。
- **v2.29 按用户决定整套移除「为你整理 / 本机分类 / 首页编排」三套功能**（用户原话「没什么用」）：
  - **删除 6 个文件**：`core/AutoSheets.ets`、`ui/pages/AutoSheetsPage.ets`、`core/LocalLibrary.ets`、`ui/pages/LocalLibraryPage.ets`、`core/HomeLayout.ets`、`ui/pages/HomeLayoutPage.ets`。
  - **清理引用**：`HomePage` 去掉 `@StorageProp('homeLayout')` / `visibleKeys()` / 两个入口卡 / `ForEach(visibleKeys())`，回到固定三块「搜索框 → 我的音乐四宫格 → 歌单收藏」；`App` 删 `openAutoSheets/openHomeLayout/openLocalLibrary` 与 `HomeLayout.broadcast()` 兜底；`Index.pageMap` 删 3 个分支、`@StorageProp('defaultTab')` 与 `switchTab(this.defaultTab)` 改回固定 tab 0；`EntryAbility.onCreate` 删 `v4_home_layout` / `v4_default_tab` 首帧读取；`SettingsPage` 删「首页编排」入口行；`SheetDetailPage` 删本地 / 下载列表顶部「按维度浏览」入口；`Backup` 白名单删 `HOME_LAYOUT` / `DEFAULT_TAB` 与恢复后广播（备份项 25→23）；`Constants.PrefKeys` 删两个键；`PlayStats` 删 v2.24 新增的 `today/daysSince/aggregate/playsInDays/msTotal/finishedTotal/lastDayMap` 整段（无其它引用，全清）。
  - **自检**：v2.24 / v2.27 / v2.28 三段正向断言换成一段 v2.29 反向断言（6 个文件不存在 + 9 个文件无残留符号），按 v2.21 识曲删除先例保持「检查项总数不变、不放宽其它检查」；AC PASS 文案同步。仍 `PASS 49 / WARN 2 / FAIL 0`。
  - v2.29 干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、双向核对 `com.yinzhan.music` / 40 / 2.29、资源表「音栈」6 次「洛雪」0 次。包内 `modules.abc + widgets.abc` 反查确认三套功能符号全 0，`ghostLayer / favScale / swipeActions / geometryTransition / Backup / PlayerCardAbility / albumList / versionMap / LIGHT_SENSE_LABELS` 全保持。HAP 3,619,008 字节，SHA256 `d45b59b3…`。快照 `archive/snapshots/LXMusicHarmony-before-v2.29-cleanup-20261108-135857.zip`，SHA256 `b4d8539e…`。**三套功能不要恢复。**
- **v2.30 歌曲行尾图标替换为真实下载**（用户图 1 橙圈标记的是 `SongRow` 行尾 `sys.symbol.more` 四宫格「更多」图标）：
  - `Common.ets / SongRow` 新增 `@StorageProp('downloadVersion') dlVersion`、`canDownload()`、`download()`；行尾在「网络歌曲且本地还没有」时显示 `sys.symbol.arrow_down_circle` 下载按钮，点击直接 `App.get().downloads.enqueue(song)` + toast「已加入下载队列」，与 `SongMenu` 的「下载到本地」同一套真实动作。
  - **不做假入口**：`song.source === 'local'` 或 `App.get().hasDownload(song)` 为真时保持 `more` 菜单图标（没有下载动作可做）；`dlVersion` 订阅让下载完成后按钮即时回退，与 `isFav()` 读 `libVersion` 同一手法。**长按整行仍弹完整 `SongMenu`**（查看歌手 / 从歌单移除 / 收藏等入口一个不丢），单击入口从「更多」变「下载」。
  - 自检守断言并入既有 AC 项（51 项不变），卡住「接 `downloads.enqueue` / 排除本地与已下载 / 订阅 `downloadVersion` / 保留长按菜单」。v2.30 干净 release 构建通过、双向核对 41 / 2.30、包内反查 `canDownload / downloadVersion / 已加入下载队列` 落包且所有既有能力保持。HAP 3,624,509 字节，SHA256 `8d1bd997…`。
- **v2.31 歌手页专辑数与全链路打通**（用户图 2「专辑」tab 空态 + 「我想让他在歌手页里能显示歌手多少部专辑，让他全链路都是通」）：
  - **能力边界（铁律 1/2，重要）**：工程**没有**「按歌手 ID 取专辑列表」的接口；`PlatformApi.artistSongs()` 只返回歌曲，但各平台解析都带真实 `album / albumName / albumId / cover`。所以「多少部专辑」只能从**已加载的真实作品**里按专辑去重聚合，**不是歌手生涯全部专辑总数**，会随上滑加载更多增长；按铁律 2 不造这个总量，也不把歌单冒充专辑。
  - `ArtistPage.ets` 新增 `interface AlbumGroup` 与独立 `@Component AlbumCard`（避开 v2.19「带参 @Builder 传 this 状态只生效一次」的坑）、`buildAlbums(list)`（优先 `albumId`，否则规范化专辑名；**没有专辑名的歌不计入**，不造「未知专辑」凑数）、`currentAlbumSongs()`、`consumeViewBack()` / `goBack()`；`@State viewMode`（0 作品 / 1 专辑）、`activeAlbum`、`albums`（`load` / `loadMore` 后重算）。
  - **链路**：搜索页「专辑」tab 空态按钮改为「去看这位歌手」→ `this.type = 2` + 搜同名 → 歌手结果 → 歌手页 header 显示「N 首作品 · M 部专辑」并给「作品 / 专辑」切换 Chip → 专辑卡列表 → 点进去看该专辑真实歌曲（复用 `SongRow`，可播放 / 收藏 / 行尾下载）→ 返回层级按「专辑内歌曲 → 专辑列表 → 作品列表 → 退页」逐级消费。
  - 诚实标注写进 UI：「专辑按已加载作品去重统计，上滑加载更多后会增加；不是歌手全部专辑总数」。不新造接口、不调不确定的跨平台专辑详情接口（kw/kg/mg 的 album id 语义与 playlist id 不同，直接走 `sheetSongs` 会拿空列表反而断链）。
  - **自检口径**：v2.31 守断言并入既有 AC 项（51 项不变）；`AR` 的「每个二级页挂 onBackPressed」原断言硬编码精确一行 `.onBackPressed(() => App.get().consumeBackIfQueueOpen())`，因歌手页多了视图层级消费而改为「挂了 `.onBackPressed(` + 仍先调 `consumeBackIfQueueOpen()`」两个条件，语义一字未放宽（少任一环仍 FAIL），沿用 v2.26 断言内文本归一化的先例。
  - v2.31 一次干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、双向核对 `com.yinzhan.music` / 42 / 2.31、资源表「音栈」6 次「洛雪」0 次、`selfcheck` 51 项 `PASS 49 / WARN 2 / FAIL 0`。包内反查 `buildAlbums / viewMode / activeAlbum / currentAlbumSongs / 不是歌手全部专辑总数 / 部专辑 / 去看这位歌手 / 已加载作品 / 返回专辑列表` 全落包，v2.29/v2.30 与更早能力全保持；权限仍只有 `INTERNET` / `KEEP_BACKGROUND_RUNNING`，`PlayerCardAbility` 注册保持。HAP 3,639,078 字节，SHA256 `06567539…`。**沙箱无真机，专辑分组数量取决于各音源本次返回的歌曲量与专辑字段完整度，真机观感 / 索引跳转 / 播放体感未实测。**
- **三版总览（二）**：v2.29（40）删三套无用功能 → v2.30（41）行尾图标接真实下载 → v2.31（42）歌手页专辑数与全链路，每版一个主题一个包，旧 HAP/图解入 `archive/hap/` 与 `archive/diagrams/`，根目录只留最新一组。**仍未做**：设置项搜索、播放小件（需先按铁律 1 评估 `AVPlayer` 能力边界）、全局字号 / 无障碍、备份范围扩展、服务卡片交互增强。
- **v2.32 按用户决定删除搜索页「专辑」tab 整套**（图 1 橙圈）：
  - 删 `SearchPage.typeTabs()` 的 `typeTab('专辑', 3)`、`@State albums`、`search()` 里 `type === 3` 专辑搜索分支、`this.albums = []` 重置、`albumList()` 两列渲染、结果区专辑空态、v2.31 刚加的「去看这位歌手」一键切歌手切口，`Models.ets` 的 `SearchType.ALBUM = 3` 枚举值（枚举只剩 0/1/2）。**保留** 单曲/歌单/歌手三 tab、跨平台同款合并（`versionMap / mergeSongs / expandedKey`）、歌手页专辑聚合（`buildAlbums / 部专辑 / 作品·专辑 Chip`）——用户只点名删「专辑那一栏」，未要求删歌手页专辑功能。
  - 自检：v2.31「专辑空态一键切歌手」正向断言换成 v2.32 反向断言（7 个关键词全清），AC PASS 文案同步；按 v2.21/v2.29 删除先例「检查项总数不变、不放宽其它检查」，仍 `PASS 49 / WARN 2 / FAIL 0`。v2.32 干净 release 构建通过、sign/verify 成功、双向核对 43/2.32、资源表「音栈」6 次「洛雪」0 次；包内反查「去看这位歌手/没有找到专辑/ALBUM = 3」全清，`buildAlbums / 部专辑 / versionMap / mergeSongs` 全保持。HAP 3,630,667 字节，SHA256 `7c542790…`。**搜索页专辑 tab 不要恢复。**
- **v2.33 按用户决定删除歌手页「搜同名歌手」按钮**（图 2 橙圈）：
  - 删 `ArtistPage.header()` 里「播放全部」旁的「搜同名歌手」玻璃按钮（含 `sys.symbol.magnifyingglass`）。**保留**「播放全部」按钮、作品/专辑 Chip、专辑聚合、空作品态里「搜索这个名字」兜底重试（后者是加载失败/无作品时的唯一出路，删了空态会变死页；与图 2 橙圈按钮不是一回事）。玻璃四件套 import 因 `AlbumCard` 等仍在用而保留。
  - 自检并入反向断言（防按钮复活 + 防误删「播放全部」），51 项不变。v2.33 干净 release 构建通过、双向核对 44/2.33、包内「搜同名歌手」为 0。HAP 3,631,992 字节，SHA256 `70687620…`。
- **v2.34 修复「详情页 → 播放页」手势返回判断不一致**（用户「检查一下，在各个详情页中打开进入播放页使用手势返回的判断逻辑是不是有问题？看看有没有不一致的」）：
  - **根因（真实 bug）**：全屏播放页 `playerShow` 是 `@Entry Index` 根 `Stack` 末尾的普通 `if` 分支（v2.5 起从 `bindContentCover` 独立模态改成同组件树共享元素转场），**不是模态、没有自身 `onBackPressed`**，盖住整个 Navigation 含所有二级页。而两类返回入口判断不一致：① 一级页 `@Entry.onBackPress()` 是「`consumeBackIfQueueOpen()` 收队列 → `if (this.playerShow)` 收播放页 → `navDepth` 退页 → 退出」四级，**认播放页**；② 二级页时系统返回手势被 `NavPathStack` 消费、只交给各 `NavDestination.onBackPressed(() => App.get().consumeBackIfQueueOpen())`，而 `consumeBackIfQueueOpen() → closeQueueFn()` **只判断 `queueShow`、完全不认 `playerShow`**。于是「从任意详情页（歌单/歌手/榜单等）点播放全部进播放页 → 按返回」时，`closeQueueFn` 见队列没开返回 false → 放行 → **详情页被 pop 掉、播放页浮层却还盖着**；而从一级页进播放页按返回能正常收起。同一个播放页，两条路径行为不同，正是用户察觉的不一致。
  - **修法（一处收敛、全站一致）**：把 `Index` 注册的 `closeQueueFn` 从「只收队列」升级为按优先级「**播放页 `setPlayerShow(false)` → 队列 `queueShow = false`**」统一收两类根级浮层，都返回 true 拦住 Navigation pop、都没开才 false 放行；删掉 `@Entry.onBackPress()` 里单独判 `playerShow` 的分支，让一级页也走同一个判断。**各二级页 `onBackPressed`、顶栏箭头 `App.back()` 一行未改**，因都调 `consumeBackIfQueueOpen()` 自动获得一致行为。`App.ets` 字段/方法注释与 `Index.ets` 注册处注释同步语义（方法名 `consumeBackIfQueueOpen` 沿用历史，实际统一收两类浮层）。
  - **ArtistPage 特例仍成立**：其 `onBackPressed` 先 `consumeBackIfQueueOpen()`（现在能收播放页/队列）再 `consumeViewBack()`（专辑内→专辑列表→作品列表），优先级「全局浮层 > 页内视图层级 > 退页」正确；`goBack()` 顶栏箭头同理。
  - 自检并入 AC 守断言（51 项不变）：卡住 `closeQueueFn` 同时判断 `playerShow`+`setPlayerShow(false)` 与 `queueShow`+`queueShow=false`、顺序为「播放页→队列」、`@Entry.onBackPress` 不再单独判 `playerShow`；AR PASS 文案同步为「先收根级浮层（播放页/队列）」。v2.34 一次干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、双向核对 45/2.34、资源表「音栈」6 次「洛雪」0 次、`selfcheck` 51 项 `PASS 49 / WARN 2 / FAIL 0`。源码级确认 closeQueueFn 段内 playerShow 先于 queueShow、含 `setPlayerShow(false)`、onBackPress 已无单独 playerShow；包内代码符号 `playerShow/queueShow/setPlayerShow/closeQueueFn/consumeBackIfQueueOpen/navDepth` 全命中（注释文字不进 abc 属正常），三版已删符号全 0，既有能力全保持；权限仍只有 `INTERNET / KEEP_BACKGROUND_RUNNING`，`PlayerCardAbility` 注册保持。HAP 3,632,021 字节，SHA256 `36f12fb9…`。**沙箱无真机，返回手势在深浅色/各二级页真机上的实际观感与共享元素收起动画衔接未实测。**
- **三版总览（三）**：v2.32（43）删搜索页专辑 tab → v2.33（44）删歌手页搜同名歌手 → v2.34（45）统一返回手势判断，每版一个主题一个包，旧 HAP/图解入 `archive/hap/` 与 `archive/diagrams/`，根目录只留最新一组。快照 `archive/snapshots/LXMusicHarmony-before-v2.32-albumtab-remove-20261108-150529.zip`，SHA256 `4eaa57c6…`。**仍未做**：设置项搜索、播放小件（需先按铁律 1 评估 `AVPlayer` 能力边界）、全局字号 / 无障碍、备份范围扩展、服务卡片交互增强。
- **v2.35 歌词来源优先级 + 假歌词拦截**（用户反馈：播放酷我平台音乐时，歌词区不一定哪首歌就显示一整屏 `http://car-lv.kuwo.cn/.../trackmedia/xxx.mgg`，底部标「歌词来自 音源·聚合音源」）：
  - **定性**：不是酷我平台把歌词返回错了，也不是播放音源坏了（歌能正常播）。`car-lv.kuwo.cn/.../trackmedia/*.mgg` 是酷我**音频直链**，被第三方「聚合音源」脚本的 `lyric` 动作塞进 `lyric` 字段返回；`LyricRepo.toDoc()` 对 JSON 形态取出 `lyric` 后没有内容校验，`parseLrc` 无时间轴时走「纯文本歌词」分支，而 `looksLikeMarkup` 只认 HTML / JSON 标签、认不出 URL，于是整条链接被当成一句歌词画出来。
  - **为什么「优先本平台」没生效**：`get()` 本来已是「本平台官方词 → 兜底批」，但兜底批里 `fromScript` 与 `fromCrossPlatform` / `fromLrclib` **同批竞速**，`firstDoc` 谁先返回用谁，脚本按歌名去别的平台搜、先返回就抢占；`kw()` 要求 `song.id` 纯数字（音源常给 `MUSIC_450444` 这类 rid，直接跳过），`fromCrossPlatform` 又明确跳过本平台 —— 酷我自己的歌反而拿不到酷我官方词。
  - **实测（沙箱真实请求）**：用搜索接口 `search.kuwo.cn/r.s` 拿到「红色高跟鞋」真实 id `450444`，请求官方歌词 `m.kuwo.cn/newh5/singles/songinfoandlrc?musicId=450444` 返回 `{"data":null,"msg":"音乐查询失败","status":301}`；`newlyric.kuwo.cn/newlyric.lrc` 返回 `TP=ERROR REQUEST`；www API 需签名 —— **酷我官方歌词接口目前整体失效 / 需鉴权**。所以本平台链路在真机上也可能取不到词，这点如实写进结论，不伪装成「已修好酷我官方词」。
  - **改动**：`core/Lrc.ets` 新增 `looksLikeNonLyric()`（URL / `www.` / `.mgg|.mp3|.flac|...` 音频后缀 / `TP=ERROR`、`"code":`、`音乐查询失败` 等报错串 / 无时间轴且一两行超长），`parseLrc` 纯文本分支与 `looksLikeMarkup` 一并拦截；`LyricRepo.toDoc()` 解析前拦截、解析后逐行 `isLinkLine()` 丢链接行，一句真词不剩就整份作废。`get()` 改三级：①本平台按 id 精确取 → ②本平台按「歌名+歌手」回查精确 id（3s 短超时）+ 其它平台同名严格匹配 + LRCLIB → ③音源脚本（独立 4.5s 超时）；`fromCrossPlatform` 不再跳过本平台；`kw()` 兼容 `MUSIC_` rid 与 `songmid` 数字 id。
  - **效果**：音源脚本降到最后且返回值必须过校验，那串 `.mgg` 链接不会再进歌词区；本平台官方词能取到时一定先用本平台；取不到时退「其它平台官方词（同名匹配）/ LRCLIB」，来源标注仍如实显示（如「QQ音乐歌词（同名匹配）」）。
  - 自检守断言并入 AC 项（51 项不变），卡住 `looksLikeNonLyric/isLinkLine`、脚本不与官方词同批、本平台回查、`MUSIC_` 兼容。v2.35 干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、双向核对 46/2.35、`selfcheck` `PASS 49 / WARN 2 / FAIL 0`、包内 `looksLikeNonLyric/isLinkLine/fromScript/MUSIC_` 全命中。HAP 3,629,561 字节，SHA256 `be44c569…`，已归档 `archive/hap/`。快照 `archive/snapshots/LXMusicHarmony-before-v2.35-lyric-priority-20261108-153946.zip`，SHA256 `dbcde5cc…`。**沙箱无真机，第三方音源脚本实际返回值与酷我官方接口在真机网络下是否可用未实测。**
- **v2.36 网易云搜索 -462 风控修复**（用户反馈「搜索歌曲、歌手、歌单，只有网易云平台搜不到；发现页网易云榜单、歌单都正常，是不是又给改出 bug 了」）：
  - **不是这轮改出来的**：v2.32 施工前快照 diff 显示 `PlatformApi.ets`、`Http.ets`、`LyricRepo.ets` 与 v2.32 前**完全一致**；`SearchPage.ets` 只删了专辑 tab（`type === 3`），单曲 / 歌单 / 歌手三条分支一字未改；v2.29 快照里网易云搜索实现也与现在一致。
  - **真实根因（沙箱实测）**：三个 tab 共用 `https://music.163.com/api/search/get/web`（GET + 空 `csrf_token`）。该接口现在对匿名请求**间歇返回** `{"code":-462,"data":{"blockText":"验证成功后，可进行下一步操作哦~"}}`、无 `result`；`WySearchResp` 没有 `code` 字段，上层 `resp.result?.songs ?? []` 直接得空数组 → 搜索页显示「没有找到结果 / 这个源没搜到，试试切到综合」。同一请求连发 8 次，4 次成功 4 次 -462；加 `WY_COOKIE`、改 POST 都不解决。发现页 `/api/toplist/detail` 与歌单详情 `/api/playlist/detail` 是另外的接口、不受该风控，所以照常可用 —— 用户「应该不是音源的问题」判断正确，**是网易云平台侧对老搜索接口加了风控 + 本地把验证页当成空结果**。
  - **改动**：`WySearchResp` 增 `code?: number`；新增 `wySearchRaw(type, keyword, offset, limit)` 统一入口，主接口换实测稳定的 `https://music.163.com/api/v1/search/get`（三种 type 连测全部 200，`result.songs/playlists/artists` 各 30 条、字段与老接口一致、`offset` 分页正常），老 `/web` 接口留作兜底，最多 3 次尝试（v1 → web → v1）；只有 `result` 缺失且 `code !== 200` 才判风控并换路重试，真无结果（`code=200` + `result` 空数组）直接返回。三个 `wySearch*` 全部改走 `wySearchRaw`，一处覆盖单曲 / 歌单 / 歌手。
  - 自检守断言并入 AC 项（51 项不变），卡住 `wySearchRaw` / v1 接口 / 老接口兜底 / `code` 识别 / 三个入口都走统一函数。v2.36 干净 release 构建通过、sign/verify 成功、`Digest verify result: true`、双向核对 47/2.36、资源表「音栈」6 次「洛雪」0 次、`selfcheck` `PASS 49 / WARN 2 / FAIL 0`、包内 `wySearchRaw / api/v1/search/get / api/search/get/web / looksLikeNonLyric / isLinkLine / closeQueueFn / ghostLayer / PlayerCardAbility` 全命中。HAP 3,629,109 字节，SHA256 `b063ceda…`。快照 `archive/snapshots/LXMusicHarmony-before-v2.36-wy-search-20261108-154229.zip`，SHA256 `b36aa20a…`。**沙箱无真机，真机移动网络下 v1 接口是否同样不受风控、-462 是否随账号 / IP 变化未实测；三次重试仍全失败时会显示空态。**
- **两版总览（四）**：v2.35（46）歌词优先与假歌词拦截 → v2.36（47）网易云搜索风控，每版一个主题一个包；v2.34 / v2.35 的 HAP 与图解入 `archive/`，根目录只留 v2.36 一组。下个新功能从 v2.37（48 / 2.37）起算。
- **v2.37 封面链路修复**（用户「有的歌曲获取不到封面？播放什么都正常」+「发现页各个榜单是不是官方没有封面？歌单倒是有封面」）：
  - **定性**：播放链路（`Resolver` 取链）与封面链路（`CoverRepo` / `PlatformApi.fetchCover()`）相互独立，取链成功不等于有封面。旧 `fetchCover()` 只认 `kw/wy/tx/kg/mg` 五个内置平台，音源脚本自定义 source 或本平台补图失败就返回空串；`CoverRepo` 失败冷却 5 分钟且 `refilled` 是永久 `Set`，「坏图 + 那次补图失败」后长期锁死成 ♪。
  - **榜单封面实测**：四平台官方榜单接口都返回封面字段且多数可达 —— 网易云 `/api/toplist/detail` 的 `coverImgUrl`、QQ `musicu.fcg` 的 `frontPicUrl`、酷我 `kbangserver.kuwo.cn/ksong.s` 的 `pic`/`v9_pic2`、酷狗 `/api/v3/rank/list` 的 `imgurl`。下载官方封面拼图后确认：**网易云 / 酷狗的「渐变块 + 白字」就是官方封面本体，不是占位**，QQ 是「巅峰榜」深色封面；用户看到的「基本都没封面」里大部分其实是官方设计。真正显示 ♪ 的是酷我部分榜：`pic` 为目录路径 `.../BangPic/` 或合法 `.jpg` 但服务器 404（经典榜 / 欧美榜 / 日韩榜）。
  - **改动**：`PlatformApi` 新增 `looksLikeImageUrl()`（只认 http(s) 且末段是真图片后缀）、`fetchCover()` 本平台补图失败后走 `coverByCrossSearch(song)`（QQ `client_search_cp` → 酷狗 `v3/search/song`，只取 `sameSong()` 命中的封面，避免张冠李戴）、`kwBoard()` 用 `v9_pic2` 兜底；`SheetInfo` 增 `coverFallback?`、`Cover` 增 `@Prop fallbackUri` + `@State useFallback`，`Image.onError()` 先切备用 URL 再走 `CoverRepo.alternate()`，运行时兜住静态判不出的 404；`DiscoverPage` / `SheetDetailPage` 榜单卡传 `fallbackUri`；`CoverRepo.FAIL_TTL` 5 分钟 → 60 秒、`refilled` 改带 TTL 的 `Map<string, number>`，网络恢复后可再补。
  - 48 / 2.37，HAP 3,638,684 字节，SHA256 `35ff6535…`，归档 `archive/hap/音栈-v2.37-封面链路修复.hap`。**沙箱无真机，真机补图命中率与官方封面观感未实测。**
- **v2.38 按用户决定把「质感」入口从设置页去除，功能保留、默认锁最强浓郁、不要入口**：
  - 删设置页「质感」四档 Chip + 说明文字 + `LIGHT_SENSE_LABELS` + `applyLight()`；**保留** `Constants.lightSense(level)` 四档参数化、`glassSurface/glassEdgeWidth/glassEdgeColor/glassShadow` 全站调用与 20 处 `@StorageProp('lightSense')` 订阅。
  - 默认值统一为 **3（最强浓郁）**：`Settings.lightSense()` 的 `getNumber(PrefKeys.LIGHT_SENSE, 3)`、`EntryAbility.onCreate` 首帧 `getSync('v4_light_sense', 3)`、全站订阅初值 `= 3`。老用户存过 0/1/2 仍按存值生效，只有没存过的新装才落 3。
  - 自检守断言并入 AC 项：反向卡 `LIGHT_SENSE_LABELS` / `applyLight` / `Text('质感')` / `'浓郁'` 入口复活，正向守功能保留与三处默认值 3。49 / 2.38，HAP 3,633,687 字节，SHA256 `d9ec19bf…`，归档 `archive/hap/音栈-v2.38-质感入口下线.hap`。**质感档位入口不要恢复。**
- **v2.39 数据说明与备份范围**（用户「我们这个软件应该没有新建歌单这个功能，在数据说明那里，把新建歌单那个说明去掉，另外把备份数据，备份的范围，加上音源脚本的」）：
  - **定性**：设置页「数据」说明里的「自建歌单」是 v1.9 下线首页自建歌单入口后的文案残留（工程只剩 `Library.createPlaylist()` 数据层方法、无 UI 入口）；`Backup.ets` 注释与 `STRING_KEYS` 明确「不含音源脚本」。音源脚本正文在 `files/sources/<id>.js`、元数据在 `PrefKeys.SOURCES = 'v4_sources'`、首选在 `ACTIVE_SOURCE = 'v4_active_source'`。
  - **铁律 2 的关键**：只改文案、或只把 `v4_sources` 加进白名单 = 恢复后 preferences 有元数据但沙箱 `.js` 全空，音源页满屏「脚本文件丢失，请重新导入」死链。**必须把脚本正文一起备份并写回**。
  - **改动**：`Models.ets` 新增 `SourceBackupItem`（元数据 + `code`）；`SourceRepo` 新增 `exportScripts()`（只导出正文真实存在的脚本，文件已丢的死链不进备份；直接读文件、不走 `readCode()` 以免为备份把 `item.status` 改成 error）与 `restoreFromBackup(scripts, activeId)` —— id 白名单正则 `[A-Za-z0-9_-]{1,64}` 防路径穿越 + code 长度 100~5MB 校验 + 去重 + 逐项 try → `writeFile()` 写回正文 → 重建 `SourcePersist[]` 元数据并落 `v4_sources`/`v4_active_source` → `loadMeta()` + `reloadAll()` 重新注入 → `syncActive()` + `notify()`。元数据只落最小真实集：`size = code.length`、`importedAt = 恢复时间`、`platforms/qualities/actions` 交给脚本重新 inited 时自行上报，**不伪造**。
  - `Backup.ets`：`BackupFile` 增可选 `scripts?` / `activeSource?`；`snapshot()` 带上脚本与首选；`exportTo()` 文案报「N 项数据、M 个音源脚本」；`apply()` 改 `async`，在白名单 entries 之后调 `restoreFromBackup()`。**只有 `scripts` 为非空数组才覆盖音源列表** —— 老备份（无该段）/ 备份时无音源，完全不碰现有音源，避免误清空；脚本恢复单独 try/catch，失败只追加提示、不阻断用户数据恢复；`schema` 仍为 1 保持向后兼容。安全边界不变：entries 仍走 `STRING/NUMBER/BOOL` 白名单 + `kindOf`/`typeMatches` 类型校验，`scripts` 段单独结构化校验，外部 JSON 不能任意写 preferences。
  - 设置页说明改为「包含收藏、歌单收藏、最近播放、搜索历史、收听统计、全部设置与音源脚本（含脚本正文，恢复后自动重新导入）；本地音乐与下载文件请用各自入口单独导出」。
  - 自检守断言并入 AC 项（51 项不变）：卡 `SourceBackupItem` / `exportScripts` / `restoreFromBackup` 六环闭环（id 校验、写回正文、重建元数据、恢复首选、重载内存态、重注入运行时）/ `BackupFile` 两段 / 非空判断 / 防「不含音源脚本」旧注释复活 / 防「自建歌单」说明复活。
  - 50 / 2.39。**沙箱无真机，系统文件面板与恢复后音源重新注入的真机观感未实测。**
- **v2.39 交付基建：正式基线切到 v2.39 + 可构建源码工程包**（2026-11-08 用户「现在把最新版作为基线版本，并把最新版的可构建编译源码工程zip给我」）：
  - **基线切换**：v2.21 三副本整体移入 `archive/baseline/legacy/v2.21/`，**作废、不再复核**；新基线三副本 = `音栈-v2.39-基线.hap` / `LXMusicHarmony-v2.39-基线源码快照.zip` / `音栈-v2.39-基线-图解.html`（图解顶部加了基线标识条）。`build_release.sh` 的 `[0/5]` 改校验 v2.39 HAP 哈希 `1bcb4c70…`，默认输出名改 `build/音栈-v2.39-signed.hap`，头注释去掉 v1.0 字样。
  - **修掉「照文档搭不出环境」的真问题**：`setup_env.sh` / README / 编译指南此前全部停在 **API 12 + hvigor 5.8.9 + SDK 5.0.0.71**，而工程 `compatibleSdkVersion` 是 `26.0.0`，照旧文档搭完环境必然构建失败。新增 `scripts/env/setup_env_26.sh`（API 26 免登录重建：OpenHarmony 7.0-Release SDK + hvigor 6.26.4 + 五个避坑点，含 API 26 新增的闭源 `libimage_transcoder_shared.so` 占位），`env.sh` 改为：`.env.local` 总是读取但外部 `CLT_DIR` 优先、默认探测加 `command-line-tools-26`、并对 `sdk-pkg.json` 的 `apiVersion` 做软校验（指到 API 12 会警告而不是静默构建失败）；`README.md` / `docs/编译环境重建指南（避坑版）.md` 全量改到 API 26，坑 4 → 坑 5，验收表换成 v2.39 实测值。
  - **可构建源码包**：新增 `scripts/env/make_source_zip.sh`，按白名单打包并自检（不得含 `.env.local` / `build/` / `.hvigor/` / `archive/snapshots` / `archive/hap` / `__pycache__`），**包内带 `archive/baseline/音栈-v2.39-基线.hap`**，解压后 `build_release.sh` 的 `[0/5]` 能直接过。产物约 7.2 MB（精确字节数、条目数与哈希以 `archive/baseline/SHA256SUMS` 为准，包内文件不自指），顶层目录 `LXMusicHarmony/`；根目录交付名 `音栈-v2.39-可构建源码工程.zip`，与 `archive/baseline/LXMusicHarmony-v2.39-基线源码快照.zip` 为同一份（哈希相同）。
  - **实测（真实解压构建，不是"应该能编"）**：把 zip 解压到 `/tmp/verify-v239` 的干净目录（确认无 `.env.local` / `build/` / `.hvigor/`），用 `CLT_DIR=/workspace/harmonyos-env-26/command-line-tools` 跑完整 `build_release.sh` —— `[0/5]` 基线哈希一致 → `BUILD SUCCESSFUL in 12 s` → `verify-app success` → `pack.info` 与 `module.json` 双向 `50 / 2.39` → `verifiedPassed = True` → `resources.index`「音栈」6 次「洛雪」0 次 → selfcheck `PASS 49 / WARN 2 / FAIL 0` → 输出 `build/verify.hap` 3,643,804 字节，退出码 0。
  - **首次验证抓到的真 bug**：`build_release.sh` 只在构建前 `mkdir -p` 输出目录，而 hvigor 的 clean/assemble 会清掉工程根 `build/`，导致 `hap-sign-tool` 报 `11017002 Write zip file failed ... (No such file or directory)`。已在 `[2/5]` 签名前补 `mkdir -p "$(dirname "$OUT_HAP")"`，重打源码包后第二次验证全绿。**这个坑只在"全新解压目录"暴露，原工程因为 build/ 里已有历史产物看不出来。**
  - **云端构建被拒：`HK-PROJECT-SECRET-FILE`（用户 2026-11-08 实报）**：
    - **根因**：首版源码包只排除了 `*.hap-chain.cer` 这类后缀，`signing/app-chain.pem` / `signing/profile.p7b` / `signing/profile.json` / `archive/signing/*-profile.p7b` / `archive/signing/*-chain.cer` 全被打进 zip。云构建平台按「归档含证书/密钥」直接拒绝，报「工程归档包含敏感材料 archive/signing/音栈-v2.36-…-chain.cer」。
    - **修法（不伪装、不改名绕过检测）**：`make_source_zip.sh` 排除整个 `signing/` 与 `archive/signing/`，并兜底排除 `.cer/.p12/.p7b/.pem/.jks/.keystore/.csr`；自检把「含签名材料」判为 FAIL 并提示该错误码。`build_release.sh` 增加**签名降级分支**：`signing/app-chain.pem` 与 `profile.p7b` 都在才走 `sign_hap.sh` + profile 校验，缺任一则跳过签名、把 unsigned HAP 复制为产物并打印「云端由平台签名」，不阻断构建。文档补「用云端构建中心（不上传证书）」三步。
    - **同时纠正一个必然踩的坑**：用户截图里云端选的是 **API 24 / HarmonyOS 6.1.1**，而工程 `compatibleSdkVersion` 是 `26.0.0` —— 即使没有敏感文件也会构建失败。文档与 README 均写明**必须选 API 26 / HarmonyOS 26.0.0**。
    - **两路实测**：① 解压无 `signing/` 的源码包 → `BUILD SUCCESSFUL` → 打印跳过签名 → `50 / 2.39` 双向核对 → selfcheck 51 项 → `build/verify.hap` 3,594,052 字节（unsigned），退出码 0；② 原工程（有 `signing/`）回归 → `verify-app success` + `verifiedPassed = True` + 全绿，退出码 0，确认签名分支没被改坏。
  - **沙箱内复用已有工具链，未从零重下 3 GB SDK**；`setup_env_26.sh` 的下载段与已实测过的同源重建脚本一致（同一批 URL / 同一套五个避坑点），但没有在本轮从零跑一遍下载解压。
  - 本轮**不改 APP 源码、不升 versionCode**：HAP 与 v2.39 完全同一份（`1bcb4c70…`），只动构建脚本 / 文档 / 交付物，避免「同一 HAP 两个版本号」。**版本号下一个新功能仍从 v2.40（51 / 2.40）起算。**
- **v2.40 MusicFree 音源支持**（2026-11-09 用户「现在评估一下软件支持Musicfree音源的可能性，github有musicfree的开源项目和音源，验证后然后开始做」）：
  - **先评估再实施，结论「可行，但两套协议不兼容，必须写适配层」**（全部实际取证，不是凭记忆）：
    - GitHub 三个仓库真实存在：`maotoumao/MusicFree`（28.3k stars / AGPL-3.0）、`maotoumao/MusicFreePlugins`（1.9k）、`MusicFreePluginTemplate`；官方协议文档 `musicfree.catcat.work/plugin/protocol.html`。
    - 按官方 `src/core/pluginManager/plugin.ts` 的**原样装载契约** `Function(require, __musicfree_require, module, exports, console, env, URL, process)` 把 7 个真实插件（快手 / 歌词网 / 歌词千寻 / 音悦台 / udio / youtube / webdav）装进 Node，全部正确读出 `platform / version / 方法名`——协议方向看对了。
    - **当前工程是洛雪 lx 协议**：IIFE 顶层执行 + `lx.on(EVENT_NAMES.request, handler)` 注册 + `lx.send('inited')` 上报 + `lx.request()` 原生 HTTP 代理；音源脚本**只**被 `invoke` 用于 `musicUrl` / `lyric` 两个 action，搜索 / 榜单全走内置 `PlatformApi`。
    - **MusicFree 是 CommonJS `module.exports`**：宿主直接调具名方法 `search / getMediaSource / getLyric`，`require` 白名单固定 9 包（cheerio / crypto-js / axios / dayjs / big-integer / qs / he / @react-native-cookies/cookies / webdav），dist 只 20KB 说明 `require('axios')` 是**宿主注入**而非打包。
    - **决定成败的一点**：MusicFree 插件 `search()` 产出的是它自己的 mediaItem（bvid / photo.id / manifest 等自定义字段），`getMediaSource()` 必须拿回这个原对象。若只做「能导入」，插件拿到的是网易云 / QQ 的五平台 id，必然取链失败 —— 那就是「导入成功、自检能过、实际放不出声」的假功能，按铁律 2 不能做。
  - **实现（一个主题一个包）**：
    - 新增 `entry/src/main/resources/rawfile/vendor/mf_runtime.js`：在 ArkWeb 沙箱里按官方 `Function(...)` 契约装载 CommonJS 插件，注入 9 包白名单的浏览器实现（axios 全量转 `lx.request()` 原生代理，避开 WebView 跨域 / 证书问题；cheerio / dayjs / big-integer / he / qs / CryptoJS 纯 JS 子集），再把 `search / getMediaSource / getLyric` 翻译成洛雪 action；`guard()` 把插件内部抛错收敛成空结果，不冒到宿主打断整轮取链。
    - `lx_bridge.html` 的 `__load(instId, code, kind)` 加**协议识别分流**（`detectKind` 双端同款规则，老备份 / 手动塞脚本没带 kind 也能自动兜底）：MusicFree 走 `MFRuntime`，洛雪保持原路径；MusicFree 分支合成 `inited`（`sourceId = 'mf:<instId>'`），复用现成的 `request` handler + `__emit` + 原生 HTTP 代理，**取链 / 歌词链路零改动**。
    - ArkTS 侧：`Models.ets` 给 `SongInfo` 加 `mfRaw`（原始 mediaItem 的 JSON 字符串）、`SourceItem` 加 `kind` / `mfSearchable`、`SourceBackupItem` 加 `kind`；`LxRunner.load(code, kind)` 与 `handleMessage` 的 `loaded` 带 `kind`；`SourceRepo` 加静态 `detectKind` / `mfMeta`，在 `loadMeta / persist / importCode / loadOne / exportScripts / restoreFromBackup` 全链路串起 `kind`（备份恢复按正文自动识别）、`mfSearchSources()` / `searchMusicFree()`、`onLoaded` 回写插件真实名 / 版本 / 更新地址。
    - 搜索页：「综合」= 五大平台 + 全部可搜索插件（并列平铺，按 `SongInfo.source` 区分），插件源带 `MF` 角标可单选，`mf:` 前缀统一分派；`@StorageProp('sourceVersion')` + `@Watch` 保证音源启停后常驻搜索页同步刷新；保存的插件源失效时自动回退「综合」（源合法性校验）。`Platform.ets` 对 `mf:` 源返回 `MF` 短标签，行内不再露一长串实例 id。
    - 播放 / 取词：`Resolver.buildMusicInfo` 把 `mfRaw` 带过去；取链 / 歌词只交给**产出这首歌的那一个插件**（`song.source === 'mf:' + item.id`），洛雪脚本与其它插件都不瞎试。
    - **音源自检改真实链路（本轮抓到的真 bug）**：`check()` 原先拿三首五平台基准曲试取链，MusicFree 插件的 `platforms` 是 `['mf:<id>']`，会被全部过滤 → 必判 `error` → 用户点一次自检插件就从搜索源消失。新增 `checkMusicFree()`：用插件自己的 `search()` 出歌，再拿第一首（带 `mfRaw`）试取链，message 如实区分「搜索与取链正常 / 搜索正常但取链空（版权）/ 本次无结果，取链未验证」，不把单曲版权问题误判成源坏了。
  - **边界（如实标注，不假装能跑）**：`webdav / navidrome / airsonic` 这类插件要用户自己的服务器 + 完整 WebDAV 客户端，`mf_runtime.js` 里 `notSupported('webdav（网盘客户端）')` 明确抛错；MusicFree 协议只有单曲 `search()`，**没有歌单 / 歌手接口**，搜索页这两个 tab 在插件源下显示说明文字，不伪造结果；沙箱无真机，ArkWeb 里 polyfill 的真实网络行为只经 Node 装载验证（7/7 通过）与干净构建，真机插件表现未实测。实测 `MusicFreePlugins/dist` 真实插件体积 1,529～20,272 字符，`importCode` 的 `<100` 校验不会误拒。
  - **自检**：v2.40 守断言并入既有 AC 项（**51 项总数不变**），卡住运行时 9 包注入 / 官方装载契约 / `mfRaw` 回传 / 合成 inited / `kind` 全链路 / 搜索页分派与刷新 / 精确分派 / 插件自检 / WebDAV 不支持标注，少任一环即退回「假功能」。`PASS 49 / WARN 2 / FAIL 0`。
  - **实测**：干净 release 构建 `BUILD SUCCESSFUL` → `verify-app success` + `Digest verify result: true` → `pack.info ↔ module.json` 双向 `com.yinzhan.music / 51 / 2.40` → `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → selfcheck 51 项 → HAP **3,682,261 字节**，SHA256 `8dfac9e8a53365c0a0a20c106f7b330a0d719b3e9c65cf864bc35903fd85a33c`。包内 `modules.abc + widgets.abc` 反查 `musicSearch / mfRaw / mfSources / searchMusicFree / checkMusicFree / mfSourceChip / activeSources / detectKind / mfSearchable / mfSearchSources / MusicFree / 2.40 / MusicFree 音源只提供单曲搜索` 全部落包，`ghostLayer / favScale / swipeActions / geometryTransition / Backup / restoreFromBackup / PlayerCardAbility / onAddForm / versionMap` 既有能力保持；`resources/rawfile/lx_bridge.html` 与 `vendor/mf_runtime.js` 包内字节与源码逐字一致。
  - 隔离快照 `archive/snapshots/LXMusicHarmony-before-v2.40-musicfree-20261109-030443.zip`，SHA256 `8ec364b95b6ca1c229af1d4f21b384f6839f5d9a11bfa6442a2d25e63f4c89ba`。v2.39 基线三份副本不动，`[0/5]` 每轮复核 `1bcb4c70…` 一致。
- **v2.41 MusicFree 订阅与布局修复**（2026-11-09 用户装机反馈「执行失败。另外它这个布局跟上面的音源也不一样呀，有点窄了」，附音源管理页截图）：
  - **取证结论（先查后改，不凭猜测）**：
    - 截图里失败卡片是「自定义音源」，红字 `音源脚本执行失败: Unexpected token ','`；像素分析实测该卡片浅绿区 `x=67~1248`、正常卡片 `x=67~1245`——**宽度完全一致**，「窄」不是字面宽度，而是报错卡片少了 `description` 行、错误信息挤在状态行，结构与正常卡片不一致、显得矮且局促。
    - 克隆 `maotoumao/MusicFreePlugins` 实测：官方 `dist/*/index.js` 13 个插件用工程真实 `mf_runtime.js` 装载 **13 OK / 0 FAIL**，且 `detectKind` 全判 `musicfree`、`new Function` 语法也全过——所以失败脚本不是官方 dist 插件。
    - 找到真正缺口：官方 `dist/_plugins/plugins.json` 是**单行订阅清单** `{"desc":...,"plugins":[{"name","url","version"}...]}`。MusicFree 用户的实际入口是「粘贴订阅链接」，而 v2.40 只吃单个 CommonJS 脚本；把整段 JSON 当洛雪脚本丢进 `new Function` 必然语法错（实测 `Unexpected token ':'`，不同引擎/片段可能是 `','`），名字兜底成「自定义音源」、无描述，正好对上截图。截图里 `酷我/网易云/128k…` 标签来自 `loadMeta()` 读的持久化旧元数据，不是本次上报。
  - **修复（一个主题一个包）**：
    - `SourceRepo` 新增 `parseSubscription()` / `isSubscription()`：识别 `plugins / list / data / sources` 数组或纯数组，只收 http(s) 直链、去重、上限 50（实测官方清单解出 12 个 URL，非法 `javascript:` / `ftp:` 全过滤）；`importCode()` 明确拦下订阅清单并提示改用「从网络导入」，不再制造语法错。
    - `SourcesPage.importFromNet()` 检测订阅清单后**展开成插件直链逐个下载导入**，复用现有 `normalizeUrl` / 网页与短内容拦截；`ok` 计数合并进「已从网络导入 N 个音源」。文件选择器导入订阅清单则给明确错误（清单里是 URL，需联网）。
    - 协议识别三处（`SourceRepo.detectKind` / `lx_bridge.detectKind`）扩到 `export default` / `exports.default` / `__esModule` + 插件特征方法；`mf_runtime.js` 加 `toCommonJS()` 把 ESM 的 `import` / `export default` / 命名 import 降级成 CommonJS，并支持 `exports.default`。Node 实测 4 种 ESM 形态 **4 OK / 0 FAIL**，官方 dist 回归仍 13/13。
    - `lx_bridge.__load` 洛雪分支执行失败时，若正文更像 MusicFree 则**自动按 MusicFree 再装载一次**；两种都失败才报错，且错误带「已尝试洛雪 / MusicFree」与「内容像 JSON 订阅清单」提示。`loadMusicFree` 改为抛异常，让正常分支与回退分支都能拿到合并原因。
    - 官方 `suno` 插件顶层会自调用 `getTopListDetail()` 且无 catch，网络异常会产生未处理 rejection；`mf_runtime.js` 加 `hookUnhandledRejection()` 收敛成日志，不冒到 ArkWeb 宿主。
    - 报错卡片布局统一：`statusText` 错误文案截到 18 字，完整错误在卡片内**单独成行可换行**；新增 `cardHint()` 让所有卡片都有一行说明（正常卡片沿用脚本描述，报错卡片给可操作提示，无描述时按协议给真实说明），结构与高度与正常卡片对齐。
  - **自检**：v2.41 守断言并入既有 AC 项（**51 项总数不变**），卡住订阅解析 / 网络展开 / ESM 预处理 / 失败回退 / 异步收敛 / 卡片说明行与错误截断。`PASS 49 / WARN 2 / FAIL 0`。
  - **实测**：干净 release 构建 `BUILD SUCCESSFUL`（ArkTS 严格类型编译通过）→ `verify-app success` + `Digest verify result: true` → `pack.info ↔ module.json` 双向 `com.yinzhan.music / 52 / 2.41` → `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → selfcheck 51 项 → HAP **3,691,586 字节**，SHA256 `8347d246de6ae762f0c4a212745020df27effdaa9da5e7770c32ab7d6b17589b`。包内 `.abc` 反查 `parseSubscription / isSubscription / cardHint / 2.41 / MusicFree 插件订阅清单` 落包、`ghostLayer / favScale / swipeActions / geometryTransition / Backup / restoreFromBackup / PlayerCardAbility / onAddForm / versionMap` 既有能力保持；`resources/rawfile/lx_bridge.html` 与 `vendor/mf_runtime.js` 包内字节与源码逐字一致。v2.39 基线 HAP `[0/5]` 复核 `1bcb4c70…` 一致。
  - **边界（如实标注）**：`toCommonJS` 只做 ESM→CommonJS 的最小降级，**不做 TypeScript 转译**，带类型注解的 `.ts` 源码仍须用官方 dist；订阅清单里的 URL 需能联网下载（gitee / GitHub raw）；沙箱无真机，ArkWeb 里 polyfill 的真实网络行为与各插件搜播成功率未实测。
- **v2.42 MusicFree 全订阅源适配**（2026-11-09 用户追加反馈「导入的都是这种情况…这个是音源」并给 `hebijunge/musicfree-plugins` 六平台订阅 + 一份 30 个 URL 的《MusicFree 音源 & 订阅源合集》txt，要求「都试一下适配」）：
  - **取证（30 个 URL 全量实测，非抽样）**：并发探测 → 14 个订阅源中 10 个可达（4 个失效：netlify 网页入口 / gitcode / GitHub raw / ghproxy 镜像）、独立 `.js` 6 个可达；把 10 个订阅清单 + 6 个独立源展开去重成 72 个插件 URL，下载成功 **63 个**（9 个失败：418/401/SSL）。10 个订阅清单格式统一 `plugins[].url`（带 `desc`/`yourinfo` 附加字段），`parseSubscription` 全可解析，解出 6~34 个 URL 不等。
  - **四类问题定位**（用工程**改前的**真实 `detectKind` + `MFRuntime.load` 对 63 个脚本逐一实测）：
    - 63 脚本里 **19 个被误判成洛雪**（`detectKind` 只认明文 `module.exports=`，且把 `@name` 头注解当洛雪强特征）。其中 11 个是**混淆 CommonJS** 插件（六平台 `qq/kuwo/kugou/migu/netease/qishui` 用 `module[混淆串]=plugin` 导出、顶层 `var axios=require(...)`；元力 5 个带中文 `@name` 注解但实为 MusicFree 插件）→ 判成洛雪走 `new Function(code)()` 且洛雪分支设 `window.require = undefined` → **正是用户截图里 `require is not a function` 的根因**。
    - 8 个 cwo.cc.cd 聚合插件顶层硬依赖 `const { Buffer } = require("buffer")`，不在注入白名单 → 装载抛「未提供的依赖：buffer」。
    - 8 个 `adad23u.appinstall.life` 链接返回 `<html>…window.location.replace(…)` 跳转页（500 字节），订阅展开分支只校验长度 `<100` 会放过 → 存成音源后执行 `Unexpected token '<'`。
    - 明文 require 包名分布：`axios 48 / crypto-js 29 / cheerio 26 / he 17 / dayjs 10 / buffer 8 / qs 7 / big-integer 7 / pako 4 / webdav 1 / crypto 1`；除 buffer / pako / crypto 外全在既有白名单内。
  - **修复（一个主题一个包）**：
    - **协议判定重定（`SourceRepo.detectKind` + `lx_bridge.detectKind` 双端一致）**：洛雪只认**运行时 API 特征**（`EVENT_NAMES.request` / `lx.on(` / `lx.send(` / `globalThis.lx` / `window.lx`），`@name` 只是头注解不算洛雪（社区 MusicFree 插件也带中文 @name）；MusicFree 认「装载痕迹 + 插件形状」，`require(` / `module[` / `module.exports=` / ESM 任一 + `platform`/`getMediaSource`/`getLyric`/`search(`/`isEnd`。Node 实测 3 个洛雪样本（含「洛雪脚本里故意放 require 字样的陷阱」）全部仍判 `lx`、零误伤；两处真实实现抽取比对 7 组样本 0 不一致。
    - **`mf_runtime.js` 补 `makeBuffer()` 真实现**：`Uint8Array` + `TextEncoder/TextDecoder` + 手写 base64/hex，覆盖 `Buffer.from/alloc/allocUnsafe/concat/isBuffer/byteLength` 与 `toString(utf8/base64/hex/utf16le)`、下标访问；`buildPackages` 注入 `'buffer'`。行为自测 14/14 与 Node 原生 `Buffer` 逐项对齐（含中文 / base64 往返 / hex / utf16le / concat）。`pako` 用 `notSupported` 如实标注能力缺失（具名方法照常导出、用到时明确抛错，不伪装）；`crypto` **故意不加白名单**，让插件的 `try{require('crypto')}catch{降级 crypto-js}` 正确降级。`appVersion` / `process.version` 升 2.42。
    - **导入层拦 HTML 中转页**：`SourceRepo.looksLikeWebPage()` 统一内容体检（BOM / 空白 + `<!doctype`/`<html`/`<head`/`<script`/`<meta`/`<body`/`<?xml`/`<title`），`importCode` 兜底拦截 + `SourcesPage.importFromNet` 单链接与订阅展开两分支都拦，订阅整批失效给「请换一个订阅源」提示。实测 8/8 落地页拦下、真脚本零误拦。
  - **验证（Node 侧用工程改后真实文件，无内存补丁）**：两处判定一致；63 脚本 → 8 个 HTML 落地页拦截 → **剩余 55 个 55/55 装载成功、0 失败，全部判 musicfree**；cwo.cc.cd 依赖 buffer 的插件全通过；`buffer` 行为 14/14；订阅解析 10/10。干净 release 构建 `BUILD SUCCESSFUL`（ArkTS 严格类型通过）→ `verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 53 / 2.42` → `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → selfcheck **51 项 PASS 49 / WARN 2 / FAIL 0**。HAP **3,702,179 字节**，SHA256 `f7aef159d0ae890ef5027c228149d8cf9768b52f5726c66239ea9830fdd17c37`。包内 `.abc` 反查 `looksLikeWebPage / 订阅里的插件链接均已失效 / 2.42 / isSubscription / parseSubscription` 新符号落包、`ghostLayer / favScale / swipeActions / geometryTransition / Backup / restoreFromBackup / PlayerCardAbility / onAddForm / versionMap` 既有能力保持；`resources/rawfile/lx_bridge.html` 与 `vendor/mf_runtime.js` 包内字节与源码逐字一致，`function makeBuffer() / 'buffer': makeBuffer() / toCommonJS / MFRuntime / loadMusicFree / restoreMedia / 已尝试洛雪` 等历史符号全在（这些是 rawfile 资源、不进 `.abc`，反查 MISS 属预期非回归）。v2.39 基线 HAP `[0/5]` 复核 `1bcb4c70…` 一致。
  - **边界（如实标注）**：`pako`（DEFLATE 压缩）、`webdav`、`crypto` 仍如实不提供或降级，依赖这些能力的插件搜索/取链可能失败；14 个订阅源里 4 个（netlify 网页入口 / gitcode / GitHub raw / ghproxy 镜像）、以及 `adad23u.appinstall.life` / `mf.ikunshare.com` / `music.haitangw.net` 等链接本轮实测不可达或返回跳转页，属第三方源失效，换可用订阅即可；沙箱无真机，ArkWeb 里 polyfill 的真实网络行为与各插件搜播成功率未实测。
- **v2.43 MusicFree 就绪状态解耦 + 元力订阅适配**（2026-11-09 用户反馈「自检失败，刷新后显示正常。搜索的时候没有显示这几个平台。只有把这几个平台全部手动刷新一遍，搜索页内才能搜歌的时候显示这几个平台。不知道这个逻辑是什么」，附 18 音源卡片截图：kugou / migu / netease 显示「不可用」「脚本未能载入」，qishui 显示「正常」；并给新订阅 `https://13413.kstore.vip/yuanli/yuanli.json` 要求适配）：
  - **根因（两层，都是真实代码缺陷，不是用户操作问题）**：
    - `mfSearchSources()` 把 `item.status === 'ok'` 当搜索源门槛。而 `status` 语义混杂：`loadMeta()` 冷启动一律重置 `idle`；`check()` / `checkAll()` / `checkMusicFree()` 真实取链失败会写 `error`；`onScriptError` 也写 `error`。`mfSearchable` 还不落盘（`persist()` 没保存，`loadMeta()` 用 `newSource()` 默认 false）。**结果：一次自检 / 网络 / 版权 / 风控波动就把一个已装载好的插件从搜索页踢掉，只能逐个手动「刷新」（`reload` → `loadOne` → `settleLoad` 把 status 点回 ok）才重新出现**。用户问的「这个逻辑是什么」就是这处错误耦合，不是设计意图，已拆除。
    - `loadAll()` 冷启动批量装载**漏传 `item.kind`**（`loadOne()` 传了）。`LxRunner.load` 默认 `'lx'`，桥接页 `__load` 收到 `'lx'` 即信任、不再 `detectKind` → MusicFree 插件被当洛雪脚本装载，只能靠「洛雪执行失败 → 自动按 MusicFree 重试」兜底；十几个源共享一个 WebView 时该回退不稳定，部分源报不出 `inited`，卡片停在「不可用」。
    - 附带两处：`notify()` 用 `Date.now()` 推 `sourceVersion`，同一毫秒连续 notify 值相同，`@StorageProp/@Watch` 不回调，常驻搜索页会漏掉刚就绪的源；`settleLoad` / `loadOne` 失败路径还会把 `mfSearchable` 清零，进一步放大问题。
  - **修复（一个主题一个包）**：
    - `SourceRepo.loadAll()` 按正文 `detectKind(code)` 复核并显式传 `item.kind`，与 `loadOne` 同一事实来源；`loadMeta()` 从持久化的 `kind + actions` 恢复 `mfSearchable`，`persist()` 落盘该能力（`SourcePersist` 加可选 `mfSearchable?`，老元数据由 `actions` 推导）。
    - `mfSearchSources()` 改为只看两件稳定事实：`enabled + kind==='musicfree' + mfSearchable + runner.isLoaded(id)`，**不再看 `status`**。脚本真没装载成功则如实不显示；临时搜不动由 `searchMusicFree` 返回空，不伪造。`settleLoad` / `loadOne` / `checkMusicFree` 失败路径不再清除能力。
    - `SourceItem` 新增 `health` 字段，`check()` / `checkAll()` / `checkMusicFree()` 只写 `health`，`status` 回归单一语义「脚本装载状态」。`statusText` / `statusColor` / `cardHint` / 报错行相应调整：自检失败显示「已就绪 · 自检未通过」+ 中性色 + 说明「本次自检未通过（可能是网络 / 版权限制）；脚本已就绪，不影响搜索，可点「自检」重试」，不再冒充「脚本未能载入」。`checkOne` toast 与 `checkAll` 汇总改读 `health`。
    - `notify()` 改严格递增 `versionSeq`，保证每个源就绪都能触发常驻搜索页 `@Watch` 刷新（铁律 9）。
    - 备份恢复也带上能力：`SourceBackupItem` 加可选 `actions` / `mfSearchable`，`exportScripts()` 导出真实值、`restoreFromBackup()` 写回；老备份没有这两段时仍由 `reloadAll()` 的 inited 上报补齐，不造数。
  - **元力订阅取证（用工程改后真实文件 + 线上真实脚本，无内存补丁）**：`yuanli.json` 是标准 `plugins:[{name,url,version}]` 共 6 条，`parseSubscription` 6/6 解析；下载 wy / kw / kg / qq / bilibili / xiaomi 六个插件（20~138 KB）→ 双端 `detectKind` 6/6 判 `musicfree`、0 不一致；桥接页 `__load(...,'lx')` 与 `__load(...,'musicfree')` 均 **6/6 loaded+inited、0 error**（顺带证明 v2.42 的「洛雪失败回退」兜底本身有效，漏传 kind 是隐患而非本次现象唯一成因）；直调 `MFRuntime.load` 6/6 读出 `platform`（元力WY / 元力KW / 元力KG / 元力QQ / bilibili / 元力MG）、6/6 有 `search` + `getMediaSource`、5/6 有 `getLyric`；`require` 包 `axios / cheerio / crypto-js / dayjs / he / qs / big-integer` **全部在既有白名单内**，网页拦截 0 误拦。**结论：现有装载代码直接支持该订阅，无需为它新增分支**；本轮改动修的是通用「就绪状态 / 搜索可见性」缺陷，元力订阅只作为回归样本纳入 AC 守断言。
  - **自检**：v2.43 守断言并入既有 AC 项（**51 项总数不变**），卡住 `health` 分离 / 能力持久化恢复 / `mfSearchSources` 不绑 `status` 且用 `runner.isLoaded` / `loadAll` 传 `kind` / `sourceVersion` 严格递增 / `plugins` 清单形态 / 自检失败文案。`PASS 49 / WARN 2 / FAIL 0`。
  - **交付**：干净 release `BUILD SUCCESSFUL`（33 tasks）→ `sign-app / verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 54 / 2.43` → `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → HAP **3,700,697 字节**，SHA256 `25887fca41614bde6ca2c259ea2a623ba9fa83a1effe8d037b9a92887eb690dd`。行为级回归：抽取改后真实 `mfSearchSources()` 函数体跑 8 组状态场景 **8/8**（自检失败 / 冷启动未 inited / checking 但脚本已装载 → 仍显示；脚本真未装载 / 禁用 / 洛雪源 / 无 search → 如实不显示），源码写入核对 **13/13**。包内 `.abc` 反查 `versionSeq / health / mfSearchable / mfSearchSources / isLoaded / actions / 已就绪 · 自检未通过 / 本次自检未通过 / 2.43` 全部落包，`geometryTransition / restoreFromBackup / versionMap / Backup / PlayerCardAbility / onAddForm / ghostLayer / favScale / swipeActions` 等历史能力保持；`resources/rawfile/lx_bridge.html`、`vendor/mf_runtime.js`、`vendor/crypto-js.min.js` 包内字节与源码逐字一致。v2.39 基线 HAP `[0/5]` 复核 `1bcb4c70…` 一致。v2.42 HAP / 图解已入 `archive/hap/` 与 `archive/diagrams/`，根目录只留 v2.43 一组 + `音栈-v2.39-可构建源码工程.zip`。
  - **边界（如实标注）**：沙箱无真机，ArkWeb 里十几个源并发装载的真实时序与各插件搜播成功率未实测；本轮改的是「状态与可见性」逻辑，不改变取链 / 协议能力，`pako` / `webdav` / `crypto` 仍如实不提供或降级。
- **v2.44 MusicFree 歌单与歌手搜索**（2026-11-09 用户问「Musicfree不能支持歌单和歌手搜索吗」，附歌单 tab 空态截图「MusicFree 音源只提供单曲搜索，歌单请切回平台源」）：
  - **纠错（铁律 1/2）**：那句文案是 v2.40 写下的错误结论。官方插件协议 `search(query, page, type)` 的 `type ∈ music | album | artist | sheet | lyric`，另有 `supportedSearchType` 声明、`getMusicSheetInfo(sheetItem, page)` 歌单详情、`getArtistWorks(artistItem, page, type)` 歌手作品、`getAlbumInfo`、`importMusicSheet`（依据 `musicfree.catcat.work/plugin/protocol.html` 与官方仓库 `types/plugin.d.ts`）。**协议支持，是工程只接了 `search(...,'music')` 一条分支**，歌单 / 歌手 tab 遇到 `mf:` 源直接返回空。本版按用户此前决定**不恢复搜索页专辑 tab、不复活「搜同名歌手」按钮**。
  - **取证（69 个真实插件，工程真实 `mf_runtime.js` 装载）**：61/69 装载成功（8 个是 v2.42 已拦的 HTML 落地页）；探针以「调用 `search(kw,1,type)` 是否真的发起 HTTP 请求」判定实现分支 —— `sheet` 34/61、`artist` 33/61、`album` 40/61、两者同时 28/61；导出 `getMusicSheetInfo` 43/61、`getArtistWorks` 41/61、`importMusicSheet` 40/61；声明 `supportedSearchType` 59/61；仅实现 music 分支 9/61。元力 6 插件：KW/QQ/MG 歌单+歌手全支持，KG 只有歌单、bilibili 只有歌手、WY 声明全类型且导出详情方法但 `search` 实际只实现单曲（声明与实现不符，如实返回空）。运行时实测发起详情请求：歌单详情 24、歌手作品 25。
  - **真实网络调用（Node fetch 转发 `lx.request`，复刻桥接页 `makeBody` 的 String 包装语义）**：元力KW 搜「经典华语」歌单 **30 条**（封面 / 简介 / 曲目数齐全）、搜「周杰伦」歌手 **30 条**（头像 / 简介齐全）；汽水 qishui 歌手 **20 条**；元力QQ / MG / 酷狗本次未取到（风控或接口变更，不伪造补数）。
  - **修复（一个主题一个包）**：
    - `mf_runtime.js` 的 `makeRequest` 新增 `sheetSearch` / `artistSearch` / `sheetInfo` / `artistWorks` 四个 action；`supportsSearchType()` 按官方声明过滤，**不支持该类型的插件直接返回空且完全不发网络请求**；`toSheet()` / `toArtist()` 映射成宿主 `SheetInfo` / `ArtistInfo` 并保留 `mfRaw`；`restoreItem()` 还原详情页回传的原始 item；异常继续由 `guard()` 收敛，`musicSearch` / `musicUrl` / `lyric` 三个旧 action 行为不变。
    - `SourceRepo.ets` 新增 `searchSheetsMusicFree` / `searchArtistsMusicFree` / `sheetSongsMusicFree` / `artistSongsMusicFree`，复用既有解析 / 超时 / 空结果风格，详情方法回传 `mfRaw`、返回 `PagedSongs` 并透传 `isEnd`。
    - `Models.ets`：`SheetInfo` / `ArtistInfo` 加可选 `mfRaw`，`LxInvokeInfo` 加 `mfRaw`；`platform` 用 `mf:<音源id>` 作详情页分派依据（行内标签仍显示「MusicFree 音源」）。
    - `SearchPage.ets`：新增 `activeMfSources()`，歌单 / 歌手 tab 与五大平台并列并发；删掉错误文案，改为「这个音源没有提供歌单 / 歌手搜索，试试切到综合或其它源」；底部小提示同步。
    - `SheetDetailPage.ets` / `ArtistPage.ets`：按 `mf:` 前缀分派到插件详情接口；歌手页对插件源**不走「按歌名跨平台模糊搜」兜底**，避免拿平台同名结果冒充插件作品。歌曲由 `toSong()` 带上 `source` 与 `mfRaw`，直接复用 v2.40 起的取链 / 取词精确分派，播放链路未改。
  - **自检**：v2.44 守断言并入既有 AC 项（**51 项总数不变**），卡住四个新 action / `supportedSearchType` 过滤 / 字段映射 / 四个 SourceRepo 通道 / 搜索页与两个详情页分派 / 旧错误文案清除。`PASS 49 / WARN 2 / FAIL 0`。
  - **交付**：干净 release `BUILD SUCCESSFUL`（33 tasks）→ `sign-app / verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 55 / 2.44` → `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → HAP **3,718,464 字节**，SHA256 `dfbc0b7998f7b1b82a0b3e4b7ba10b50e9f564d650b152b7a2d2b648f76b186e`。运行时行为级回归：测试桩字段映射 / `mfRaw` 往返 / `isEnd` 透传 / 旧 action 回归 15 项全过，能力过滤与缺方法降级 3 项全过，真实插件矩阵与逐项声明一致。包内 `.abc` 反查 `sheetSearch / artistSearch / sheetInfo / artistWorks / activeMfSources / searchSheetsMusicFree / searchArtistsMusicFree / sheetSongsMusicFree / artistSongsMusicFree / 2.44` 全部落包，错误旧文案「MusicFree 音源只提供单曲搜索」已清除；`geometryTransition / restoreFromBackup / versionMap / Backup / PlayerCardAbility / onAddForm / ghostLayer / favScale / swipeActions / looksLikeWebPage / isSubscription / versionSeq / health / buildAlbums / mfSearchSources` 等历史能力保持。三份 rawfile 包内字节与源码逐字一致。v2.39 基线 HAP `[0/5]` 复核 `1bcb4c70…` 一致。v2.43 HAP / 图解已入 `archive/hap/` 与 `archive/diagrams/`，根目录只留 v2.44 一组 + `音栈-v2.39-可构建源码工程.zip`。
  - **边界（如实标注）**：不是所有插件都有歌单 / 歌手（34 / 33 of 61），没实现的如实返回空；歌单详情目前只取第 1 页（通用歌单详情页无上滑加载更多），歌手作品沿用既有分页；部分源本次真实网络未取到数据；`album` / `lyric` 搜索类型、`importMusicSheet` 导入歌单、`getTopLists` 榜单等协议能力仍未接；沙箱无真机，ArkWeb 并发时序与真机观感未实测；`pako` / `webdav` / `crypto` 仍如实不提供或降级。
- **v2.45 MusicFree 插件取链替补 + 下载完成态**（2026-11-09 用户三连反馈：①「把洛雪音源全部关闭，点播放歌曲死活不启用，Musicfree 音源没加入这个替补逻辑吗」附音源选项截图；②「洛雪来源的发现/搜索的歌曲、歌单、歌手，只要收藏过的，即使没洛雪音源了，点播放能自动切到 music free，跟第一条差不多」；③「图二类似界面，下载完成后图标变成四宫格而不是显示已下载」）：
  - **根因（1 与 2 同源，用户自己判断对了）**：不是「补位开关漏加 MusicFree」，而是 MusicFree 插件**根本进不了取链候选池**。`Resolver.trySources()` 组装候选时有 `item.platforms.indexOf(song.source) < 0 → 跳过`；MusicFree 插件装载时合成 inited 上报的 platforms 是 `mf:<实例id>`，而洛雪来源歌曲 source 是 `wy/kw/qq/kg/mg`，两者永远对不上，候选池阶段就被过滤，「补位竞速」再怎么开关都轮不到它。洛雪全关 → 候选池空 → 死活不启用。更深一层：洛雪来源的歌没有 `mfRaw`，`getMediaSource()` 认不出平台 id（v2.40 已确认的约束），硬塞进候选池也是假功能。
  - **修复（一个主题一个包）**：`Resolver.ets` 新增 `findMusicFreeAlternatives(song)` + 常量 `MF_FALLBACK_MAX=6`，在阶段 2（原平台）失败后、跨平台换源之前插入「2.5 MusicFree 插件替补」：拿 `歌名 + 首歌手` 对 `mfSearchSources()` 前 6 个插件并发调 `searchMusicFree`，用既有 `pickBest()` 严格同名同歌手匹配，只收 `mfRaw` 非空的候选，再交给 `trySources()` —— 第一道 `mfRaw` 精确分派守卫会自动只放行产出这首歌的插件，取链闭环。成功标「 · 插件替补」+ 回填 `altSong`，未命中如实写入失败说明。**不改候选池逻辑**（避免破坏 v2.40 精确分派）、只在失败后触发（正常播放不额外发请求）、放在 `oneOnly` 判断之后（「只用首选音源」时绝不替补）、并发上限 6（不拖慢失败路径）。因所有播放入口（收藏 / 歌单 / 歌手 / 发现 / 搜索）最终都汇到 `Resolver.resolve(song)`，**一处接通即全部生效**，无需给「收藏」单独写逻辑——这正是用户判断的「跟第一条差不多」。
  - **下载完成态**：`Common.ets / SongRow` 新增 `isDownloaded()`（读 `dlVersion` 挂依赖图），行尾改三态：未下载网络歌 → `arrow_down_circle`；已下载 → `checkmark_circle_fill` + 主色 + 点击 toast「这首歌已经在本地了」；本地 / source 空 → `more` 四宫格。之前 `canDownload()` 变 false 会直接落 else 的 more，看不出已下载（v2.30 既定回退设计，用户本次明确要「显示已下载」）。长按完整 `SongMenu` 与 v2.30 全部守断言保留。
  - **取证**：确定性复现 3/3（洛雪全关时候选池确实为空）；工程真实 `mf_runtime.js` 端到端闭环 12/12（按名重搜→`pickBest`→`mfRaw`→`getMediaSource` 出链 + headers 透传 + 反证「无 mfRaw 平台 id 硬问插件取不到链」）；改后真实函数体行为回归 **33/33**（替补严格匹配 / mfRaw 门槛 / 并发上限 / 单插件异常收敛 / 阶段顺序 / 下载三态 / 源码写入）；下载三态判定 4/4。**真实网络对照诊断**：A 路径（v2.40 原生播放）与 B 路径（v2.45 替补）行为完全一致，14 个真实插件 `MISMATCH=0`，证明替补传参无缺陷；本次样本插件 `getMediaSource` 均因 `Cannot read properties of undefined (reading 'url')`（接口/风控）未出链，原生路径同样不出链，与替补链路无关，真实闭环由离线 12/12 承担。
  - **自检**：守断言并入既有 AC 项（**51 项总数不变**），卡住替补入口 / 真实搜索通道 / `pickBest` 严格匹配 / `mfRaw` 门槛 / 并发上限 / 来源标注 / `altSong` 回填 / 阶段顺序 / 已下载勾选态与依赖图订阅。`PASS 49 / WARN 2 / FAIL 0`。
  - **交付**：干净 release `BUILD SUCCESSFUL`（33 tasks）→ `sign-app / verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 56 / 2.45` → `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → HAP **3,720,615 字节**，SHA256 `daa50bbb755aa5fdd3d4fe210d5232d504e41bb998aa6b87e5e5816b6f84493e`。包内 `.abc` 反查 `findMusicFreeAlternatives / MF_FALLBACK_MAX / searchMusicFree / pickBest / 插件替补 / isDownloaded / 2.45` 全部落包，`geometryTransition / restoreFromBackup / versionMap / Backup / PlayerCardAbility / onAddForm / ghostLayer / favScale / swipeActions / looksLikeWebPage / isSubscription / versionSeq / health / buildAlbums / parseSubscription / mfSearchSources / sheetSearch / artistWorks / canDownload` 等历史能力保持；`resources/rawfile/lx_bridge.html`、`vendor/mf_runtime.js`、`vendor/crypto-js.min.js` 包内字节与源码逐字一致。v2.39 基线 HAP `[0/5]` 复核 `1bcb4c70…` 一致。v2.44 HAP / 图解已入 `archive/hap/` 与 `archive/diagrams/`，根目录只留 v2.45 一组 + `音栈-v2.39-可构建源码工程.zip`。注：`sys.symbol.checkmark_circle_fill` / `arrow_down_circle` 是系统符号资源引用，编译后以资源 id 形式存在，不以明文进 `.abc`（源码三处真实调用存在，与 `PlayerPage` 自 v2.30 的用法一致）。
  - **边界（如实标注）**：替补只在原平台与跨平台换源都失败后触发；严格同名匹配不到就如实返回空、不张冠李戴；最多并发 6 个插件；「只用首选音源」开启时不替补；沙箱无真机，ArkWeb 并发时序与真机观感未实测；本次真实网络样本插件均因自身接口/风控未出链（v2.40 原生路径同样如此），不代表替补链路失效；`pako` / `webdav` / `crypto` 仍如实不提供或降级。
- **v2.46 MusicFree 取链失败如实反馈**（2026-11-09 用户反馈：「https://13413.kstore.vip/yuanli/yuanli.json 源里这个订阅源，自检、刷新都显示正常，为什么就是播放不出来呢？你看一下它的提示」附失败面板截图「共 12 个音源参与取链…音源未返回有效链接」）：
  - **取证（真实订阅源 + 真实网络 + 工程真实运行时）**：拉下订阅 JSON，6 个插件；用 `mf_runtime.js` 装载并抓取运行时真实取链 URL，5 个「元力」插件（WY/KW/KG/QQ/MG）全部指向同一个第三方中转 `http://yinyue.haitangw.net/...`（明文 HTTP），第 6 个 bilibili 走 B 站官方 API、与元力无关。中转实测：明文 HTTP 所有 `level` 档位一律 404；HTTPS 返回 `{"code":0,"msg":"请求异常","data":[]}`，换歌 id、换 `standard / exhigh / lossless` 都一样。插件取链代码反混淆后为 `return {url:(await axios.get(中转)).data.data.url}`，中转不返回数据 → 读 `.url` 抛 `Cannot read properties of undefined (reading 'url')`。音质映射表 `{low:"standard",standard:"exhigh",high:"lossless",super:"lossless"}` 与宿主 `qualityOf` 输出 `super / high / low` 完全对得上，**传参无缺陷**。搜索本身正常：「骑士精神 蔡依林」搜回 30 首，第一首正是截图那首且带完整 `mfRaw`。
  - **根因（三层）**：① 插件侧中转服务失效，工程侧无法修复，任何 MusicFree 宿主都出不了链；② `mf_runtime.js` 的 `guard()` 把插件异常吞成 `{}`，`lx_bridge.html` 据此判为「音源未返回有效链接」，失败面板 12 行全是同一句兜底文案；③ `SourceRepo.checkMusicFree()` 只要搜索有结果就无条件 `ok = true`，取链失败只写进 `message`，`health` 仍标「正常」——v2.43「自检失败不踢出搜索源」解耦时走过头（`health` 已不参与 `mfSearchSources()` 过滤，本可如实标失败）。
  - **修复（一个主题一个包）**：A. `guard(promise, empty, exposeError)` 只对 `musicUrl` 开透传，异常改为 `Promise.reject(new Error('插件取链异常：' + 原始异常))`，由桥接页既有 `firstError → finish(false, …)` 分支交给宿主；插件**正常返回空**仍走原兜底文案，不混淆两种情况。B. `checkMusicFree()` 拿到 http 链接才判 `health='ok'`，返回空 / 抛错一律 `health='error'` 且把真实原因写进 `message`；`mfSearchable` 不动，「能搜不能放」的源仍留在搜索页，v2.43 修复不破坏。C. `SourcesPage.cardHint()` 自检未通过时优先展示 `item.message`，保留「脚本已就绪，不影响搜索」如实说明。状态文案自动变「已就绪 · 自检未通过」+ 中性色，toast 也如实说「自检未通过」。
  - **验证**：行为级回归 **25/25**（真实运行时 + 真实元力 WY 插件：搜索仍出 30 首带 `mfRaw`、取链改 reject 且含底层异常；桥接页 632–648 行逐字一致的聚合逻辑确认 `firstError` 回传；抽取 `checkMusicFree()` 真实函数体跑取链抛错 / 返回空 / 成功 / 搜索无结果 4 态，逐个核对 `health` / `message` / 搜索源保留）；成功路径对照 **4/4**（合成可出链插件，url / `320k→high` / 自定义 headers 全部照常透传）；包内 rawfile 新代码核验 **7/7**。守断言并入既有 AC 项，**51 项总数不变**，`PASS 49 / WARN 2 / FAIL 0`。
  - **交付**：干净 release `BUILD SUCCESSFUL` → `sign-app / verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 57 / 2.46` → `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → HAP **3,720,507 字节**，SHA256 `1058391a9f4364bff3694f929d13696f26fbd1fa976ae6f8810f6193d2760c52`。三份 rawfile 包内字节与源码逐字一致；包内 rawfile 逐项核实 `exposeError / 插件取链异常 / 同步与异步透传 / appVersion 2.46 / 搜索分支未透传 / 桥接 firstError`；`.abc` 反查「取链返回空 / 2.46」落包，`findMusicFreeAlternatives / MF_FALLBACK_MAX / isDownloaded / mfSearchSources / sheetSearch / checkMusicFree / geometryTransition / restoreFromBackup` 等历史能力保持。v2.39 基线 HAP `[0/5]` 复核 `1bcb4c70…` 一致。v2.45 HAP / 图解已入 `archive/hap/` 与 `archive/diagrams/`，v2.43–v2.46 的 `.cer/.p7b` 统一入 `archive/signing-artifacts/`，根目录只留 v2.46 一组 + `音栈-v2.39-可构建源码工程.zip`。
  - **边界（如实标注）**：**这一版不能让元力订阅源恢复出链**，修的是「把失败显示成正常」与「提示看不懂」，不是修第三方服务；要让这批源能播放只能等插件作者恢复 / 更换中转地址，或换一个取链服务仍可用的订阅源。`exposeError` 只作用于 `musicUrl`，搜索 / 歌词 / 歌单 / 歌手分支仍按原样收敛；`Resolver.short()` 统一截到 40 字符，长英文异常在失败面板显示为「插件取链异常：…」前缀加截断内容，完整原因在音源卡片说明行；沙箱无真机，ArkWeb 并发时序与真机观感未实测；`pako` / `webdav` / `crypto` 仍如实不提供或降级。
- **v2.47 自检结论如实显示**（2026-11-09 用户反馈：「自检未通过的就不要显示正常了，未通过还显示正常，这是个什么逻辑？」附音源管理截图：toast 为「元力 MG 自检未通过」，同一批卡片状态行仍是绿点「正常 v1.2.1」）：
  - **根因（三处叠加，任一都足以让「正常」赖着不走）**：① `SourcesPage` 的 `ForEach` 键值只拼 `id + status + enabled + order`，自检只改 `health` 不改这四个字段，键值不变 → ArkUI 复用旧节点、卡片整块不重建，toast 读内存说「未通过」、屏幕还停在自检前的「正常」。**这正是 v2.43 那条「自检失败，刷新后显示正常」的真实成因**（退出重进页面整棵重建才显示真实结论），当时按「status 与 health 耦合」修，方向偏了。② `statusText()` 只要 `status === 'ok'` 就返回「正常」，而 `status` 只表示脚本注入无语法错误，与能否取链无关，连一次自检都没跑过的源也显示「正常」。③ `persist()` 未存 `health`，`loadMeta()` 新建对象时 `health` 为空串，冷启动后卡片又回到「正常」。
  - **修复**：A. 键值改为 `id | status | health | checkedAt | enabled | order`（+ 选择态），自检开始 / 结束 / 说明行变化都会让键值变化，卡片当帧重建。B. `statusText()` 拆清语义：`health='ok'` 才写「正常 / 正常 · Xms」；`health='error'` 写「自检未通过」；`health=''` 且已装载写「已就绪 · 未自检」；`status='error'` 仍如实显示装载失败原因。C. `statusColor()` 跟随结论：通过绿、未通过 `accent` 警示橙、未自检中性、装载失败红（v2.43 的「失败降成灰字」正是观感等同正常的原因，改掉）。D. `SourcePersist` 增加 `health / checkedAt / latency / message` 并随元数据落盘，`loadMeta()` 只恢复 `ok / error` 终态，进程被杀残留的 `checking` 一律作废。E. 顶部汇总由「N 个可用」改为「N 个已就绪」，有失败项时补「M 个自检未通过」，新增 `failCount`。
  - **验证**：抽取 `statusText()` / `statusColor()` **真实函数体**跑状态矩阵 8 态（未自检 / 通过有声 / 通过无声 / 未通过 / 自检中 / 装载失败 / 载入中 / 未载入），文案与颜色 **16/16** 命中；反向断言 `health ∈ {'' , checking, error}` 三态文案均不含「正常」且不用绿色 **4/4**；用真实键值表达式算自检前 / 中 / 后键值三态互不相同，确认卡片必重建；持久化 6 项（写入四字段 / 只恢复终态 / `checking` 作废 / `error` 与 `ok` 可恢复）；顶部口径 4 项。行为级总账 **36/36**。守断言并入既有 AC 项，**51 项总数不变**：`PASS 49 / WARN 2 / FAIL 0`（两条 WARN 为 v2.30 起既有冗余广播，按要求不修）。
  - **交付**：干净 release `BUILD SUCCESSFUL` → `sign-app / verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 58 / 2.47`（`targetAPIVersion 26 / compatible 26 / compileSdk 26.0.0.38`）→ `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → HAP **3,727,087 字节**，SHA256 `5429d2ffc6739ac8dca083df720c510e896b37fc6c8579c511cd9c3a76a41224`。三份 rawfile 包内字节与源码逐字一致；`.abc` 反查 `2.47 / failCount / statusText / statusColor / checkedAt` 与历史能力 `findMusicFreeAlternatives / isDownloaded` 全部落包。v2.39 基线 HAP `[0/5]` 复核 `1bcb4c70…` 一致。v2.46 HAP / 图解已入 `archive/hap/` 与 `archive/diagrams/`，v2.47 的 `.cer/.p7b` 入 `archive/signing-artifacts/`，根目录只留 v2.47 一组 + `音栈-v2.39-可构建源码工程.zip`。
  - **边界（如实标注）**：这一版只修「结论显示」，**不会让元力订阅源恢复出链**（中转服务 `yinyue.haitangw.net` 仍失效，属插件侧）；「自检未通过」不再把源标成不可用，该源仍参与搜索，只是如实告诉用户这次取链没验证通过；沙箱无真机，`ForEach` 重建行为按 ArkUI 键值规则与真实键值表达式验证，真机观感未实测；`pako` / `webdav` / `crypto` 仍如实不提供或降级。
- **v2.48 音源多选批量删除**（2026-11-09 用户诉求：「音源管理页增加选择音源按钮，我想实现点击几个音源一起删除或者全选删除」）：
  - **起点**：工程里已有 `selectMode`，但它是给「导出」做的 —— 进入后条内只有一颗「导出」，没有任何删除动作；清几个源只能逐张左滑 → 删除 → 确认，N 个源 N 次弹窗。本轮补的是入口（顶部「选择」）与动作（「删除所选」），不是重做多选。
  - **UI**：① 顶部三颗等宽按钮改为「本地导入 / 网络导入 / 选择」；原「导出」入口没有消失，挪进选择条下排，与「删除所选」并列（`导出所选`），能力一项没少。② 选择条拆两行：上排「取消 · 已选 N / 总数 M · 全选/取消全选」，下排两颗等宽按钮；未勾选时删除按钮 `.enabled(false)` 且 0.45 透明。③ 删除按钮用 `danger` 底色，确认弹窗标题「删除 N 个音源」、正文列前 3 个名字（更多写「等 N 个」）并写明「脚本文件一并删除，删除后只能重新导入」。④ 选择模式下右侧开关收起、左滑四钮返回 0 宽（横向滑动会与勾选冲突、误删代价大）；新增 `onNameTap()`，选择模式点名字直接放行给整卡 `TapGesture` —— 名字 `onClick` 与卡片 Tap 是同一次触摸、都会回调，两处都 toggle 会立刻又取消勾选。
  - **数据层**：新增 `SourceRepo.removeMany(ids: string[]): Promise<number>` —— 按 id 去重、跳过已不存在项，逐个 `unload` + `unlink`，然后**一次** `filter`、**一次** `reindex / persist / notify`，返回真实删除条数。不在外层循环调单删：那会 persist + notify N 次、列表重建 N 轮，选择模式的勾选与节点会被中途刷新打断。`remove(id)` 改为 `await this.removeMany([id])`，单删 / 批量不会再走成两套逻辑。首选被一起删掉时回退剩余列表第一项，与单删兜底一致。
  - **验证**：行为级 `verify_v248.cjs` **42/42**（选择模式结构 21 项 / 仓库层 12 项 / 语义样例 9 项：去重、缺失 id、全选删空、空选、首选回退、全选与取消全选）；守断言并入既有 AC 项，**51 项总数不变**，`PASS 49 / WARN 2 / FAIL 0`。
  - **交付**：干净 release `BUILD SUCCESSFUL` → `sign-app / verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 59 / 2.48` → `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → HAP **3,729,852 字节**，SHA256 `b8b7e7b125da2a2e430c7704579689424b308a6747a2ed2fac0d9a6c71e52741`。包内 `.abc` 反查 `confirmRemoveSelected / removeMany / onNameTap / removing / 2.48` 全部命中，`resources/rawfile/vendor/mf_runtime.js` 为 2.48。v2.39 基线 HAP `[0/5]` 复核 `1bcb4c70…` 一致。v2.47 HAP / 图解入 `archive/hap/` 与 `archive/diagrams/`，v2.48 的 `.cer/.p7b` 入 `archive/signing-artifacts/`，根目录只留 v2.48 一组（HAP + 图解 + 可构建源码包）。
- **v2.48 基线切换（2026-11-09，按用户决定「把最新版作为基线版本」）**：
  - **新基线三件套**固定在 `archive/baseline/`：`音栈-v2.48-基线.hap`（SHA256 `b8b7e7b1…e52741`，3,729,852 字节，与根目录交付 HAP 同字节）/ `LXMusicHarmony-v2.48-基线源码快照.zip`（约 7.3 MB / 172 条目 / 顶层 `LXMusicHarmony/` / 不含任何证书密钥材料；精确字节与哈希见同目录 `SHA256SUMS`，不写进本文件以免自指）/ `音栈-v2.48-基线-图解.html`（SHA256 `1d896f33…a0732c`，比根目录图解多一条「正式基线」标识条）。
  - **旧 v2.39 基线整体作废**：三副本（HAP / 源码快照 / 图解）与旧 `SHA256SUMS`、根目录的 `音栈-v2.39-可构建源码工程.zip` 全部移入 `archive/baseline/legacy/v2.39/`，不再复核、不再保护；`legacy/v2.21/` 保持原样。
  - **闸门改指新基线**：`scripts/env/build_release.sh` 的 `[0/5]` 校验路径与哈希改为 `音栈-v2.48-基线.hap` / `b8b7e7b1…`，头注释改为「基线：v2.48（59 / 2.48）；旧 v2.39 已作废」；`scripts/env/make_source_zip.sh` 的必需文件清单改为 `archive/baseline/音栈-v2.48-基线.hap`；`docs/编译环境重建指南（避坑版）.md` 的默认输出名、排错表、目录说明同步到 v2.48（第 6 节「v2.39 实测」保留为历史验收记录）。
  - **验证**：`sha256sum -c archive/baseline/SHA256SUMS` 三行全 OK；源码包解压到 `/tmp` 后包内基线 HAP 复算 `b8b7e7b1…` 一致、`build_release.sh` 的 `[0/5]` 判定通过、两个脚本 `bash -n` 无语法错误、包内无 `.p12/.p7b/.cer/.pem` 与 `build/` 残留；用新闸门实跑一次完整 release（构建 → 签名 → 验签 `Digest verify result: true` → 双向 `59 / 2.48` → selfcheck `PASS 49 / WARN 2 / FAIL 0`）全部通过。**重建 HAP 为 3,729,850 字节（与基线 3,729,852 差 2 字节，构建非逐字节可复现），基线锚定的是交付给用户的那一份，不因重建而替换。**
  - **边界**：基线三件套禁止移动 / 删除 / 覆盖；以后每轮构建 `[0/5]` 都会复核 `b8b7e7b1…`。下一轮若再切基线，必须同时改脚本、本文件、基线目录三处，不允许「改脚本哈希迁就文件」。
  - **边界（如实标注）**：删除不可恢复（沙箱内脚本 `unlink`，只能重新导入），确认弹窗已明说；勾选状态不落盘，退出页面即清空（删除属不可逆动作，不该下次进来还带着上次的勾）；沙箱无真机，选择条两行在窄屏的排版、删除按钮热区、系统确认弹窗观感未实测；本次未改播放 / 取链 / 自检链路，v2.46 / v2.47 的元力订阅源结论（中转服务仍失效、不能出链）不变。
- **v2.49 双体系自动替补优化 + 歌单收藏多选删除**（2026-11-10 用户诉求：「继续优化两个平台的音源支持和自动替补机制，还有歌单收藏里增加可选择删除选项」）：
  - **「两个平台」按工程语境界定**为洛雪（LX）音源脚本体系 + MusicFree（MF）插件体系 —— 工程只有这两套音源来源，「自动替补」正是 v2.45 起连接两方的 `findMusicFreeAlternatives`。未改任何平台 API 或取链协议。
  - **取证三处真实缺口**：① v2.45 替补是 `mfSearchSources().slice(0, 6)` 纯按音源页顺序，**完全没用上 v2.46 / v2.47 刚做准并持久化的 `health` 自检结论** —— 已判 `error` 的插件（元力中转失效那批）占满 6 个并发名额，能出链的排第 7 位永远轮不到；② 不排除「产出原歌、刚取链失败」的原插件（重复白问同一失效中转）；③ 阶段 3 无条件并发搜 `kw/tx/kg/mg/wy` 五个内置平台 API，但换源拿到的平台歌只能由洛雪脚本取链，洛雪全关时注定空转 5 次。
  - **替补升级（全部收敛在决策内）**：`SourceRepo.mfFallbackSources()` 复用 `mfSearchSources()` 全量结果按 `healthRank`（ok=0 / ''·checking=1 / error=2）稳定排序，同档按 `a.order - b.order` 保持用户拖出来的优先级、不依赖 `Array.sort` 稳定性；**只排序不过滤**——`error` 垫底但保留（自检可能过时 / 偶发抖动，换首歌可能就能出链，v2.43 解耦原则不破坏）。`findMusicFreeAlternatives()` 用 `song.source.indexOf('mf:')===0` 取原实例 id，先剔除再取满 `MF_FALLBACK_MAX=6`（6 个名额全是有效候选），全场只剩原插件时不发请求。新增 `hasEnabledLxSource()`（遍历 `enabled()` 找 `kind !== 'musicfree'`，未分类老脚本按洛雪侧处理避免误跳过），洛雪全关时阶段 3 直接跳过并写 note「洛雪音源都已关闭…本次跳过」，酷我直连（阶段 4）不受影响。阶段 2.5 失败说明改为「按自检通过优先的顺序问过插件」，不再笼统写「没搜到」。**候选池、`mfRaw` 精确分派守卫、`pickBest` 严格同名匹配、`2.5→3` 顺序、`oneOnly` 全部不动**，不张冠李戴、不伪造出链、不拖慢正常播放。
  - **歌单收藏多选删除**：`Library.removeSheetFavorites(keys: string[]): number` 按 `sheetKey` 去重 → 一次 `filter` → 一次 `saveFavoriteSheets` → 一次 `notify`（`removed>0` 才落盘），返回真实移除数；`removeSheetFavorite(sheet)` 单删复用批量路径。`FavoriteSheetsPage` 加 `@State selectMode / selected`（存 `Library.sheetKey(sheet)`，不用 name 怕重名）；说明卡右侧「选择 / 取消」入口、选择条两行（已选 N/M + 全选 / 取消全选 + 删除所选，未勾选禁用 + 0.45 透明）、`AlertDialog` 确认（列前 3 个名字 +「只影响收藏列表，不会删除歌单本身或歌曲文件」）、勾选圈叠左上角 `HitTestMode.None` 不抢点击、未选中卡 0.62 透明；`ForEach` key 加 `_s` 选中后缀（v2.47 教训：key 不带状态则节点复用不重绘）；`onCardTap` 选择模式切换勾选否则进详情；`refresh()` 用 `.some` 清理跨页取消收藏后的失效勾选、全空时退出选择模式；系统返回键与顶栏返回选择模式下先 `exitSelect()`，顶栏副标题改显「已选 N/M」。
  - **验证**：行为级 `verify_v249.cjs` **66/66**（结构 37 项 + 抽取改后真实 ArkTS 函数体去类型后直接执行 29 项：health 三档、旧缺陷「第 7 位 ok 源进前 6」、排除原插件后仍问满 6、只剩原插件不白问、mfRaw 门槛、local / 空名短路、洛雪全关判定、批量去重计数一次落盘）；守断言并入既有 AC 项，**51 项总数不变**，`PASS 49 / WARN 2 / FAIL 0`。
  - **交付**：干净 release `BUILD SUCCESSFUL` → `sign-app / verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 60 / 2.49`（`targetAPIVersion 26 / compatible 26`）→ `verifiedPassed = True` → 资源表「音栈」6 次「洛雪」0 次 → HAP **3,742,252 字节**，SHA256 `b99186022c4adc730f7b0fa1bc569f290dd68c02bbe078a11f08e2c9a7bfc9c9`。包内 `.abc` 反查 `mfFallbackSources / healthRank / hasEnabledLxSource / removeSheetFavorites / confirmRemoveSelected / toggleAll / exitSelect / 2.49 / findMusicFreeAlternatives / isDownloaded` 全部命中（`MF_FALLBACK_MAX` 与既有 `INIT_GRACE_MS` 同为编译内联常量、不以明文进 abc，属预期）；三份 rawfile 与源码逐字一致、`mf_runtime.js` 为 2.49。**基线 v2.48 保持不动**（`[0/5]` 仍复核 `b8b7e7b1…`），本轮未切基线、未重打源码包。v2.48 HAP / 图解入 `archive/hap/` 与 `archive/diagrams/`，v2.49 的 `.cer/.p7b` 入 `archive/signing-artifacts/`，根目录只留 v2.49 一组（HAP + 图解）+ `音栈-v2.48-可构建源码工程.zip`。
  - **边界（如实标注）**：**这一版不能让失效的第三方订阅源恢复出链**——元力那批依赖的 `yinyue.haitangw.net` 中转仍是插件侧失效（HTTP 404 / HTTPS「请求异常」），工程侧无法修复；`health='error'` 只降权不排除，换首歌能出链时照样顶上。`health` 是「上次自检结论」不是实时探测，用户没自检或环境变了排序依据可能过期，故设计上只降权不排除。沙箱无真机，ArkWeb 并发时序、选择条两行窄屏排版、勾选圈热区、系统弹窗观感未实测；取消收藏只影响收藏列表、不删歌单本身或歌曲文件。`pako` / `webdav` / `crypto` 仍如实不提供或降级。
- **v2.50 选择条统一下方**（2026-11-10 用户诉求：「选择后，那个删除全部不要在顶部。要在下方，我记得音源那个地方也有选择，全选之类的，要保持统一的设计」）：
  - **需求两层**：① 选择模式后的批量操作（全选 / 删除）不要挤在顶部，要放下方；② 音源管理页也有同样的「选择 / 全选」，两处设计必须统一。只挪歌单页、音源页留顶部恰是「不统一」，故**两页一起改**。取证：改前音源页选择条是 `List` 第一个 `ListItem`（随列表滚走）、歌单页是 `Scroll` 内容流里说明卡正下方一块，且上排元素 / 下排按钮数 / 退出入口都不同。
  - **落地结构**：两页主 `Column` 都是「列表 `.layoutWeight(1)` → 选择条（独立子元素，不随列表滚）→ `Row().height(PAGE_BOTTOM + MINI_BAR_SPACE)` 留白」三段。**关键约束**：迷你播放条 + 胶囊标签栏是 `pages/Index.ets` 全局悬浮层（二级页常驻，Constants 要求额外留 100vp），选择条若用 Stack 底对齐贴屏幕底会被盖住，留白把它顶到悬浮层之上；列表自动收缩，内容仍可滚到底。
  - **统一设计**：上排「取消（`text2`）/ 已选 N/M（`text3` 居中 `layoutWeight(1)` + `TextAlign.Center`）/ 全选·取消全选（`primary`）」；下排 danger 底白字「删除所选」（`RADIUS.pill` / 38 高 / 未勾选 `text3` 置灰 + `opacity 0.45` + `enabled(false)`）；玻璃四件套卡座 + 统一 `padding({ left:16, right:14, top:10, bottom:10 })`。音源页下排额外「导出所选」（两颗 `layoutWeight(1)` 平分），歌单页单颗 `width('100%')` 占满；功能差异保留、骨架一致。
  - **耦合与口径**：`listHeaderCount()` 的 `selectMode` 分支 `1 → 0`（选择条不再是 ListItem，否则 `scrollToIndex` 换算与真实节点数不符；选择模式下拖动本就禁用，仍按真实结构修正）。音源页 ImmersiveBar `onBack` 与 `.onBackPressed` 补「选择模式先 `exitSelect()` 返回 true」（此前直接退页 / 只处理队列浮层）。歌单页说明卡右侧「取消 / 选择」三元拆成 `if (!this.selectMode) { Text('选择') }`，退出统一交给底部条「取消」；`ImmersiveBar` 副标题固定「N 个」，已选数只在底部条显示不重复；说明卡提示改「点卡片勾选，下方按钮可批量删除」。
  - **验证**：行为级 `verify_v250.cjs` **88/88**（位置顺序含「搬回顶部会失败」的反证、两页结构逐项比对、抽取改后真实 `listHeaderCount()` 去类型后执行 6 组场景、顶部口径收敛、版本与基线闸门）；守断言并入既有 AC 项（用「删除按钮在列表滚动属性之后」的顺序断言防回归），**51 项总数不变** `PASS 49 / WARN 2 / FAIL 0`。
  - **交付**：干净 release `BUILD SUCCESSFUL` → `verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 61 / 2.50` → `verifiedPassed = True`；HAP **3,741,903 字节**，SHA256 `c9c6922f9ac87abc606a0fd80e4c8c4c8686d16a43a768cd926fba1d2f489462`。包内 `.abc` 反查 `2.50 / 点卡片勾选 / 下方按钮可批量删除 / listHeaderCount / removeSheetFavorites / findMusicFreeAlternatives / isDownloaded` 全部命中；两份 rawfile 与源码逐字一致、`mf_runtime.js` 为 2.50。**基线 v2.48 保持不动**（`[0/5]` 仍复核 `b8b7e7b1…`），本轮未切基线、未重打源码包。v2.49 HAP / 图解入 `archive/hap/` 与 `archive/diagrams/`，v2.50 的 `.cer/.p7b` 入 `archive/signing-artifacts/`，根目录只留 v2.50 一组（HAP + 图解）+ `音栈-v2.48-可构建源码工程.zip`。
  - **边界（如实标注）**：沙箱无真机，选择条两行在窄屏的排版、100vp 留白在不同机型是否偏大、与全局迷你播放条的实际视觉间距、按钮热区与系统确认弹窗观感未实测；本轮只改 UI 布局与交互一致性，取链 / 自动替补 / 自检 / 播放 / 下载链路一行未改；删除仍不可恢复、勾选状态不落盘；v2.46 / v2.47 / v2.49 关于元力订阅源「第三方中转仍失效、不能出链」的结论不变。
- **v2.51 音源管理页重设计**（2026-11-10 用户诉求：「音源管理页面，你看一下能不能重新设计？现在 ui 排版界面感觉一排拉到底，好多选项，感觉有点操作也不方便，视觉上也不好。按照你的想法重新设计一版。但是要保持整体风格青绿液态玻璃」）：
  - **需求与诊断**：这是纯 UI 重设计，用户给了充分设计自由度但要求保持青绿液态玻璃。取证确认改前 `build()` 是单个 `List` 从上平铺到底，把三种不同性质的内容挤在同一滚动流：高频导入操作（3 张按钮卡）+ 低频配置（`sourceSettings()` 6 个 Toggle + 统计说明 + 全部自检 + 重建，常驻占近两屏）+ 状态概览（`sourceOverview()` 纯文字 + 汇总 + 长段提示）+ 音源卡片主体。根因是**没有信息层级、没有视觉焦点、低频设置和高频列表抢首屏空间**，不是配色问题。
  - **三层结构**：① `sourceOverview()` 重写为 Hero 状态控制台 —— 左侧 72×72 圆角「仪表芯片」用 `135°` 实体渐变 `#FF6FEBD0→#FF31C6D2→#FF2E8FE0` 叠 `180°` 上沿弧光 / 中段通透 / 下沿反光（复用 `SourceSwipeButton` 的介质光语言），中间 `FONT.display` 白色大号总数；右侧三行状态色点「N 个已就绪（success）/ N 个自检未通过（accent）/ N 个已启用（primary，新增 `enabledCount()`）」；底部一行「当前首选」+ `TinyBadge`。② 新增 `actionBar()` —— 本地导入 / 网络导入 / 全部自检 / 选择 四个 `layoutWeight(1)` 等分裸排按钮，不套玻璃卡，把原来藏在设置说明里的「全部自检」提到显眼位置，`this.checkAll()` 入口保留。③ `sourceSettings()` 重写为可折叠 —— 常驻只一条折叠头（gearshape 图标 + 「音源选项」+ `optionsSummary()` 摘要 + chevron_down `rotate`），`if (this.settingsExpanded)` 内才是统计说明卡 + 6 行开关（`preferOnlyRow`/`downgradeRow`/`verifyRow`/`fallbackRow`/`rememberRow`/`autoCheckRow` 全部原样调用）。新增 `sectionTitle()`「已导入音源 · N / 长按卡片可拖动排序」，空态不显示。
  - **默认收起是核心**：`@State settingsExpanded: boolean = false`（不落盘、重进页面默认收起，低频设置属刻意设计）。折叠头 `onClick` 切换 `this.settingsExpanded = !this.settingsExpanded`。展开后 6 个开关、统计说明、重建行与改前完全一致，`sourceStat()` / `setRememberSource` / `autoCheckSources` 等入口全部保留。`optionsSummary()` 与 `enabledCount()` 是确定性纯逻辑，行为级验证直接抽真实方法体执行。
  - **骨架零改动**：`ForEach` 前仍是恰好 2 个 `if (!this.selectMode)` 固定 ListItem（第一个 `sourceOverview()+actionBar()`，第二个 `sourceSettings()+sectionTitle()`），`listHeaderCount()` 的 `let c = this.selectMode ? 0 : 2;` 与拖动落位 `scrollToIndex` 换算不变；`cardBody`/`sourceCard`/`ghostLayer`/`swipeActions`/`menuSheet`/选择条/`ForEach` key（带 `health`/`checkedAt`）/ `statusText`/`statusColor`/`cardHint` / 替补 / 取链 / 播放 / 下载一行未动。玻璃底全页 9 处 ≥ 自检要求 6 处，四件套齐全，未引入 `backgroundBlurStyle`、无连续两次 `.border({...}).border(`。
  - **验证**：行为级 `verify_v251.cjs` **59/59**（`optionsSummary()` 真实方法体跑 6 开关 × 折叠态 64 组组合、`enabledCount()` 计数、两个固定 ListItem、折叠收起顺序含「退回一排到底」反证、Hero 芯片与玻璃四件套、守断言字符串与入口全在）；守断言并入既有 AC 项（用「6 开关必须在 `if (this.settingsExpanded)` 之后」的顺序断言防回归），**51 项总数不变** `PASS 49 / WARN 2 / FAIL 0`。
  - **交付**：干净 release `BUILD SUCCESSFUL` → `verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 62 / 2.51` → `verifiedPassed = True`；HAP **3,749,699 字节**，SHA256 `ec7164a8298324d1a4168d8a2bcb3579e45917c8e4dbdd2ce03598e7bcae7365`。包内 `.abc` 反查 `settingsExpanded / actionBar / sectionTitle / optionsSummary / enabledCount / 音源选项 / 已导入音源 / 项已开启` 全部命中（`当前首选音源` 精简成 `当前首选` 属预期非回归），既有替补 / 收藏 / 拖动符号保留；两份 rawfile 与源码逐字一致、`mf_runtime.js` 为 2.51。**基线 v2.48 保持不动**（`[0/5]` 仍复核 `b8b7e7b1…`），本轮未切基线、未重打源码包。v2.50 HAP / 图解入 `archive/hap/` 与 `archive/diagrams/`，v2.51 的 `.cer/.p7b` 入 `archive/signing-artifacts/`，根目录只留 v2.51 一组 + `音栈-v2.48-可构建源码工程.zip`。
  - **边界（如实标注）**：沙箱无真机，Hero 仪表芯片在深浅色 / 不同光感档位的观感、四个操作按钮在窄屏的文字挤压、折叠展开动画顺滑度、分区标题与迷你播放条的视觉间距未实测；本轮只改 UI 层，取链 / 自动替补 / 自检 / 播放 / 下载链路一行未改；折叠状态不落盘、重进默认收起；v2.46 / v2.47 / v2.49 关于元力订阅源「第三方中转仍失效、不能出链」的结论不变。
- **v2.52 墨栈 Inkstack 视觉风格落地**（2026-11-10 用户诉求：「那就开始把设计方案应用到工程源码构建 HAP。」；施工中追加：「现在不要听那个断言了，直接听我的。按照我说的做。」）：
  - **前置**：上一轮只交付了「墨栈 Inkstack」设计规范文档（色板 / WCAG / 组件 / ArkTS 落地方案），明确未改源码、未构建、未切基线。本轮把规范真正落到工程源码并出签名包。设计由 UI 设计全栈团队 `ui-yinzhan-vnext` 三阶段产出、经主理人独立实算复核 WCAG 35/35 一致，本轮是施工不是再设计。
  - **换肤杠杆**：`Constants.ets` 的 `glass*` 四件套被全站约 250 处调用、覆盖 20 个 `.ets` 页面。保留全部函数名 / 签名（`glassSurface` / `glassShadow` / `glassEdgeWidth` / `glassEdgeColor` / `glassDepth` / `glassRowShadow` / `glassFill` / `glassCardBase` / `lightSense`），只改返回值 → 整站从青绿玻璃切到中性纸墨实色，不必逐页改调用点。`lightSense` 四档归一（highlight / glow / ambience 全 0），设置页光感入口移除并加静态说明「界面为不反光的纸墨表面，光感选项已移除。」，符号与全站 `@StorageProp('lightSense')` 订阅保留作兼容回滚。
  - **色板与 token**：主色「信号琥珀」浅 `#FFE29A26` / 深 `#FFF3B044`；`accent` 改反相墨块、`danger` 玫红、`success` 墨绿、`text3` 深改 `#FF878D96`（card 4.77:1）；新增 `inkDividerStrong`（浅 `#FF817E7A` / 深 `#FF6E7076`）、`inkSignalText`（浅 `#FF8F4B06` / 深 `#FFF3B044`）、`INK_ON_SIGNAL`（`#FF191713`）。深色 `cardAlt` 明度阶反转为最暗内嵌井。
  - **硬编码旧色收敛**：`Shell.ets` 底栏白色反光带 / 选中片彩色投影，`SourcesPage.ets` Hero 青绿芯片 / 白色弧光 / 青蓝图标 / 蓝影白边，`HomePage.ets` 四宫格粉蓝绿橙 / 去导入白字，`Common.ets` `PlayingBars` 旧品牌蓝 / 收藏心形徽标，`FavoriteSheetsPage.ets` / `SheetDetailPage.ets` 图标块与已收藏渐变，`form/pages/PlayerCard.ets` 桌面卡片青绿底，全数换成琥珀信号或中性纸墨实色 + 1vp 发丝线 + 中性紧投影。
  - **onSignal 墨字收尾**：包内反查后逐处核对压底色，18 处白字 / 白图标压在 `this.p().primary` 或琥珀渐变上（约 2.31:1），按规范 04 节「其上文字只用墨色 onSignal」改为 `#FF191713`（7.57:1），涉及 `Common` / `DiscoverPage` / `PlayerPage` / `SearchPage` / `SheetDetailPage` / `ArtistPage` / `RankBoardPage` / `FavoriteSheetsPage` 8 个文件（空态 Action 按钮、Chip 激活态、搜索按钮、MF / 平台 chip 选中态、四处「播放全部」、换音源按钮、已收藏态、选中勾选圈）。深色 toast / 半透明黑封面角标 / `danger` 玫红 / 反相墨块徽标上的 14 行白字按压底色逐处判断后保留。
  - **守断言等价改写**：按用户「不要听那个断言，直接听我的」指令，把旧 `selfcheck.py` 为青绿玻璃写的断言（多段 rgba 渐变 / 下厚上薄描边 / offsetY ≥ 10 大投影 / 薄荷青绿染色 / 光感档位差异）改写成守护墨栈（中性实色平涂 / 1vp 等宽发丝线 / offsetY 2–4 紧投影 / 墨栈 token 齐 / 6 项旧色字面量 0 残留 / 白字压 signal 实底 0 处），并做**变异测试**（把一处墨字改回白字，守断言命中 1 处，仅内存变异未写盘）确认断言有效。断言并入既有 AC 项，51 项总数不变。
  - **验证**：自检 51 项 `PASS 49 / WARN 2 / FAIL 0`；行为级 `verify_v252.cjs` **38/38**（抽取改后真实 `Constants.ets` 方法体去类型后由 Node 执行，覆盖四档恒等 / 玻璃四件套返回值 / 色板 / 硬编码残留 / `backgroundBlurStyle` 禁令）；独立复核彩色残留 0、白色弧光 0、白字压琥珀 0、版本四处 + 运行时全 OK。
  - **交付**：干净 release `BUILD SUCCESSFUL` → `verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 63 / 2.52` → `verifiedPassed = True`；HAP **3,744,813 字节**，SHA256 `1be42ec4b675cec70b92456e9bbdcfc778abf35f8121740aa12165c78ac1ce98`。包内 `.abc` 反查新墨栈色值与 token、`界面为不反光的纸墨表面` 全部命中，旧色与 `backgroundBlurStyle` 残留 0；`mf_runtime.js`（appVersion 2.52）/ `lx_bridge.html` 与源码逐字一致，`resources.index` 音栈 6 / 洛雪 0。**基线 v2.48 保持不动**（`[0/5]` 仍复核 `b8b7e7b1…`），本轮未切基线、未重打源码包。v2.51 HAP / 图解、视觉风格规范 HTML、旧 `.cer/.p7b` 分别入 `archive/hap/` / `archive/diagrams/` / `archive/signing-artifacts/`；根目录只留 v2.52 一组 + `音栈-v2.48-可构建源码工程.zip`。
  - **边界（如实标注）**：沙箱无真机，1vp 发丝线在不同像素密度的细度、琥珀实底深浅色观感、共享元素转场帧率、读屏播报、窄屏按钮文字挤压、折叠动画顺滑度未实测；本轮只改视觉层与守断言，取链 / 自动替补 / 自检 / 播放 / 下载链路一行未改；深色主题 `danger`（`#FFE4696E`）按钮上的白字对比偏低，定稿规范未规定危险按钮文字色，本轮按「一次一个主题」未扩大改动面，留待专项；光感四档归一属「停用但保留符号壳」；v2.46 / v2.47 / v2.49 关于元力订阅源「第三方中转仍失效、不能出链」的结论不变。
- **v2.54 交互方案包 2「导航与诊断闭环」**（2026-11-10 用户诉求：「继续」，承接上轮分包计划）：
  - **前置**：包 1（v2.53 状态与反馈统一 + 新图标）已交付；本轮只做包 2，未越包。
  - **① 搜索从页面变动作**：`ui/Common.ets` 的 `PageBar` 增 `@Prop showSearch: boolean = false` + `onSearch`，`if (this.showSearch)` 条件渲染放大镜 `IconTap`；`ImmersiveBar` 透传两参。接入 4 处：`RankBoardPage` / `ArtistPage` / `SheetDetailPage` 顶栏 `showSearch: true` + `App.get().openSearch('')`；`DiscoverPage` 是一级 Tab 无顶栏，把「排行榜 / 推荐歌单」分段行由内容宽度改为 `width('100%')` 外包一层 `Row` + `Blank()` + 放大镜。**路由表 7 个名字一个未加**、`Swiper` 三页仍常驻，搜索页参数结构未改；空关键词进页面停在 idle 态等输入，不自动发请求。
  - **② 失败现场直达诊断**：`PlayerPage.failPanel()` 在两按钮行下方加一行「查看音源状态」→ `this.panel = 0; App.get().openSources()`。文字色用 `inkSignalText`（浅 `#8F4B06` / 深 `#F3B044`），不用实底琥珀压浅底（那是 v2.52 Phase 2 定的「细线型琥珀专供文字」）。故意不塞进按钮行：上面是「继续听」，这一行是「先弄明白为什么」，性质不同，四个等宽按钮会把小屏挤成一团。
  - **③ 来源显式**：`core/Player.ets` 增 `private sourceKind: string = 'normal'` + `getSourceKind()`，五类 `normal / local / substitute / manual / switch`，在 5 处赋值同步（换歌重置、本地文件、`result.altSong !== undefined ? 'substitute' : 'normal'`、手动换源、自动换源）。`PlayerPage.topBar()` 在替补 / 手动 / 自动三类时给来源行左侧加 2×11vp 琥珀竖线，替补态文字提到 `text` 色。**不改 `result.from` 生成逻辑** —— 「· 插件替补」后缀仍由 `Resolver` 拼，那一行未动。
  - **④ 部分失败显式化**：`SearchPage.searchSongsBySource()` 去掉内部 `.catch(() => [])`（吞掉之后上层分不清「没搜到」和「源挂了」），异常向上冒；歌曲 / 歌单 / 歌手三个 tab 各自 `catch` 并 `fails.push(this.sourceLabel(id))`，完成后 `this.failedSources = fails`；新增 `sourceLabel()`（插件源取插件名、平台源取 `platformShort`，都查不到时兜底「MusicFree 插件」）与 `sourceFaultBar()`（「N 个源本次没返回结果」，点开看名单，`bgSoft` 底 + 1vp `line`，不引新色）。`loadMore` 保留单源兜底，避免一个源抛错把整页成功结果一起丢（原来每个 task 自带 catch，拆掉后必须在外层补）。
  - **⑤ 守断言**（`scripts/selfcheck.py` AC 块内追加，**不新增检查项，51 项守恒**）：PageBar 三处锚点（`@Prop showSearch` / `if (this.showSearch)` / `showSearch: this.showSearch`）；三个二级页 `showSearch: true` + `openSearch('')` 齐备且**计数必须 = 3**，`onBackPressed` 仍 = 3；发现页入口存在；**路由名集合硬等于 `artist,downloads,favoriteSheets,rankboard,search,sheet,sources`**（多一个即 FAIL，这正是「搜索是动作不是页面」的可执行证据）；失败面板 `Text('查看音源状态')` + `openSources()` + `inkSignalText`；`sourceKind` 六锚点；`searchSongsBySource` 内**不得再出现** `searchMusicFree(id.substring(3), word, page).catch(`；`failedSources` / `sourceLabel` / `failedSources = fails` / `sourceFaultBar()` 四锚点。
  - **验证**：干净 release `BUILD SUCCESSFUL`（33 tasks）→ `verify-app success` + `Digest verify result: true` → 双向 `com.yinzhan.music / 65 / 2.54` → `verifiedPassed = True`；HAP **2,971,944 字节**，SHA256 `cf323e1a427557e21eb810c7e14f6ec8c06f7e6176bdd890d7ea79d11fde2e06`。行为级 **13/13**（`sourceLabel` 六种映射、五类来源取值集合、单源搜索无 catch、三 tab 各记一次、翻页兜底存在）；变异测试 **6/6 全部被拦截**（删诊断出口 / 路由表加 `diagnose` / catch 复活 / 榜单页漏接搜索 / 撤发现页入口 / 手动换源不记类型）；包内 `.abc` 反查 `showSearch / 查看音源状态 / sourceKind / getSourceKind / substitute / failedSources / sourceLabel / sourceFaultBar / 个源本次没返回结果` 全命中，旧口径「自检完成：通过」残留 0；`mf_runtime.js` 与 `lx_bridge.html` 逐字节一致。**基线 v2.48 保持不动**（`[0/5]` 仍复核 `b8b7e7b1…`）。
  - **不碰**：`Resolver.ets`（两阶段取链 / `MF_FALLBACK_MAX = 6` / `healthRank` / `result.from`）、`Constants.ets`（墨栈 token 一个值未改）、`SourceRepo.ets`、`Library.ets`、`PlayerCard.ets`、`Swiper` 三页常驻、失败面板原三按钮文案与行为、搜索的版本合并 / 分页 / 上拉加载。
  - **未实测**（沙箱无真机，一律不写成「已通过」）：顶栏放大镜压在沉浸式渐变头部 / 深色封面下的可读性；空关键词进搜索页后软键盘是否自动弹出、光标是否落位；部分失败提示条在窄屏 + 多源同时失败时的换行高度；失败面板多一行后小屏弹层（`FIT_CONTENT`）是否触发内滚；「查看音源状态」40vp 仍低于 48vp 触控下限（留包 4 统一处理）。
- **v2.53 交互方案包 1「状态与反馈统一」+ 新应用图标**（2026-11-10 用户诉求：「按照刚刚制定的方案，开始执行吧。另外把应用图标换一下，现在更改过的 UI 界面不适合原本的图标了。」，同批给出深浅两版 1600×1600 图标原图）：
  - **前置**：上一轮只交付《音栈 · 交互逻辑重设计说明（v2.53 预案）》，把落地拆成五包（v2.53 状态与反馈 → v2.54 导航与诊断闭环 → v2.55 返回与选择统一 → v2.56 无障碍与响应式 → v2.57 大屏索引栏待定）。本轮只做包 1，未越包。
  - **状态形状冗余**：新增 `enum SourceMark`（PASS / WARN / WAIT / IDLE）与 `statusMark(item)`，判定优先级照抄 `statusText()`（自检中 → 装载失败 → 载入中 → 已载入看结论 → 其它），保证形状 / 文案 / 色相三者同源，不会出现「形状说通过、文案说未通过」。新增 `@Builder markGlyph()`，用 `Shape` + `Path` 在 16×16 视图坐标自绘四档：实心圆 + 挖空对勾（通过）/ 实心三角（不可用、未通过）/ 空心方（自检中）/ 空心圆（未检测）。**不用字体字形**（不同设备对 ●✓△□ 覆盖不一致会画出豆腐块），**不引新色**（取色仍走 `palette`）。卡片状态行 13vp、顶部概览 12vp，同一套几何按尺寸等比缩放。
  - **形状实现取舍**：三角做成实心、省掉感叹号——13vp 里再塞一个「!」必然糊成一团，实心三角本身已是「警告」最强的几何语义，配合右侧固定文案足够读懂。方案 5.1 表格写的是「△!」，此处如实标注实现差异。
  - **顶部概览口径收紧**：`okCount` 从 `status === 'ok'`（脚本装载成功即算「已就绪」）收紧为 `status === 'ok' && health === 'ok'`，与卡片「正常」同一判定；概览由 3 行变 4 行（N 个自检通过 / N 个自检未通过 / N 个已就绪未自检 / N 个已启用），前三行互斥、加起来等于「脚本已载入」的源数，第四行是配置计数用方点区分。这条修的是 v2.47 同类残留——顶部数字好看、卡片却写着「已就绪 · 未自检」。
  - **时间上下文**：新增 `relativeCheck(at, now)` / `checkStale(item, now)` / `checkLabel(item, now)` 与 `CHECK_STALE_MS`（24h）。已自检的卡片底部加一行「上次自检 3 小时前」，超 24h 变 `accent` 并追加「· 可能已过时」；页面内 60 秒定时器推进 `nowTs`，`aboutToDisappear` 清理。**放独立一行而不是状态行**：状态行还要容形状、状态文案、首选徽标与版本号，360vp 屏余量不足 60vp，挤进去必然把版本号顶掉。
  - **L3 持久结果区**：新增 `interface CheckReportRow` 与 `@State reportAt / reportTotal / reportOk / reportSkipped / reportFailed / reportClosed`（摊成基础字段，不用嵌套对象，避开 ArkUI 对深层字段的刷新盲区）；`checkAll()` 结束后把 `CheckSummary` 摊成一张可复查的卡（形状 + 汇总 + 逐条失败原因 + 相对时间 + 关闭按钮），挂在概览与操作行之间。`SourceRepo.checkAll()` 的返回结构、判定逻辑、持久化一行未改——本轮只负责把已有结论显示出来。
  - **措辞统一**：批量自检 toast `自检完成：通过 3 个 · 未通过 1 个` → `自检完成：3 个正常 · 1 个自检未通过[ · 跳过 N 个平台]`；单源 toast `X 自检通过` → `X 正常`；概览「N 个已就绪」→「N 个自检通过」。
  - **守断言**：`selfcheck.py` 既有 AC 块内追加 21 条包 1 断言（四档枚举 / 形状判定函数 / 卡片与三处概览调用点 / 相对时间三函数 / 结果区结构与挂载 / 概览文案口径）与 1 条「6vp 状态圆点不许复活」正则，不新增检查项，51 项计数不变。`markGlyph` 加入既有 `EXEMPT`（形状走静态 if/else 两条调用，实参只有 `this.p()` 这一层主题取色，与 `glow` / `glassHighlight` 同类）。
  - **应用图标换新**：两张 1600×1600 原图（深色 IMG_2738 / 浅色 IMG_2737）LANCZOS 缩放到 1024 写入四处 `app_icon.png`（`AppScope/resources/<base|dark>/media/` 与 `entry/src/main/resources/<base|dark>/media/`，两处缺一会有一端仍显示旧图）；`start_window_icon.png` 用既有 `scripts/icon/make_start_window.py` 径向淡出重生成 640。启动窗口底色改取图标外圈实测中位色（浅 `#FFFCF2DF` / 深 `#FF2E2E2D`，原为青绿系 `#FFDCEDEB` / `#FF0A1E2A`）；顺带修 v2.52 换肤时漏改的窗口背景（`#FFF5F6F9` / `#FF0B0C10` → 与 `palette.bg` 一致的 `#FFF1EFEA` / `#FF0F1116`）。**图标体积**：四张从 2,246,292 降到 1,439,702 字节，是本版 HAP 变小 78 万的主因（`.abc` 实际 +15,136），包内条目集合与 v2.52 完全一致、无资源丢失。
  - **验证**：自检 51 项 `PASS 49 / WARN 2 / FAIL 0`；行为级 `verify_v253.cjs` **44/44**（从源码切出 `statusMark` / `statusColor` / `statusText` / `relativeCheck` / `checkStale` / `checkLabel` 的真实函数体、剥类型后交 Node 执行，覆盖 7 个状态分支的形状文案颜色三者一致、四档全覆盖、相对时间 11 个边界含未来时间、24h 阈值边界、状态行后缀三形态）；**变异测试 4 组全部命中**（形状退回 6vp 圆点命中 2 条，删时间行 / 概览退回含糊口径 / 结果区不挂载各命中 1 条，仅内存变异未写盘），确认守断言不是假通过。
  - **交付**：干净 release `BUILD SUCCESSFUL` → `verify-app success` + `Digest verify result: true` → 双向版本 `com.yinzhan.music / 64 / 2.53` → `verifiedPassed = True`；HAP **2,955,532 字节**，SHA256 `263877c750689b141301bc145a89501672839bf7fd3fe33bdd2d6ad76a7da33b`。包内 `.abc` 反查 `SourceMark / markGlyph / relativeCheck / checkStale / checkLabel` 与「上次自检结果 / 可能已过时 / 个自检通过 / 个已就绪未自检 / 个平台因脚本错误跳过」全部命中，旧口径文案残留 0；4 张图标与两份 rawfile 与源码逐字节一致。**基线 v2.48 保持不动**（`[0/5]` 仍复核 `b8b7e7b1…`），本轮未切基线、未重打源码包。v2.52 HAP / 图解与旧 `.cer/.p7b` 分别入 `archive/hap/` / `archive/diagrams/` / `archive/signing-artifacts/`；根目录只留 v2.53 一组 + `音栈-v2.48-可构建源码工程.zip`。
  - **边界（如实标注）**：沙箱无真机，13vp 形状在 1.5× 字体与不同像素密度下的清晰度与抗锯齿、桌面圆角蒙版裁切后新图标四角与圆形光晕的观感、启动窗口底色到首帧页面的亮度过渡、60 秒定时器在长时间后台后的唤醒行为未实测；`Constants.ets` / `SourceRepo.ets` / `Resolver.ets` / `Library.ets` / `PlayerCard.ets` 零改动，取链 / 自检 / 替补 / 收藏 / 下载算法一行未改；包 2–5 未开始（包 5 大屏索引栏仍需先确认是否恢复）；v2.46 / v2.47 / v2.49 关于元力订阅源「第三方中转仍失效、不能出链」的结论不变。
- **十八版总览**：v2.37（48）封面链路修复 → v2.38（49）质感入口下线 → v2.39（50）数据说明与备份范围 → v2.40（51）MusicFree 音源支持 → v2.41（52）MusicFree 订阅与布局修复 → v2.42（53）MusicFree 全订阅源适配 → v2.43（54）MusicFree 就绪状态解耦 + 元力订阅适配 → v2.44（55）MusicFree 歌单与歌手搜索 → v2.45（56）MusicFree 取链替补 + 下载完成态 → v2.46（57）MusicFree 取链失败如实反馈 → v2.47（58）自检结论如实显示 → v2.48（59）音源多选批量删除 → v2.49（60）双体系自动替补优化 + 歌单收藏多选删除 → v2.50（61）选择条统一下方 → v2.51（62）音源管理页重设计（Hero 控制台 / 一行四操作 / 选项折叠 / 列表分区） → v2.52（63）墨栈 Inkstack 视觉风格落地（纸墨实色 / 信号琥珀 / onSignal 墨字 / 守断言等价改写） → v2.53（64）交互方案包 1 状态与反馈统一 + 新应用图标（形状冗余 / 概览口径收紧 / 时间上下文 / L3 结果区 / 图标换新） → v2.54（65）交互方案包 2 导航与诊断闭环（顶栏搜索动作 / 失败面板直达音源管理 / 来源类型标记 / 部分失败可见），每版一个主题一个包；v2.53 及更早的 HAP / 图解入 `archive/hap/` 与 `archive/diagrams/`，根目录只留 v2.54 一组（HAP + 图解 + `音栈-v2.48-可构建源码工程.zip`，后者是 v2.48 基线切换时交付的源码包，本轮未重打故保留）。**仍未做**：设置项搜索、播放小件（需先按铁律 1 评估 `AVPlayer` 能力边界）、全局字号 / 无障碍、服务卡片交互增强。
- **下一个新功能版本从 v2.55（66 / 2.55）起算**，对应交互方案的包 3「返回与选择统一」（返回优先级链收敛为单一入口 / `SelectionBar` 公共组件 / 下载页不可达状态机清理）。

## 必读文档（在 `yinzhan-ai-handoff/`）

| 文件 | 何时读 |
| --- | --- |
| `01-CONTEXT.md` | 第一个读，单一事实来源 |
| `04-RULES-AND-PITFALLS.md` | 动手前必读，铁律与坑 |
| `02-HISTORY.md` | 需要理解决策背景时 |
| `03-BUILD-SOP.md` | 出包前照着跑 |
| `MANIFEST.json` | 核对文件与 SHA256 |

注意：`LXMusicHarmony/README.md` 停在 `v4.0.48` 老版本线、`音栈-后续开发方向与功能规划-v2.4起.md` 写于拆除前（仍写 `14/2.3` 与「统计」组），**都已过时**，别被带偏。

## 铁律

1. 改需求前**先评估**「能不能做、会不会崩」；评估不行就明确不做。
2. **按真实的，不要模拟**：统计只读真实数据，不造数、不用定时器假增量；拿不到真实值就标「估算」或砍掉。
3. 大改前打**隔离快照**并报 SHA256；每轮出包前复核 **v2.39 基线 HAP** 的 SHA256（`archive/baseline/`），v2.21 及更早基线已作废、不再复核。
4. 版本号**四处同步**：`AppScope/app.json5`、`SettingsPage.APP_VERSION`、`build_release.sh`、`selfcheck.py`。
5. 用户靠「**设置 → 关于 看到新版本号**」确认安装成功。
6. 出包走 `scripts/env/build_release.sh`：干净构建 → 签名 → 验签 → 版本双向核对 → 自检 → 包内符号反查 → 配图解。
7. 根目录只留最新 HAP，旧包入 `archive/`；交付优先系统分享，超时就如实说明并改文件交付。
8. 一次一个主题、一次一个包；同类列表/卡片复用同一套组件与青绿玻璃四件套（`Constants.ets`）。
9. 一级页常驻不销毁 → 跨页刷新必须 `AppStorage` + `@StorageProp/@Watch`；新增二级页必须挂 `.onBackPressed(() => App.get().consumeBackIfQueueOpen())`。
10. 用**简体中文**回复。

## 交付呈现约定（用户 2026-11-07 指定，后续一律照此）

用户对比两张界面截图后明确要求：**后续每次有最新产物，都按「图二」给** —— 像交付 v2.14 那次一样，在回答里直接列出当次最新的那一组文件，一眼可点开，不必去「全部产物」里逐个翻找。

1. `present_files` 只传本轮新生成的产物，通常是「最新 HAP + 随包图解」这一组（1~2 个文件）。
2. 以下文件不进交付，只留 `archive/`：资源图（如 `app_icon.png`）、构建中间产物、旧版本 HAP 与旧图解、签名副产物（`.cer` / `.p7b`）、隔离快照 ZIP、构建日志、历史评估/说明文档。
3. 根目录保持「最新 1 个 HAP + 随包 1 个图解」，其余 HTML 一律移入 `archive/diagrams/`。
4. 一次交付只给当次最新一组文件，不把多个文件铺在回答里。
5. 事实边界：App 端「全部产物 (554)」是历史累积入口，本地归档不会减少其计数；本约定约束此后每次新增交付的形式。

## 不要碰

- **任何形式的免流混淆 / 代理伪装**（伪造 Host/SNI 指向 `dm.toutiao.com`、自建中转、走代理规避计费）——已连续多轮拒绝并翻篇，不重新评估、不给替代实现、不进路线图。
- 账号/云同步、猜你喜欢推荐、继续接新平台、桌面/Web 端、音源链路一次性全量重构。
- **不要恢复 v2.29 已整套移除的「为你整理 / 本机分类 / 首页编排」**（用户判定「没什么用」）；也不要恢复听歌识曲、沉浸光感 / 流光、统计看板 / 月报告、自建歌单入口。
- **不要恢复设置页「质感」档位入口**（v2.38 按用户决定移除：功能保留、默认锁最强浓郁 3、不要入口）；数据说明不要再写回「自建歌单」，备份范围说明必须包含音源脚本。
- 不要为了"全绿"修那 2 项历史 WARN；不要直接删掉 `AS/AV/AW` 的拆除确认断言。
- `archive/baseline/` 下 v2.39 的三份基线产物（HAP / 源码快照 / 图解）：禁止移动、删除、覆盖，也不许当「旧包」挪进 `archive/hap/`。`archive/baseline/legacy/` 只放作废基线，禁止当基线引用。

## 技术栈红线

工程只接受 **ArkTS 原生**实现。React / Tailwind / Recharts / Framer Motion 代码照抄会**编译失败（不是崩溃）**；
图表用 `Canvas` 自绘。解压/工程路径必须纯英文。


---

## 接手必读 · 2026-11-13 v1.0（版本号归 1 / 下载文件内标签 / QQ·酷狗账号连根删除）

本轮一次性处理用户三条诉求，**当前有效版本即本版**（上一版 v2.80「去除青绿液态玻璃」已归档）。

**1. 版本号改为 1.0（四处 + 运行时串全部同步）**
- `AppScope/app.json5`：`versionName` = `1.0`；**`versionCode` 保持 67 不回退** —— 回退会让真机覆盖安装被系统拒绝（用户可见版本已是 1.0）。如用户坚持连内部序号一起归 1，需明确提示须先卸载旧版。
- 同步改动：`SettingsPage.APP_VERSION = '1.0'`、`entry/src/main/resources/rawfile/vendor/mf_runtime.js` 的 `appVersion` / `process.version`、`build_release.sh` 的默认产物名与 `[3/5]` 断言、`selfcheck.py` 的 AJ/AL~AS 组版本断言（现锁 `67/1.0`）。
- 注释里大量 `v2.56` 是**历史批次标记，不是版本号，一律保留**（别误改）。

**2. 下载歌曲写入「文件内」元信息 + 歌词（排查结论 + 实现）**
- 排查：`Downloader.ets` 以前只 `copyFileSync` 原始字节，歌名/歌手**仅在文件名与 App 下载记录里**，拷到别的设备就是「未知标题/未知歌手/无歌词」。用户判断属实。
- 新增 `core/AudioTag.ets`（纯 ArkTS / 零三方依赖，约 380 行）：
  - mp3 → **ID3v2.3**：TIT2 标题 / TPE1 歌手 / TALB 专辑 / **USLT 歌词（LRC 原文）**；`parseId3Frames` 保留原有 APIC 封面等无关帧、`stripId3` 剥离旧标签保证幂等。
  - flac → **Vorbis Comment 块**：TITLE / ARTIST / ALBUM / **LYRICS**；`parseFlac` 合并已有 comment、重设 last-metadata-block 标志、音频帧字节原样追加。
  - m4a / ogg / wav / unknown：**不动音频字节**（手写 atom/page 结构风险高），只落同名 `.lrc`。所有格式都额外写一份同名 `.lrc`。
  - `rewrite()` 整体重写 + **失败回滚原字节**；`embed()` 幂等，可被重复调用。
- `Downloader.run()`：落盘后先同步写元数据（零延迟、不等网络），再由 `embedLyricLater()` 用 `LyricRepo.get().get(song)` 异步补歌词（优先用 `song.lyric` 自带 LRC），`toLrcText()` 还原标准 LRC。全部 try/catch，**标签失败绝不影响下载结果**。
- 已用 `ffprobe` 等价字节实现实测：ID3v2.3 识别 `lyrics-eng`、FLAC 识别 `LYRICS`，二次写入字段不重复，`ffmpeg` 解码校验通过。新增自检 `CE` 组锁死。
- **ArkTS 坑**：`fs.openSync()` 返回 `File` 对象，`readSync/writeSync` 必须传 `.fd`（本轮首次构建 10505001 就栽在这里）。

**3. QQ / 酷狗「账号登录体系」连根删除（不是只隐藏）**
- v2.71 起账号页只留网易云，那批代码一直只是隐藏、无人引用。本轮删除 7 个文件：`QqAccount.ets` / `QqApi.ets` / `KgAccount.ets` / `KgApi.ets` / `KgDevice.ets` / `AccountCrypto.ets` / `ui/pages/PlatformAccountPanel.ets`。
- `FavSyncHub.ets` **重写**（861 → 约 230 行）：删掉整个 `FavSyncEngine`（qq/kg 通用引擎），只代理 `WyFavSync`；**保留** `FavSyncStatus` / `status(scope)` / `label(scope)` / `toastText(scope)` / `reconcileAllAwait()` / `anyLoggedIn()` / 前台 12s 心跳 `startForegroundSync·stopForegroundSync·scheduleHeartbeat`（用户要的实时同步不能丢）。`scope='qq'/'kg'` 返回中性空态兼容旧调用。
- 清理引用：`App.ets`（2 个 import + init）、`Library.ets`（qqFavHook/kgFavHook 及分发分支）、`Constants.ets`（QQ_*/KG_* PrefKeys）、`SettingsPage.ets`（qqNick/kgNick）、`FavoriteSheetsPage.ets`（6 个 @StorageProp + reconcileQqKg）、`HomePage.ets`（reconcileQqKg + 悬空 import）、`WyAccountPage.ets`（注释）。
- **红线：删的是「账号登录」，不是「音源平台」**。`Platform.ets` 的 `tx`(QQ音乐)/`kg`(酷狗音乐)、`PlatformApi.ets` 的 `c.y.qq.com` / `m.kugou.com`、`DiscoverFeed` 的 tx/kg 板块、以及用户已收藏的 tx/kg 歌单数据**全部保留**。落包反查 `c.y.qq.com` 6 次、`m.kugou.com` 3 次在。
- 自检：`BK`（QQ/酷狗账号链路）、`BL`（P0 扫码修复）两组整组删除；`BP` 收口为仅 wy 但守住「状态不撒谎 + 前台定时对账」；`BR` 只保留「收藏页心形角标可点」通用 UI 断言；新增 `CD` 组锁死账号零残留 + 音源保留。

**验证 / 交付**
- 自检 **76 项：PASS 74 / WARN 2 / FAIL 0**（两条 WARN 仍是 themeMode / activeSourceName 冗余广播，按约定不修）。
- API 26 release `BUILD SUCCESSFUL`；`pack.info` / `module.json` 双向 `67 / 1.0`；`sign-app` / `verify-app` / `verify-profile` 全 success，`compatibleVersion 26`。
- 落包反查：账号体系 18 个关键词（QqAccount…fcg_qm_order_diss / v4_qq_ / glassTheme / 2.56）**全 0**；`USLT/TIT2/TPE1/TALB/LYRICS=/fLaC/.lrc/AudioTag` 与音源接口字符串全部在。
- 边界（不变）：沙箱无真机，装机后需确认「设置→关于」显示 1.0、下载后在系统音乐 App 里能看到歌手与歌词；正式分发须用 AGC 正式 profile 重签 `-unsigned.hap`；第三方平台同步仍非服务端推送级实时。


---

## 接手必读 · 2026-11-13 v1.0a（歌词改为纯内嵌 / 下载只出单文件）

**用户反馈**：「我要求的是文件下载歌词，以为是内嵌到歌曲中的，现在实现的是另外又下了一个 LRC 文件。内嵌不行吗？不行就把另外下载歌词的选项取消，只下载单文件歌曲。」

**澄清结论（重要，别再搞错）**：歌词**本来就已经内嵌**在歌曲文件里了 —— mp3 的 ID3v2.3 `USLT` 帧、flac 的 Vorbis Comment `LYRICS` 字段，上一轮已用 ffprobe 验证可识别。用户看到的「第二个文件」是上一版额外多加的**同名 `.lrc` 外挂兜底**（想兼容只读外挂歌词的播放器），正是它让人误以为歌词没内嵌。所以本轮不是「新做内嵌」，而是**去掉多余的 .lrc，回归单文件**。

**改动**
- `core/AudioTag.ets`：
  - `embed()` 里删掉 `if (lyricLrc.length > 0) AudioTag.writeLrcFile(...)`，改为无条件 `AudioTag.removeSidecarLrc(path)`。
  - `writeLrcFile()` 整个函数替换为 `removeSidecarLrc()`：只 `fs.unlinkSync(同名 .lrc)` 清掉**旧版本遗留**的那一份，不扫描目录、不碰其它文件、不存在时静默忽略（新版本根本不写，绝大多数是文件不存在）。
  - 头注释与四条硬约束同步：下载目录始终只产出「一个」歌曲文件；mp3/flac 歌词内嵌在文件内部；其余格式不带歌词也不多出文件。
- `core/Downloader.ets`：三处注释去掉「落同名 .lrc」，补一句「不会产生第二个文件」。**取词 / 二次 embed / 幂等逻辑一行未动**。
- 播放器本地歌词走 `LyricRepo` 网络+缓存，全工程**没有任何读 `.lrc` 文件的代码**，删外挂不影响 App 内播放歌词（已全局 grep 确认）。

**格式边界（如实告知用户，别打包票）**
| 格式 | 文件内元数据 | 文件内歌词 | 额外文件 |
| --- | --- | --- | --- |
| mp3 | ID3v2.3 TIT2/TPE1/TALB | ✅ USLT（LRC 原文） | 无 |
| flac | Vorbis TITLE/ARTIST/ALBUM | ✅ LYRICS | 无 |
| m4a / ogg / wav / 未知 | 不改字节 | ❌ | 无 |
- m4a(MP4) 内嵌要重建 `moov.udta.meta.ilst` 并重算 `stco/co64` chunk offset，ogg 要重算 page CRC，纯 ArkTS 手写风险高、易毁文件，且沙箱无真机验证 —— 按用户「不行就取消」的兜底口径，这些格式不带歌词但也不产出第二个文件。若后续用户要求 m4a 也内嵌，需单独评估、务必带 ffprobe/ffmpeg 字节校验。
- 内嵌的是**带时间轴的 LRC 文本**（USLT / LYRICS），不是逐字 SYLT；系统音乐 App / 华为音乐对 USLT 的显示支持因版本而异，装机需实测。

**自检**：`CE` 组把「必须存在 `.lrc` / `writeLrcFile`」两条断言**反转成禁止存在**，新增 `removeSidecarLrc` / `fs.unlinkSync(lrcPath)` 断言和 Downloader 注释断言，PASS 文案改为锁死「单文件 + 歌词内嵌 + 零外挂」。

**红线**：后续不要以「兼容播放器」为由再加回外挂 `.lrc` —— 用户明确要的就是只下载单文件歌曲。


---

## 接手必读 · 2026-11-14 v1.0b（并行下载可配置 / 下载管理页就地设档位）

**用户反馈**：「现在把下载设置改成可以并行下载。一下子下载几个音乐，只有一个是正在下载中，其他都是排队中。增加个选项，可以设置成同时几首歌下载。」

**排查结论（别再误判）**：下载器**本来就有并发机制**，`pump()` 是 `while (running < maxRunning && queue.length > 0)` 的标准并发泵，取链 `Resolver.resolve()` 按「歌+音质」去重（`inflight` Map），不同歌互不阻塞。真正卡住的是两点：
1. `private maxRunning: number = 2` **写死为 2**，且**没有任何设置入口** —— 用户下 5 首只能有 2 个「下载中」，其余显示「排队中」（`DownloadsPage.statusText` 里 waiting→「排队中」、running→进度）。
2. `pump()` 只在 `enqueue()` 入队和 `run().finally()` 任务完成时触发。即使以后加了设置，只改上限、不主动 pump，用户把 1 调到 5 也得等当前这首跑完才见效，看起来像没生效。

**改动（4 个文件 + 自检）**
- `common/Constants.ets`：`PrefKeys.DOWNLOAD_CONCURRENCY = 'v4_download_concurrency'`；类外新增 `DOWNLOAD_CONCURRENCY_MIN=1 / MAX=5 / DEFAULT=3`。MAX=5 是经验上限（系统 DownloadTask 槽位 + 多源取链风控），MIN=1 保留退回串行的路，DEFAULT=3 比旧的 2 更能体现「批量一起下」。
- `core/Settings.ets`：`downloadConcurrency()` / `setDownloadConcurrency(value)`，读写都做 `Math.round` + clamp，用 `if (!(n >= MIN))` 顺手兜住 NaN / 脏值（ArkTS 严格子集，避免 `Number.isFinite` 的兼容风险）。
- `core/Downloader.ets`：
  - 字段 `maxRunning` 初值改为 `DOWNLOAD_CONCURRENCY_DEFAULT`，**删除写死的 2**；头注释同步。
  - `init()` 里 `this.maxRunning = Settings.get().downloadConcurrency();`（`Store.get().init()` 在 `App.init` 中先于 `downloads.init()`，读回安全）。
  - 新增 `concurrency(): number` 供页面读当前档位。
  - 新增 `setConcurrency(value)`：`Settings.setDownloadConcurrency()` 落盘 → 更新 `maxRunning` → **`notify()` + `pump()`**。最后这个 `pump()` 是本轮关键，让排队任务在改设置瞬间补位启动；调小档位不中断正在跑的任务，等 `running` 自然降下来收敛（不kill下载）。
- `ui/pages/DownloadsPage.ets`：`statCard()` 与 `downloadsToolbar()` 之间插入 `concurrencyCard()` —— 标题「同时下载」+ 当前档位 + 5 个 `Chip`（文案用纯数字 `'1'~'5'`，**不要写「N 首」**：5 个三字 Chip 在窄屏会挤爆一行）。点 Chip → `applyConcurrency(n)` → `App.get().downloads.setConcurrency(n)` → `refresh()` + toast。`@State concurrency` 在 `refresh()` 里从单例同步，`aboutToAppear` 首帧即对齐。
- 放**下载管理页**而非设置页：用户正是在这页看到一堆「排队中」，就地改档位、立刻看到几条同时变成下载中，反馈闭环最短。

**未改动 / 红线**：取消 / 重试 / 批量删除 / 清空、`AudioTag` 单文件内嵌歌词、`markCancelled` 痕迹、`request.DownloadTask` 的 `finally delete()` 槽位释放 —— 一律没碰（CF 组锁死）。别为了「更并行」去调大 `pump()` 之外的取链并发或删 `inflight` 去重，那会撞平台风控并重复请求。

**自检**：新增 `CF` 组（`check_download_concurrency`），锁死常量/PrefKey/Settings clamp、Downloader 无写死 2 / init 读回 / `setConcurrency` 必须落盘+`pump()`+`notify()`、页面 5 档 Chip 接 `setConcurrency`、既有链路保留。全量 **77 项：PASS 75 / WARN 2 / FAIL 0**（两条 WARN 仍是 themeMode / activeSourceName 冗余广播，按约定不修）。

**验证 / 交付**：API 26 release `BUILD SUCCESSFUL`；签名/验签/profile 全 success；版本仍 `67 / 1.0`。沙箱无真机，装机后需确认：一次下 5 首 → 默认 3 个同时「下载中」；点「5」→ 排队任务立刻全部启动；杀进程重进档位保持；点「1」→ 回到串行。


---

## 接手必读 · 2026-11-14 v1.0c（档位改「− 数字 +」步进器 / 卡片瘦身）

**用户反馈**：「同时下载占用太大，把调数字改成左减右加式，同时下载那一栏右面位置卡片缩小。」

**结论**：v1.0b 那张卡是「标题 + 两行说明 + 横排 5 档 Chip」，整卡近 170vp，在下载管理页挤掉约四分之一屏。本轮**只改 UI**，Downloader / Settings / Constants 的并发逻辑（1~5、默认 3、落盘、改完立即 pump）一行未动。

**改动（2 个文件）**
- `ui/pages/DownloadsPage.ets`：
  - `concurrencyCard()` 由两层 Column 压成**单行 Row**：左边 `Column`（「同时下载」+ 一行小字「调大后排队任务立即开始」，`layoutWeight(1)`），右边 Row 放 `Text('-')` / `Text(this.concurrency + ' 首')` / `Text('+')`，`space=6`。减号加号用 `padding({left:9,right:9,top:3,bottom:5})` + `RADIUS.pill` 做小胶囊，**不用固定 height + align**（老 API 上 Text 垂直居中不稳）。
  - 根 Row 改 `padding({ left: 14, right: 10, top: 9, bottom: 9 })`（原 16）+ `alignItems(VerticalAlign.Center)`，整卡高度约 50vp；glass 背景/描边/阴影与 `statCard()` 保持一致，没换风格、没缩宽度（宽度仍满行才和上方统计卡对齐）。
  - 到 1 / 5 边界时按钮 `opacity(0.4)` + `text3` 置灰；`applyConcurrency(n)` 开头加 `if (n < MIN || n > MAX) return;` 双保险 —— 越界点击静默无反应，不弹 toast、不落盘。
  - import 去掉 `Chip`，新增 `DOWNLOAD_CONCURRENCY_MIN / MAX`。**别改回 5 档 Chip，也别把两行说明加回来**。
- `scripts/selfcheck.py`：`CF` 组 ③ 从「必须有 5 档 Chip」**反转成禁止** `Chip({` / `text: 'N', active: this.concurrency`，新增减一/加一、MIN/MAX 常量、卡片收窄 padding 断言，PASS 文案同步。全量仍 **77 项：PASS 75 / WARN 2 / FAIL 0**。

**红线**：并发上限始终取自 `Settings.downloadConcurrency()`，别因为 UI 变步进器就写死数字或去掉 clamp；`setConcurrency()` 末尾的 `pump()` 是上一版关键，删了「调大档位排队任务立刻启动」就失效。


---

## 接手必读 · 2026-11-14 v1.0d（「忽略音频打断」真正生效 / 根因是 API 用错）

**用户反馈**：播放设置里「忽略音频打断」打开后，其它应用一播放，本应用照样暂停。

**排查结论（别再按旧思路改）**
1. `AVPlayer.audioInterruptMode` **只决定同一应用内多条音频流的焦点归属**，管不了跨应用。官方《音频焦点和音频会话介绍》：SHARE_MODE「仅当其他应用创建的音频流与该应用的音频流同时播放时，才会触发音频焦点策略的管理」、INDEPENDENT_MODE「每个音频流均独立拥有一个音频焦点」。两者都不阻止别的 App 抢焦点。
2. 跨应用的 `INTERRUPT_HINT_PAUSE / STOP` 是 **INTERRUPT_FORCE（系统强制执行）**，应用只能在 `audioInterrupt` 回调里收到通知、同步 UI，**无法拒绝**。旧代码 `if (token !== this.token || Settings.get().ignoreInterrupt()) return;` 以为「不处理事件」=「不被打断」，正是功能失效的原因。
3. 雪上加霜：`audioRendererInfo` / `audioInterruptMode` 被设在 `createAVPlayer()` 之后的 **idle 状态**。官方 AVPlayer 文档：`audioRendererInfo` 只允许 `initialized`（首次 `prepare()` 前）、`audioInterruptMode` 只允许 `prepared/playing/paused/completed`（首次 `play()` 前）。idle 设置被忽略，两个属性从头到尾没生效过。

**正解**：`AudioSessionManager.activateAudioSession({ concurrencyMode: CONCURRENCY_MIX_WITH_OTHERS })` —— 官方「播放音乐，希望共存」方案，让本应用的音频流与其它应用混音共存、不参与焦点抢占。API 26 SDK `@ohos.multimedia.audio.d.ts` 已确认存在（since 12；`AUDIO_SESSION_SCENE_MEDIA` since 20）。

**改动**
- `core/Player.ets`：
  - 新增 `audioSession: audio.AudioSessionManager | null`、`interruptResumeAt`；`init()` 里 `audio.getAudioManager().getSessionManager()`，注册 `on('audioSessionDeactivated')`（系统超时 / 抢占释放后按开关重新激活），并首次同步；`shutdown()` 释放会话。
  - 新增 `syncAudioSession()`：开→`setAudioSessionScene(MEDIA)` + `activateAudioSession(MIX_WITH_OTHERS)`（幂等 `isAudioSessionActivated()`），关→`deactivateAudioSession()`。
  - `audioRendererInfo` 移到 `stateChange` 的 `initialized` 分支、`prepare()` 前；`audioInterruptMode` 移到 `prepared` 分支、`play()` 前；删掉 idle 块。`prepared` 起播前再 `syncAudioSession()` 保活。
  - `audioInterrupt` 回调：开关打开时不主动 `pause()`，改走 `resumeFromForcedInterrupt()` —— 延迟 250ms 补一次 `play()` 抢回被系统强制暂停的流，1.5s 节流防抖，并重新激活会话；开关关闭时保留原 PAUSE / RESUME 逻辑。
  - `applyInterruptMode()` 末尾 `syncAudioSession()`，开关一变立刻生效。
- `ui/pages/PlaySettingsPage.ets`：hint 改为「其它应用同时播放时继续播放，声音混合输出」，去掉做不到的「来电」承诺。
- `scripts/selfcheck.py`：新增 `CG` 组锁死 AudioSession 全链路、属性设置时机、禁止旧「回调 return」写法。全量 **78 项：PASS 76 / WARN 2 / FAIL 0**。

**红线 / 边界**
- 别再想用 `INDEPENDENT_MODE` 或「回调里 return」实现跨应用共存 —— 官方文档已明确否掉。
- `activateAudioSession` 必须在 `play()` 之前；会话会被系统超时释放，`audioSessionDeactivated` 重激活不能删，否则播一阵又会被打断。
- 来电 / 闹钟 / 导航等系统高优先级音频仍以系统策略为准，开关主要保证「其它应用播放音乐 / 短视频时本应用不自动暂停」；不同 ROM 焦点策略有差异，装机需实测。
- 续播兜底是节流过的，别把 1.5s 间隔调小或删掉，否则会与系统反复拉扯导致播放抖动 / 耗电。

---

## 接手必读 · 2026-11-14 v1.0 歌曲评论（四平台直连 / 咪咕隐藏入口）

**基线**：`音栈-交接包-20261114-v1.0f.zip`（67 / 1.0，自检 77 项 PASS 75 / WARN 2 / FAIL 0）。
用户诉求：「给歌曲增加可以查看评论的功能，各个平台的都搞一下；评论入口放在哪自行决断」。
用户选择：**按方案全做** + **咪咕歌直接隐藏评论入口**。

**改动（只增不删，不重做播放页 UI）**
- 新增 `core/CommentApi.ets`：统一 `CommentInfo` / `CommentPage` 模型，`fetchComments(song, page, hot)` 按 `song.source` 分派；`commentSupported()` 白名单 `wy/tx/kw/kg`。
- 新增 `ui/pages/CommentPanel.ets`：**组件不是路由**，通过 `@Prop` 基本类型接参（避开 @Builder 按值传参坑），`@Watch('onSongKeyChange')` 切歌重拉，`reqSeq` 防旧响应覆盖新歌。
- `ui/pages/PlayerPage.ets`：底排动作栏加第 5 个「评论」按钮（`commentButton()`），`commentSupported(this.song)` 条件渲染；`panel = 8` + `panelContent()` 分支 + `bindSheet` `SheetSize.LARGE`。**路由表 12 个名字一个没加**。
- `scripts/selfcheck.py`：新增 `CZ` 组（四平台端点 / id 桥接 / 咪咕隐藏 / 零新增路由 / 失败如实 / 切歌重拉）；`CD` 组的 `gateway.kugou.com` 检查细化为「只允许 `CommentApi.ets` 的 `mcomment/v1/cmtlist`」，防账号体系借通用网关回潮。自检 **78 项 PASS 76 / WARN 2 / FAIL 0**。

**四平台实测端点（2026-11-14 沙箱直连，均为匿名，不用登录）**

| 平台 | 端点 | 关键桥接 |
|---|---|---|
| wy | `music.163.com/api/v1/resource/comments/R_SO_4_<songId>` | `song.id` 已是数字 id |
| tx | `c.y.qq.com/base/fcgi-bin/fcg_global_comment_h5.fcg`（`cmd=8` 最新 / `6` 热评） | `song.id` 是 **songmid**，必须 `client_search_cp` 反查数字 `songid`；直接传 mid 返回 `commentlist: null` |
| kw | `comment.kuwo.cn/com.s`（`comment.s` / `/comment` 均已 403 / 404） | `song.id` 已是 rid |
| kg | `gateway.kugou.com/mcomment/v1/cmtlist` + Android MD5 签名 | `hash → getSongInfo.php?cmd=playInfo → audio_id → childrenid=<audio_id>`；**必须用 `childrenid` 参数**，`mixsongid` / `hash` 都不行 |

**红线 / 边界**
- 咪咕（mg）评论接口 `music.migu.cn/v3/api/comment/*` 实测全部 301 跳 HTML 首页且资料显示需登录 → **隐藏入口**，不要显示假空白，也不要用别的平台同名歌曲评论串台。
- 任何失败（网络 / 风控 / `code=-462` / `err_code` / 空列表）都返回 `error` 真实原因给面板，面板显示重试；**不许返回占位评论、不许拿空数组当成功、不缓存上次结果**。
- 酷狗签名 `MD5(salt + 排序 key=value 串 + salt)`，salt `OIlwieks28dk2k092lksi2UIkp`，用原生 `cryptoFramework.createMd('MD5')`；该 API 有 syscap WARN（非所有设备支持），已 try/catch，签名失败返回明确错误。
- 评论面板是 `bindSheet` 组件，别改成 `NavDestination` / 新路由，`check_tab_routes` 精确锁 12 个名字。
- 首包**全部改动未上真机**：沙箱只做到接口实测 + 自检 + API26 release `BUILD SUCCESSFUL`（HAP 3,263,811 B）。**真机回归结果与两处修复见下一节**。

---

## 接手必读 · 2026-11-14 真机回归修复（覆盖上一节的「未上真机」）

**用户真机截图反馈**：酷狗评论面板显示 `Parameter error`；QQ 音乐显示
「读取 QQ 音乐评论失败: TypeError: Cannot read property length of null」。wy / kw 正常。

**根因（真机现象 + 沙箱同款歌曲对照实测）**

1. **QQ**：`fcg_global_comment_h5.fcg` 把 `middlecommentcontent` / `avatarurl` 等字段
   大量返回 **null**；旧 `str()` 只判 `undefined`，把 null 透给 `middle.length` → 抛 TypeError。
   截图歌曲「伤心太平洋 / 任贤齐」反查 `songid=4830123`，`cmd=8` 返回 20 条，
   第一条就是 `middlecommentcontent=null`。
   → `str/num/numText/isDigits` 全部改成 `typeof` 兜底。
   → 另发现 `cmd=6` 时 `hot_comment` 可能为 null，而评论仍在 `comment` 块里
     （同曲实测 `comment.commentlist` 20 条 / total 821）：加热评降级，不让「热评」页空白。
2. **酷狗**：旧代码用 `POST` + 空 `extraData`（`options.body = ''`），
   **HarmonyOS NetworkKit 直接抛 `Parameter error`，请求根本没发出去**。
   沙箱 curl 的 POST 能通，所以沙箱测不出来，只有真机暴露。
   → 实测该端点 **GET 同样可用**：截图歌曲「慌啥子嘛 / 村口吴老二」
     hash `d0f928c394c175bc0f4cad8b9c3b5e9e` → `audio_id=658331615` →
     `count=772`、20 条评论，`pagesize=20` 正常。
   → 改走工程通用 `getJson`，删掉自定义 header 与 POST 组装；`song.hash` / `song.id` 加判空。

**红线（别改回去）**
- 别把 `str()` 改回 `v === undefined ? '' : v`：QQ 的 null 字段会再次让评论页崩。
- 别把酷狗改回 POST：鸿蒙网络库对空 body 的 POST 报 `Parameter error`。
- 自检 `CZ` 组第 ⑦ 项锁住以上两条（typeof 兜底 / 热评降级 / `getJson<KgCmtResp>` /
  禁止 `options.method = 'POST'`）。

**另：发现页 UI 重做方案已按用户 2026-11-14 决定取消**，
`音栈-交接包-20261112/` 里把它列为「待办 / 未解冻 / 等发话」的备注已清除，
不要再从需求时间线的旧原话里把它捡起来做。

---

## 2026-11-14 · 评论改无限滚动（热评也能一直刷）

用户真机反馈：网易云「热评」页的「下一页」点不动，最新评论可以；要求去掉翻页
控件，改成一直往下刷，四个平台统一。

**接口事实（实测，别再试图给热评做翻页按钮）**
- 网易云 `hotComments` 只在 `offset=0` 返回、固定最多 15 条，`offset>0` 为空 → 没有第二页。
- QQ `cmd=6` 的 `pagenum` 无效，0/1/2 返回同一批且 `hot_comment` 恒为 null；
  只有 `cmd=8` 能翻页，且 `pagenum=0` 的响应里带 15 条官方精选热评。
- 酷我 `get_rec_comment` 约 3 页 / 50 条，`get_comment` 88 页。
- 酷狗 `cmtlist` 没有热评/最新之分，`p` 天然可一直翻（p=1/2/3/10 均正常），
  但分页之间有重叠，必须按 id 去重。

**做法**：`fetchComments(song, page, hot)` 签名不变，把 `page` 当无限流序号。
hot 流 `page=1` 是热评批次，之后自动映射接续该平台最新流
（wy offset / tx cmd=8 pagenum / kw get_comment / kg p）；`hot=false` 全程最新流。
`hasMore` 在热评批次必须为 true，否则刷不动（旧代码 `!hot && ...` 就是 bug 根源）。
UI 用工程现成的 `List + onReachEnd` 触底追加，按 id 去重，去掉翻页控件；
追加失败只影响底部、不清空已读列表；`added === 0` 时置 `hasMore=false` 防死循环；
切歌 / 切排序用 `resetInFlight()` 打断在途请求。

**网易云 -462**：连续翻页时随机返回 `code=-462`（限流），同 URL 立即重试即可
（实测 20/20 成功）。`wyFetch()` 最多 3 次；注意 ArkTS `arkts-limited-throw`
禁止 `throw e`，要用 `throw new Error('...')`（工程惯例，见 `Http.ets`）。

**红线**：别把 `!hot &&` 写回 hasMore；别恢复「上一页/下一页」；别删 `wyFetch` 重试。
自检 `CZ` 组第 ⑧ 项锁住无限流与 -462 重试。

---

## 2026-11-14 追加：失败面板对比度 + 听够 2/3 自动下载

**失败面板音源名看不清（真机截图实测）**：`PlayerPage.p()` 恒返回 `palette(true)`（播放页压在封面上的白字），
但 `failPanel` 的白色卡片背景是 `glassCardBase(this.isDark)` 跟随系统主题。浅色主题下卡片变白、音源名
仍用 `p().text`（近白）→ 白底白字。像素采样：面板底 `(16,17,22)`、卡片 `(253,252,250)`、
音源名文字 `(252,252,252)`。**卡片内文字必须用 `palette(this.isDark).*`**；标题 / 按钮在深色面板底上
继续用 `p()` 没问题。别把 `this.p().text` 写回卡片内（自检 `DA` 组会拦）。

**独家音源 v4.0（用户 2026-11-14 给的链接）**：`wzh15802/lxmusic` 里该文件已被删除
（提交 `c5fcca8c`），服务端 `88.lxmusic.中国` 明确回「版本过低(v4)，请下载 v7」，`/lxmusicv4/url/...` 404。
**工程本身已完整适配**：`SourceRepo.detectKind` 与 `lx_bridge.html` 对混淆脚本都 fallback 到 `lx`，
`LxRunner` 实现了它用到的全部 API（`lx.on/send/request/utils/version/env/currentScriptInfo`），
Node mock 实测能 `send('inited')` 上报 wy/tx/kw/kg/mg。用户确认「已适配过就不管他了」→ 本轮不改音源代码。

**听够 2/3 自动下载（默认关）**：
- 开关：`PrefKeys.AUTO_DOWNLOAD_ON_PLAY` → `Settings.autoDownloadOnPlay()` → `Backup.BOOL_KEYS`；
  下载页 `autoDownloadCard()`（在 `concurrencyCard()` 下）即时落盘。
- 触发：`Player.timeUpdate` 里 `time >= duration * AUTO_DOWNLOAD_RATIO(2/3)`，
  `autoDownloadDone` 每首一次、切歌复位；用 `setAutoDownloadHandler` 回调注入，
  **Player 不 import App**（避免循环引用）。
- `App.ets` 执行器：判断开关 → 跳过 `local` / 空 id / `hasDownload(song)` → `downloads.enqueue(song)`。
  不弹错误卡片、不打断播放；入队异常只记日志。
- 自检 `DA` 组锁住上述全部。

---

## 2026-11-14 追加：音源能力扩展（只补运行时能力，不碰内容页）

**用户口径（务必先读）**：「我说的扩大范围，意思是支持音源的能力」；「软件能支持更多的音源，
也能把音源要求的东西给它适配，但是最好不要跟现有工程冲突，这个软件的目的本质不还是听歌、下载」。
即：**把音源脚本要求的运行时能力 / 用户变量补齐**，不是把插件的榜单、专辑、推荐歌单搬进发现页。

**边界（红线，别越）**

- 落点**只在音源管理页 `SourcesPage` 既有 `bindSheet`**（菜单新增「配置与能力」形态）；
- 试跑结果**只进既有出口** `App.get().playAndOpen(...)` / `App.get().downloads.enqueue(song)`；
- **零新增路由**（路由表仍 12 个名字）；**不改发现页 / 榜单页 / 专辑页 / 搜索页的数据源与版式**；
- 不动既有 selfcheck 断言，只新增 `DB` 组；`actions` 协议三值 `musicUrl / lyric / musicSearch` 不变，
  扩展能力走独立 action，**别污染取链 / 取词链路**；
- `webdav` / `pako` 继续 `notSupported(...)` 如实标注，不伪造能力。

**运行时 `mf_runtime.js`**

- 新增 8 类扩展 action 分派：`albumSearch / albumInfo / topLists / topListDetail / recommendTags /
  recommendSheets / musicInfo / importSheet`；兼容 `getRecommendSheetsByTag` 变体；
  `importSheet` 调插件真实 `importMusicSheet(urlLike)`，异常作为真实失败原因回传。
- 归一辅助 `listOf / endOf / toTag / toTopSheet / flattenTopLists / fromSongs`；
  **`fromSongs` 必须放 `makeRequest` 内部**（依赖 `listOf/endOf`），提到模块级会引用不到。
- `load()` 按**实际导出**生成 `capabilities` 与 `variableDefs`，不造能力。
- `env.getUserVariables` 从写死 `{}` 改成 **getter**（`readUserVars()`），保存配置后即时生效、不必重载脚本；
  另有 `env.userVariables` 静态值兼容直读、`env.AG_DEBUG` 兼容真实插件。

**宿主链路**

- `lx_bridge.html`：`userVarsByInst` 按实例隔离；`loadMusicFree()` 给 `MFRuntime.load()` 传 `getUserVariables`
  **getter 而非快照**；host 新增 `__setUserVars(instId, varsJson)`；`loaded` 消息带 `meta`
  （`capabilities` + `variableDefs`）；`__unload` / `__reset` 清变量防串源。
- `LxRunner.ets`：`NativeMessage.meta?` + `onMeta` 回调 + `userVars: Map`；
  `load()` 把 `window.__setUserVars(...)` 与 `window.__load(...)` **合并进同一次 `runJavaScript`**
  （`LxRunner.load` 签名保持不变，别拆回两次调用，否则插件顶层读不到变量）；
  新增 `setUserVars(instId, varsJson)` 供保存后即时注入。
- `SourceRepo.ets`：`mfMetaMap`、`mfMetaOf()`（**别叫 `mfMeta`**，与已有静态方法 `mfMeta(code,key)` 撞名）、
  `mfUserVars() / saveMfUserVars() / injectUserVars() / probeMf()`；
  `loadAll` / `loadOne` 在 `runner.load(...)` 前 `await injectUserVars(item.id)`，保留既有调用形式。
- `PrefKeys.MF_USER_VARS = 'v4_mf_user_vars_'` + sourceId 隔离，**含 cookie/token/apikey 凭证，不进 Backup 白名单**。
- `Models.ets`：`MfVarDef / MfMeta / MfProbeResult`；`SourcesPage.ets`：`cfgMode` 系列状态、`configSheet()`、
  能力中文映射 `capLabel()`。

**踩过的坑**

- ArkTS `Record<string, string>` 的**键必须写成字符串字面量** `'musicSearch': '搜歌曲'`，不加引号会报
  `arkts-no-untyped-obj-literals`（曾卡在 `SourcesPage.ets:1263`）。
- 批量用 Node 装载真实插件生成清单时，顶层要挂 `unhandledRejection` / `uncaughtException` 兜底，
  否则插件自身调用的异步方法会把脚本带崩。
- `detectKind` 双端规则量化验证过 186 份插件本体：旧规则只漏判 1 个洛雪脚本，新增特征无收益 → **未改判定规则**。
- 新增 selfcheck 组若锁路由，务必用真实 12 个名字基线，别凭印象写 expected 集合。

**自检 / 构建**：`DB` 组锁死上述全部；`共 80 项：PASS 78 / WARN 2 / FAIL 0`；
API 26 release `BUILD SUCCESSFUL`，HAP `3,320,176 B`；干净目录复现产物内部逐文件一致。
