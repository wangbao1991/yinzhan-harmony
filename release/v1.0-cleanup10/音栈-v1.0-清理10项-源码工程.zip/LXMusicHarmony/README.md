# 音栈 · 鸿蒙原生音乐播放器（v1.0）

一个完全原生（ArkTS / ArkUI，Stage 模型，API 26 / OpenHarmony 7.0）的鸿蒙音乐播放器，播放地址由洛雪音源脚本提供。

> v4.0.20 是回退基线；v4.0.21 改下载存储、v4.0.22 修音源脚本加载、v4.0.23 切歌即时切换 + 取链提速，
> v4.0.24 处理「音质偏好全局性」与「歌词找不到」两项，
> **v4.0.25 让音源管理页的「首选」真正在播放/下载取链生效，并修正下载失败提示**，
> **v4.0.26 修「有的平台歌曲没有封面」**，
> **v4.0.27 修「通知栏封面停留在上一首歌」**，
> **v4.0.28 修「封面仍有不显示/错乱、歌词串平台、通知栏缺时长与歌词」**，
> **v4.0.29 修「咪咕歌词整段显示 HTML」**，
> **v4.0.30 修「首页切换重新加载、左上角返回/收起键点不动」**，
> **v4.0.31 修「榜单每次进入都要加载」**，
> **v4.0.32 接上酷狗推荐歌单**，
> **v4.0.33 修「歌单点进去拿不到歌曲」**，
> **v4.0.34 修「网易云歌单只出 10 首」**，
> **v4.0.35 修「迷你播放条的播放队列按钮点了没反应」**，
> **v4.0.36 修「一级页数据不刷新（音源已导入仍显示未导入）」**，
> **v4.0.37 修「播放页打不开（v4.0.35 回归）」与「本地音乐数字仍不刷新」**，
> **v4.0.38 修「二级页看不到当前播放条（榜单点歌无反馈）」**，
> **v4.0.39 主动自检：补播放失败提示、返回键优先级、播放页与队列浮层互斥**，
> **v4.0.40 继续自检：修失败跳歌死循环、本地音乐与最近播放不刷新等 6 处**，
> **v4.0.41 按需求移除「智感握姿」**，
> **v4.0.42 修「自动续播 / 记住播放进度时好时坏」三处断点**，
> **v4.0.43 修本地音乐菜单里冒出「下载到本地」，并加左滑删除与全选删除**，
> **v4.0.44 下载列表统一左滑 + 多选，并修「取消下载不生效、删了还在后台写」**，
> **v4.0.45 清掉 7 处同屏重复入口（首页、搜索、播放页、音乐库、下载、歌曲菜单、设置图标）**，
> **v4.0.46 收掉设置页「下载」卡片里与下载管理页重复的两项（保存目录、下载管理）**，
> **v4.0.47 播放页只留一个下载入口（菜单让位），底部按钮按真实状态显示**，
> **v4.0.48 播放页下线倍速与定时，队列按钮移到原定时位置，队列面板去掉「清空」**。
> 此处版本号是回退后重新计数，与回退前同号的旧版本无关。

## 编译与重建（先看这个）

工程自带可复现的命令行编译环境，不需要华为账号、不需要 DevEco Studio 图形界面：

```bash
bash scripts/env/setup_env_26.sh     # 首次搭建（OpenHarmony 7.0 / API 26，约 3 GB 下载）
source scripts/env/env.sh            # 每个新终端载入一次
bash scripts/env/build_release.sh    # 基线复核 → 干净构建 → 签名 → 验签 → 版本核对 → 自检
```

完整说明、五个必踩坑（`sdk-pkg.json` 格式、`hms` 空占位、hvigor tarball 内置依赖、HMS 校验 schema、闭源图片转码库占位）、报错速查与官方 DevEco 路径见 **[`docs/编译环境重建指南（避坑版）.md`](docs/编译环境重建指南（避坑版）.md)**；原始依据见 `docs/参考-编译环境搭建手册.md`。

工程零三方依赖，不需 `ohpm install`，可离线构建。产物默认在 `build/音栈-v2.39-signed.hap`。**注意：工程 `compatibleSdkVersion` 为 `26.0.0`，API 12 / API 24 工具链都无法构建。**

**用云端构建中心**：上传源码 zip 时选 **API 26（HarmonyOS 26.0.0）**、产物选 **HAP 安装包**、Release 模式。源码包**不含 `signing/` 证书材料**（平台会以 `HK-PROJECT-SECRET-FILE` 拒绝含证书的归档），构建由平台签名；本地要签名就把自己的材料放进 `signing/`，`build_release.sh` 会自动走签名分支，没有材料则输出 unsigned HAP。

## 音源协议兼容（导入第三方音源前建议先看）

音源运行时是 `entry/src/main/resources/rawfile/lx_bridge.html` + `core/LxRunner.ets` 组成的 ArkWeb 沙箱，按洛雪自定义音源 v2 事件协议提供 `globalThis.lx`。两批音源脚本（本地 20 个 + `pdone/lx-music-source` 16 种）的协议差异、为什么无损下载会失败、本轮的四层修复与剩余限制，见 **[`docs/音源协议兼容分析（整合版）.md`](docs/音源协议兼容分析（整合版）.md)**。

协议改动后可用 `node scripts/verify_source_protocol.js` 做离线回归（双兼容 `resp.body`、格式判定、音质档位三组用例，不联网、不依赖真机）。

## 一、音质偏好是全局生效的吗？—— 是

设置页、播放页、下载读写的都是同一个 `Settings.quality()`（`v4_quality`）：

| 位置 | 读 / 写 |
| --- | --- |
| 设置页「音质偏好」 | 写：`player.setQuality()` → Store |
| 播放页「音质」面板 | 写：同上（同一个 Store） |
| 播放取链 | 读：`Player.quality` → `Resolver.resolve(song, quality)` |
| 下载入队 | 读：`Downloader.enqueue()` 默认 `Settings.get().quality()` |

本版补上全局联动：`Player.setQuality()` 同步写 `AppStorage['qualityPref']`，设置页用
`@StorageProp + @Watch` 订阅，即使在播放页改了音质、设置页不重建也能立刻显示一致。

**策略差异（设计如此，不是没生效）**：播放用 `strict=false`，音源给不了 FLAC 会自动降质保证出声，
播放页按钮显示的是「实际音质」；下载用 `strict=true`，默认严格按所选音质，拿不到就报错
（打开「音质不足时自动降级」开关后才降质，并标注实际音质）。所以选了 FLAC 却看到 128K，
是音源只给到 128K，不是设置没生效。

## 二、歌词为什么有的平台不显示、搜也搜不出来

排查结论（修复前）：

1. `LyricRepo.fromPlatform()` 只实现 `wy/tx/kg/kw` 四个平台，**咪咕 `mg`、`qsvip` 及自定义源没有官方歌词**，
   直接掉到唯一兜底 LRCLIB；而 `lrclib.net` 国内基本不通。
2. 音源脚本歌词路径**实际从未生效**：随包 6 个音源里 3 个完全不上报 `inited`（`platforms/actions` 为空），
   另外 3 个只声明 `musicUrl`；旧过滤条件要求 `platforms` 含当前平台且 `actions` 含 `lyric`，
   空数组一律跳过；而且 `JSON.parse(raw)` 只认对象，音源返回纯 LRC 文本会抛异常被吞掉。
3. 只有「重新找歌词」（清缓存重跑同一条链路），**没有真正的搜索歌词功能**——链路拿不到，重试多少次都一样。
4. 全串行 + 长超时（音源逐个 8s、平台 15s、LRCLIB 10s），最坏要等很久才显示空态。

### 本版改法

| 改动 | 说明 |
| --- | --- |
| 两批并发取词 | 批1 音源脚本 + 本平台官方；批2 跨平台同名匹配 + LRCLIB。任一批先拿到就返回，各批有总超时兜底 |
| 补咪咕歌词 | 按 `copyrightId` 试两个官方接口，兼容 `{lyric}` / `{data:{lyric}}` / 纯文本 |
| 跨平台同名匹配 | 不看歌曲来自哪个平台，按「歌名 + 歌手」去 kw/wy/kg/tx 搜同名歌，用那边的官方歌词 |
| 修音源脚本路径 | `platforms/actions` 为空视为「能力未知」仍尝试一次；并发 + 3.5s 超时；返回兼容 JSON 对象 / JSON 字符串 / 纯 LRC |
| 新增搜索歌词 | 歌词空态「手动搜索歌词」→ 输入歌名 → 并发搜 4 平台 + LRCLIB → 候选列表点选即应用并缓存 |
| 超时收敛 | 平台 5s、LRCLIB 5s、批1 6.5s、批2 9s 兜底，不再长时间转圈 |
| KRC 兼容 | 解析时去掉 `<00:12.34>` 逐字标记，歌词里不再残留时间戳 |

改动文件：`core/LyricRepo.ets`（重构）、`core/Lrc.ets`、`core/Player.ets`、`core/App.ets`、
`ui/pages/SettingsPage.ets`、`ui/pages/PlayerPage.ets`。权限、签名配置、下载链路未动。

## 三、下载失败提示里的音源名 /「首选」到底生效吗

**结论：不是串源，是「首选」以前没接进取链链路。**

- `SourceRepo.setActive()` 只写 `v4_active_source`，并供 3 个页面显示名字 / 画角标；
  `Resolver.trySources()` 取的是 `enabled()` 全集，从不读 `getActiveId()`。
- v4.0.23 改成全量并发后，报错把各音源失败原因按到达顺序拼前 4 条，
  括号里第一个名字只是「最先失败的那条记录」，**不是下载实际使用的音源**。
- 桥接页每个实例的 `handlers` 隔离、`__emit` / `result` 都带 `inst`，取链结果不串源；
  但全局 `window.lx` 会停在最后加载的实例，本版已用 `__setActive` 指回首选。

| v4.0.25 改动 | 说明 |
| --- | --- |
| `core/Resolver.ets` | `trySources()` 给首选 1200ms 独占窗口，命中直接用；未命中再让其余已启用音源并发补位 |
| 同上 | `formatReasons()` 结构化失败原因：首选排第一、补位明确标注、同名去重、统计剩余尝试 |
| `core/LxRunner.ets`、`resources/rawfile/lx_bridge.html` | `setActive()` 下发 `__setActive(instId)`；`load()` 不再每次覆盖 `activeInst` |
| `core/SourceRepo.ets` | 启动 / 导入 / 启停 / 删除后统一 `syncActive()` |
| `ui/pages/SourcesPage.ets` | 文案与 toast 同步为「播放/下载优先使用」 |

只想用某一个音源，把其它音源开关关掉即可。

## 四、为什么有的平台歌曲没有封面

先排除网络：5 个平台的封面 CDN 实测全部 200，不是防盗链 / 协议问题。
根因是 `song.cover` 为空，可分为四类（均为真实接口响应验证）：

| 类型 | 代表 |
| --- | --- |
| 接口压根不给图 | QQ 搜索 `smartbox` 的 itemlist **0/4 带 pic**；酷我榜单/歌单 `musiclist` **一个图片字段都没有** |
| 结构读错 | 网易云 `/api/album/{id}` 实际返回 `{album:{songs, picUrl}}`，旧代码读 `resp.songs` → 空列表；且 `songs[].al` 为 null |
| 风控 / 别名没兜住 | 网易云歌单 v6 触发 `code:-462`；咪咕 `imgItems` 多尺寸；酷狗封面字段名不统一 |
| 无效兜底图 | 酷狗老 CDN `stdmusic/240/{albumId}.jpg` 现在对任意 id 返回同一张图 |

### v4.0.26 改法

- `QQ 搜索` 换 `client_search_cp`（带 `albummid`）拼官方封面，失败回退 smartbox
- `网易云` 专辑读 `album.songs` + 顶层 `picUrl`；歌单 v6 失败降级老接口
- `酷我 / 咪咕 / 酷狗` 补齐字段别名、多尺寸优选，去掉假兜底图
- `fixCover` 统一处理空值 / `//` / `http→https` / `{size}`
- 新增 `core/CoverRepo.ets`：**按需补封面**（并发 6、缓存、失败不重试、`coverVersion` 广播），
  列表项出现时才补，不阻塞加载；`Cover` 组件订阅刷新，`onError` 先试备用 URL
- `PlatformApi.fetchCover()` 实现酷我 `r.s` 按 rid 补、网易云 `song/detail`、QQ `albummid`、酷狗搜索匹配

实测：酷我榜单按需补 **5/5** 成功，QQ 拼出的封面 **200**，网易云专辑从 0 首变 10 首。

## 五、通知栏封面为什么是上一首歌

**不是封面没解析出来**：播放页显示的是当前歌正确封面，只有播控中心（通知栏 / 锁屏）停留在旧图，
而歌名、歌手、进度都已经是新的。两个原因叠加：

1. `AVSession.setAVMetadata()` 是**部分字段**语义（SDK 注释：`can fill in partially supported
   properties`），`mediaImage` 可选。旧 `updateSong()` 只在 `loadCover()` 成功时才设这个字段，
   拿不到封面就整个不传 → 系统**保留上一首的封面**。
2. v4.0.26 的 `CoverRepo` 按需补全是**异步**的，切歌瞬间 `song.cover` 常为空，`updateSong()`
   必然拿不到图；补到之后只广播 `AppStorage['coverVersion']`，`Cover` 组件能订阅刷新（播放页对了），
   但 `MediaSessionService` 不是 ArkUI 组件，**收不到广播、也没人再 set 一次**。

### v4.0.27 改法

- `updateSong()` 改两阶段：阶段 1 立刻下发文字 + **显式占位 `mediaImage`**（应用图标 `PixelMap`），
  阶段 2 异步取到真封面再刷一次；`lyric` 也显式置空，避免同类残留。
- `CoverRepo.addFilledListener()` + `Player` 注册：补到封面时若命中当前歌曲，调
  `session.refreshCover()` 回填；`coverUrlFor()` 还会先查补全缓存，覆盖「补全早于切歌」。
- `songToken` 每次切歌自增，迟到的旧封面直接作废，快速连切不会把上一首盖回来。
- `loadCover()` 失败时再试一次备用形态（`{size}` 替换 / http↔https 互切）。

状态机边界测试 **17 项 PASS**：无封面切歌不残留、补全回填、重复回调幂等、非当前歌忽略、
快速切歌竞态、下载失败保持占位、所有下发都带 `mediaImage`。

## 六、封面仍不显示/错乱、歌词串平台、通知栏缺时长与歌词

### 6.1 封面

| 现象 | 根因 | 修法 |
| --- | --- | --- |
| 咪咕有歌没封面 | `fetchCover()` 只有 kw/wy/tx/kg 四个分支，`mg` 直接返回空 | 新增 `mgCoverBySearch()`：按 `copyrightId` 精确匹配 + `imgItems` 最大尺寸，实测接口 20 首、封面 200 |
| 接口有图但仍 ♪ | 图是坏的（404/假图），`onError` 只试一次协议切换；`ensure()` 又因 `cover` 非空跳过 | `CoverRepo.registry` + `refill(key)`，`onError` 最终失败强制重补一次（`refilled` 防死循环） |
| 偶尔串成别的歌的封面 | `Cover` 只 `@Watch('uri')`，`songId` 变了不重算；两首都没图时 `uri` 都是空串，`shownUri` 留上一首的图 | `songId` 加 `@Watch`，变化时先清空 `shownUri`；`keyOf()` 空 id 退化为「歌名+歌手」，不再共用 `kw|` |
| 有歌名却匹配不上 | `sameSong()` 要求规范化歌名完全相等，「(Live)」「- Remastered」「（伴奏）」对不上 | `baseTitle()` 剥版本后缀；允许主体包含但长度差 ≤ 4、较短 ≥ 4 字 |

### 6.2 歌词串平台

1. 第一批是「音源脚本」与「本平台官方」并发竞速，脚本按歌名去别处搜词、常先返回 → 采用别处歌词。
   改为**官方优先**：`wy/tx/kg/kw/mg` 先按 id 精确取，没有才走脚本 + 跨平台 + LRCLIB。
2. 跨平台兜底以前直接取 `list[0]`。改为 `matchScore()`：歌名同主体、歌手必须相交、时长差 > 15s 放弃，
   **总分 > 1 直接放弃** —— 宁可没词也不给错的。

### 6.3 通知栏

- **时长**：`updatePlaybackState` 的 `durationMs` 以前只算进度、从不回写 metadata，
  而 `metadata.duration` 用 `song.duration*1000`（榜单条目常为 0）→ 不显示总时长。
  现在记录 `durationMs`，与实测值差 > 800ms 就回写一次 metadata。
- **歌词滚动**：`AVMetadata.lyric` 以前从未设置。现在 `Player` 把 `LyricDoc` 还原成标准 LRC
  交给 `session.setLyric()`（> 8KB 截断），`applyMetadata` 每次带 `lyric`，切歌清空。

v4.0.28 逻辑边界测试 **23 项 PASS**。

### v4.0.29 改法

- **根因**：咪咕 `music.migu.cn/v3/api/music/audioPlayer/getLyric` 已下线，只回 301 跳转页（正文是 HTML）；
  网络层把 3xx 当成功、解析器把「无时间轴文本」当纯文本歌词，HTML 就一行行显示出来了。
- **取词改造**：优先用歌曲自带的 `lyricUrl`（搜索/歌单结果），没有再按 `songId` 调
  `resourceinfo.do` 取 `lrcUrl` / `trcUrl`，最后才按「歌名 + 歌手」搜一次且 `copyrightId` 必须一致。
- **防污染**：`Http` 只认 2xx；`Lrc.looksLikeMarkup()` 识别 `<!doctype`/`<html`/`<meta`/JSON 报错，
  `toDoc` 与 `parseLrc` 双重拦截，正常 LRC 与纯文本歌词不受影响。
- **噪声清理**：咪咕歌词的 `@migu music@`、`歌曲名/歌手名/专辑名` 行与重复的「内容纯音乐，请欣赏」合并剔除。

### v4.0.30 改法

- **首页切换重载**：四个一级页原来用 `if / else if` 分支渲染，切 Tab 会销毁整棵子树；
  改为常驻 `Stack` + `visibility`，首页只加载一次，搜索词/结果/滚动位置都保留。
- **返回键失灵**：`Index.measureSafeArea()` 的真实安全区只写进了自己的 `@State`，
  `AppStorage['topSafe']` 一直是默认 24，全屏布局下左上角按钮压进状态栏手势区。
  现在算完即写入 `AppStorage`，并去掉 `Index` 外层重复的一层 `padding-top`。
- **`App.back()` 判据**：`NavPathStack.size()` 不含 Navigation 根内容，二级页时值即为 1，
  原写法 `size() > 1` 永不成立；改为 `size() > 0`。

### v4.0.31 改法

- **重复请求**：首页启动时已把 5 个平台榜单列表拉过一遍，点进榜单页又拉一遍；酷我 4 个子榜还是串行，
  实测 603ms。现在 `ranks()` 走 `RankCache`（10 分钟），并把酷我子榜改 `Promise.all` 并发。
- **无缓存**：新增 `core/RankCache.ets`，榜单列表 10 分钟、榜单歌曲 5 分钟；空结果不写缓存。
  `sheetSongs()` 只对 `kind === 'rank'` 生效，歌单/专辑逻辑未改动。
- **页面**：`RankBoardPage.onReady` 拆成 `hydrate()`（同步铺缓存）+ `refresh()`（后台静默刷新），
  刷新按 `boardId` 找回选中的子榜；接口失败且无内容时才显示空态。
- **首屏**：空白 + 小转圈换成骨架条，子榜先出现。

### v4.0.32 改法

- **缺口**：`sheetsByTag()` 只有 wy/tx/kw 三条分支，酷狗、咪咕 落到 `return []`，推荐歌单永远空态。
- **酷狗**：新增 `kgPlaylists(page)`，走 `m.kugou.com/plist/index&json=true&page=N`（600 条、30 条/页），
  字段映射 `specialid/specialname/imgurl/songcount/playcount/username`；详情复用已有 `kgSpecialSongs()`。
  按标签筛的接口带签名校验（`Access Deny`），因此 `sheetTags('kg')` 返回空，不显示假分类。
- **分页**：`loadMore()` 按 `platform + id` 去重后追加（实测酷狗第 2 页有 3 条重复），整页重复即停止翻页。
- **咪咕**：列表能取到（`pc/bmw/page-data/music-index-show/v2.0` 的「推荐歌单2.0」栏目），
  但详情 `inMusicLists.do` 返回 `290001 请先登录`，给了卡片点进去必空，故不接入，仅把空态文案改准。

### v4.0.33 改法

- **根因**：平台歌单与本地自建歌单的 `kind` 都是 `'playlist'`，`SheetDetailPage.songsOf()` 只按 kind 判断，
  把平台歌单当成自建歌单交给 `Library` 查，永远查不到 → 所有平台点进去都提示「这个列表暂时拿不到歌曲」。
- **判定**：新增 `isLocalList(sheet)`，要求 `platform === 'local'` 才算本地库；
  `songsOf()` / `onLibraryChange()` / `subtitle()` / 菜单 `playlistId` 全部改走它。
- **连带**：`onLibraryChange()` 之前会在收藏/建歌单时把平台歌单列表清空；平台歌单菜单不再出现「从歌单移除」。
- **酷狗取全**：`kgSpecialSongs()` 的 `pagesize` 由 100 提到 1000，超过 1000 再补一页（上限 2000），
  417 首的歌单实测一次取全。

### v4.0.48 改法

- **倍速下线**：底排 `1x`、倍速面板、音质旁的速度角标全删；`Player.speed`、`setSpeed/getSpeed`、`v4_speed` 一并移除。
- **定时下线**：底排「定时」、定时面板、倒计时状态全删；`setSleep/sleepRemain`、`sleepTimer` 一并移除。
- **队列移位**：顶栏列表图标删除，`controls()` 第 5 格换成「队列」（原定时那一格），全页只剩一个队列入口。
- **队列面板去「清空」**：只留右上系统关闭叉号，原先胶囊与浮层叉号叠在一起像被划掉；行内单删保留。
- `Player.clearQueue()` 随之无调用者，一并删除；`PrefKeys.SPEED/SLEEP` 删除，老键保留不读。

### v4.0.47 改法

播放页底排有「下载」，右上「更多」弹出的菜单里又有「下载到本地」，两处调的是同一个 `enqueue`、连提示都一样：

- `SongMenu` 新增 `hideDownload`，播放页传 `true`；其它页面（歌单 / 搜索 / 首页 / 榜单 / 歌手）照旧显示。
  没直接删菜单项，是因为那些列表没有底排动作栏，删了就只能进播放页下载。
- 底部按钮改成按状态说话：未下载「下载」、排队「排队中」、下载中「下载中」、完成「已下载」+ 主色勾。
  以前已下载也写着「下载」，点下去只弹「已经在本地了」；下载中再点还提示「已加入下载队列」，实际没入队。
- 订阅 `downloadVersion` 但先比较再赋值，只在状态切换时重渲染，不让下载进度拖累歌词滚动。
- 自检 Q 类加第三条：页面有单曲入队、同屏 `SongMenu` 又没 `hideDownload` 就 WARN；`downloadAll()` 不误报。

### v4.0.46 改法

设置页「下载」卡片原来有三项：保存目录、自动降级、下载管理。前两项与别处重复：

- **「保存目录」与下载管理页的「检测」调的是同一个 `refreshDir()`** —— 重新探测目录可写性、必要时重建、弹 toast。
  名字叫「保存目录」、右侧带箭头，看起来像能进去看或能选，点下去只弹一句提示，名字和行为对不上。
- **「下载管理」与音乐库入口卡、首页右上图标是同一页的第三个入口**，且是三者里唯一不带信息的（音乐库那张卡带「N 首」角标）。

改法：设置页「下载」卡片只留真正的配置项「音质不足时自动降级」，目录检测与任务列表统一到下载管理页；
音乐库入口卡与首页图标保留不动。顺带删掉 `dirName` 状态与它的初始化。
自检 Q 类扩成两层：同屏重复之外，同一目标页被 3 个及以上页面挂入口也报；反向注入设置页入口可检出。

### v4.0.45 改法

同一界面两个入口做同一件事，会让人站在界面前犹豫。按页扫了一遍，处理 7 处：

- **首页**：顶部时钟图标与「最近播放」区块的「全部」进同一个列表 → 删顶部图标。
- **搜索**：搜索框左侧平台下拉与下方平台 chips 是两套选平台 → 删下拉，`sourceMenu`/`sourceLabel` 一并删除。
- **播放页歌词屏**：头部收藏 + 更多与底部动作栏重复 → 头部只留「点击收起」箭头。
- **音乐库**：空态时「+」「新建」「空态按钮」三个新建入口同屏 → 空态隐藏标题旁「新建」。
- **下载管理**：行尾垃圾桶与左滑删除重复 → 去掉垃圾桶，只留左滑 + 多选。
- **歌曲菜单**：「我喜欢」列表里「取消收藏」与「从我喜欢中移除」都取消收藏 → 前者在收藏列表隐藏。
- **设置**：同一张下载卡片里「自动降级」和「下载管理」都用下箭头 → 后者改用 `download` 图标。
- 自检新增 Q 类「重复入口」：同一页面两处 `push` / `toSheet` 到同一处即报；反向注入首页时钟图标可检出。

### v4.0.44 改法

- **下载列表统一手势**：每条右侧垃圾桶改成左滑（下载中显示「取消并删除」）；head 加「选择」，
  进多选后行首勾选、行尾动作收起、整行点击切换；「全选 / 已选 N 项 / 删除」，删除前二次确认。
  `removeMany()` 一次落盘一次广播，删空自动退出选择态。
- **取消下载真的停**：`cancel()` 以前只认 `waiting`，下载中点 × 毫无反应。现在 running 一并取消，
  记 `cancelled` 痕迹；`run()` 在 progress 回调里核对并 `live.delete()`，complete 后再核一次并清临时文件。
- **删记录不再「文件还在后台写」**：`remove()` 抽成 `dropOne()`，先取消再摘记录，
  痕迹留到 `finally` 才清；取链与 `bootstrap()` 之后各核一次，避免删了任务文件却出现在下载目录。
- `retry()` 清掉取消痕迹，取消过的任务能正常重试。
- 自检新增 P 类（下载取消闭环），反向注入 v4.0.43 的旧写法能直接 FAIL。

### v4.0.43 改法

- **菜单里的「下载到本地」**：本地音乐本身就是本地文件、已下载的平台歌也已经在本地，
  这一项却无条件显示，点了只弹「这首歌已经在本地了」——把内部状态当功能给用户看。
  改为 `source !== 'local' && !hasDownload(song)` 才出现。
- **本地音乐加左滑删除**：`ListItem.swipeAction` 露出红色「删除」，删的是导入时复制到沙箱的副本，
  手机里的原始文件不动；同时把这首歌从播放队列摘掉，避免「文件没了还在放它」。
- **全选 / 多选删除**：head 右侧加「选择」，进入后行首变勾选圈、行尾收藏与更多收起、长按不再弹菜单；
  下方出现「全选 / 已选 N 首 / 删除」，删除前二次确认，`LocalRepo.removeMany()` 一次落盘一次广播。
- 删空之后自动退出选择模式（页面已转空态，没有工具栏可点「完成」）。

### v4.0.42 改法

这两个开关一直都在，坏在三条前提上：

- **播放中位置不落盘**：`timeUpdate` 先 `lastPersist = now`，再调要求 `now - lastPersist >= 4000` 的 `persistQueue(false)`，
  判断恒假 → 全程一次没写。正常退出能记住，被划掉/回收就退回上次暂停点。
  改为独立的 `persistPosition()`（只写 `LAST_POS`）+ `lastPosSave` 计时；暂停、拖动进度补即时落盘。
- **进度恢复挂在自动续播上**：`pendingSeek` 只在 `autoPlay()` 分支设置，关掉开关后点播放从头开始。
  改为 `resumeKey`/`resumeSeek` 记录「哪首、从哪继续」，`playCurrent()` 统一消费一次。
- **自动续播跑在音源前面**：冷启动 `restore()` 时音源 WebView 还没注入脚本，取链必失败、连跳两首。
  改为本地直通、在线等 `sourcesReady`（上限 8 秒，等待中显示准备中），用户先动手则不重复开播。
- 恢复点落在最后 5 秒内从 0 开始，避免一进应用就「播完」跳下一首。
- 自检新增两类：M 进度落盘（节流自锁）、N 恢复进度解耦，反向注入验证可检出。

### v4.0.41 改法

- **移除「智感握姿」**：设置页不再有这一项，整块自动左右手适配下线——`core/Grip.ets`（重力传感器推断 + 手动锁定）删除，
  `Settings.gripMode()/setGripMode()`、`PrefKeys.GRIP_MODE`（`v4_grip_mode`）、`EntryAbility` 的预读一并删掉。
- **布局回到固定右手**：`Shell.MiniPlayer` 的播放/下一首按钮、播放页顶栏的换源/队列、底部控件的播放模式/定时，
  原来按 `gripSide` 左右互换，现在按右手布局固定——正是原先「关闭握姿」时的样子，视觉与操作不变。
- **不再申请传感器**：`SensorServiceKit` 的 `GRAVITY` 订阅随模块一起消失，冷启动少一个常驻监听。
- 老用户机器上残留的 `v4_grip_mode` 键不再读取，留着无害（不清库，避免连带丢别的设置）。

### v4.0.40 改法

- **失败跳歌死循环**：`handleFail` 里 `failStreak++` 后调 `next()`，而 `next()` 第一行又 `failStreak = 0`，
  计数永远到不了 2 → 队列以 0.9 秒一首无限跳，既不播也不报错。`next(auto)` 只在用户主动切歌时清零。
- **「本地音乐」列表页不刷新**：`onLibraryChange` 只认 `kind ∈ {favorites,history,playlist}`，
  `kind === 'local'` 被跳过；且该页只订阅 `libraryVersion`。改为按 kind 分派 + 订阅 `localVersion`/`downloadVersion`。
- **「最近播放」不刷新**：`Library.addHistory()` 只落盘不 `notify()`，上一版加的订阅是空转，补上广播。
- **大歌单错位**：队列只存 200 首却存全量 index，恢复时被夹到 199。改成围绕当前曲的滑动窗口。
- **搜索结果滑不到底**：`loadMore` 早退时不清 `loadingMore`，换关键词后永久卡住。
- **下载任务不释放**：`DownloadTask` 从不 `delete()`，槽位耗尽后新任务直接失败；同时校验「完成」的文件不是 HTML。
- **删当前播放曲目**：旧逻辑只在越界时换歌，删中间那首会「队列里没它却还在放」。
- **滚动收起标签栏**：`TabBarHider` 写了一套渐变，8 个页面都在 `feed()`，外壳从未读 `tabBarProgress`。按「只收标签栏」方案接上。
- **其他**：`Resolver` 的 `lastMessage`/`preferredWindowUsed` 从单例字段改局部（并发串源）；
  `Http.request` 补同步异常保护与状态码人话；封面失败 5 分钟可重试、缓存与登记表加上限、广播节流 200ms。

### v4.0.39 改法

- **主动自检**，不等反馈。四类扫描 + 行为测试，扫出 3 个尚未被用户撞到的问题。
- **播放失败静默**：`errorText` 只在播放页展示，列表点歌失败时没有任何反馈。新增
  `Player.setErrorReporter()`，外壳注册后弹轻提示；自动跳下一首的两次不提示，停下那次才说明原因。
- **返回键无优先级**：`Index` 一直没有 `onBackPress`，队列浮层开着时按返回会退页面（首页则退出应用）。
  补统一入口：队列浮层 → 播放页 → 二级页 → 退出。
- **浮层互斥**：`openPlayer()` 不关 `queueShow`，从队列进播放页再退出会压着旧浮层；改为开播放页前先收。
- **待定**：`TabBarHider` 一直往 `AppStorage['tabBarProgress']` 写值，但外壳从未读取，滚动隐藏标签栏从未生效。
  两种接法（只收标签栏 / 整组收）涉及视觉取舍，等确认后再接。

### v4.0.38 改法

- **根因**：迷你条 + 标签栏画在 `Navigation` 的根内容里，压入二级页后整块被 `NavDestination` 覆盖。
  榜单、歌单、歌手、下载、音源、发现页全都看不到「当前播放」，歌其实已经在放。
- **改法**：两者提到外层 `Stack`，与 `Navigation` 同级 → 所有页面都显示迷你条。
  标签栏只在一级页显示，靠 `AppStorage['navDepth']`（`App.syncNavDepth()`，由 push / back /
  `setInterception` 三条路径写入）决定；系统返回手势靠拦截回调回读 `size()`。
- **留白**：二级页尾部占位加 `MINI_BAR_SPACE`(64)，最后一行能滚到条上方。
- **顺带**：榜单行点击由 `playAndOpen` 改 `play`（和歌单/歌手一致，不跳播放页）；
  「正在播放」高亮由只比 `id` 改为 `App.isCurrent()`（`id` + `source`），避免跨平台撞号误标。

### v4.0.37 改法

- **播放页打不开（v4.0.35 回归）**：`bindSheet` 与 `bindContentCover` 挂在同一节点会互相顶掉，
  后绑定的生效、先绑定的失效 → `playerShow` 置 true 也不弹。队列面板改为根 `Stack` 里的普通节点叠层
  （遮罩 + 70% 面板 + `TransitionEffect.move`），`bindContentCover` 独占弹层槽位。
- **本地音乐数字不刷新**：v4.0.36 的 `localVersion` 广播本身是通的，卡住的是渲染——
  `@Builder entryCard(item)` 按值传参，ArkUI 只在首次调用时取参数，参数变了不更新已生成的节点。
  改为独立 `@Component LibraryEntryCard` + `@Prop hint`，父组件重绘即带动卡片；
  顺带删掉 `EntryDef` 与 `entries()`。
- **对比**：设置页的 `sourceCard()` 是无参 `@Builder`，内部直接读 `this.sourceCount`，属于父组件自身依赖，
  所以 v4.0.36 的修法在那里是有效的——同一个问题在两种写法下表现不同。

### v4.0.36 改法

- **根因**：v4.0.30 把四个一级页改成常驻 `Stack` + `visibility`，`aboutToAppear` 从此只跑一次；
  数据在二级页变化时，一级页既不会重建也没有通知通道。以前「切 Tab 就重建」掩盖了这个缺陷。
- **设置页音源卡片**：`sourceCount` / `sourceName` / `sourceOk` 是普通 `@State`，只在 `aboutToAppear` 读；
  `SourceRepo.notify()` 只写 `sourceCount`（条数不变的操作不产生新值），页面也没订阅 → 永远停在首帧。
- **音乐库数字**：`localCount` / `downloadCount` 来自 `LocalRepo` / `Downloader`，
  `LocalRepo.notify()` 不写 AppStorage，音乐库也没订阅 `downloadVersion`。
  「切几次忽然对了」是因为播放历史触发 `libraryVersion` 时，`refresh()` 顺带把这两个数也读了一遍。
- **修法**：`SourceRepo` 补 `sourceVersion`、`LocalRepo` 补 `localVersion`（都用 `Date.now()`，
  保证改名/切首选这类「数量不变」的操作也能触发）；设置页、音乐库、首页分别 `@StorageProp + @Watch` 订阅。
- **顺带**：首页「最近播放」以前也只在 `aboutToAppear` 读，播完一首回首页不变，一并订阅 `libraryVersion`。

### v4.0.35 改法

- **根因**：迷你播放条的「列表」按钮只会把 `Index.queueShow` 置 `true`，而 `@Builder queuePanel()` 从未被
  `bindSheet` / `bindContentCover` 挂载 —— `@Builder` 不挂容器就不会执行，面板永远弹不出来。
  迷你条是全局组件，所以首页、搜索、音乐库、歌单、榜单上点它都是同一个「没反应」。
- **补齐挂载**：`Index.build()` 的根节点加 `bindSheet($$this.queueShow, this.queuePanel(), { height: SheetSize.LARGE })`，
  任何页面点开都是同一个面板，`onDisappear` 回写 `queueShow = false`。
- **去重复**：`PlayerPage` 里那份 90 行队列面板删除，`panel === 4` 直接复用 `ui/QueueSheet`，
  两处图标长得一样，行为不再各写各的。
- **定位当前曲目**：标题改「共 N 首 · 正在播放第 x 首」，打开后延时 180ms `scrollToIndex(current - 2)`，
  从第 40 首点播也能一眼看到自己在哪；点队列里的歌切歌后自动收起。
- **性能**：旧实现把 `version` 塞进 `ForEach` 的 key，而 `version` 每次 `onChange` 都递增（播放进度每秒一次），
  等于每秒重建整个列表；改为内容指纹（长度 + 当前索引 + 每首 `source+id`），只有队列真变了才更新。

### v4.0.34 改法

- **根因**：网易云 `/api/v6/playlist/detail` 对匿名请求把 `tracks` 裁到前 10 首（`trackIds` 仍是全量）。
- **主路径**：改用老接口 `/api/playlist/detail`，匿名也返回全量（427/197/76/30 实测与 trackCount 一致），
  旧结构 `artists/album/duration` 由 `wySong()` 原有别名兼容，超时放宽到 20s。
- **兜底**：老接口失败时走 v6（带固定 Cookie），`trackIds` 多于 `tracks` 就按每批 100 首调
  `/api/song/detail?ids=[...]` 补全并按原顺序重排；`Http.ets` 为此新增 `getJsonWith()`。
- **时长**：`wySong()` 改为 `raw.dt ?? raw.duration`，v6/v3 的 `dt` 之前没认，歌单里全是 `0:00`。
- **酷我**：`rn=200` → `1000`（`pn` 偏移不生效），445 首的歌单一次取全。

## 工程结构

| 目录 | 作用 |
| --- | --- |
| `entry/src/main/ets/core/LyricRepo.ets` | 歌词仓库：并发分批、平台官方、跨平台匹配、手动搜索 |
| `entry/src/main/ets/core/Player.ets` | 播放队列、切歌时机、音质偏好、歌词状态 |
| `entry/src/main/ets/core/Resolver.ets` | 取链：缓存、音质链、首选音源优先、换源 |
| `entry/src/main/ets/core/RankCache.ets` | 榜单内存缓存：列表 10 分钟 / 歌曲 5 分钟，缓存先铺 + 后台刷新（v4.0.31 起） |
| `entry/src/main/ets/ui/QueueSheet.ets` | 播放队列面板：迷你条与播放页共用，打开自动定位当前曲目（v4.0.35 起） |
| `entry/src/main/ets/core/CoverRepo.ets` | 按需封面补全：并发/缓存/广播/坏图重补（v4.0.26 起） |
| `entry/src/main/ets/service/MediaSessionService.ets` | 播控中心元数据两阶段下发、封面回填、时长回写、歌词滚动（v4.0.27~28） |
| `entry/src/main/ets/core/PlatformApi.ets` | 各平台元数据解析 + 补封面接口 |
| `entry/src/main/ets/core/DownloadPath.ets` | 固定下载目录（v4.0.21） |
| `entry/src/main/resources/rawfile/lx_bridge.html` | 音源脚本沙箱 |
| `scripts/` | 命令行构建与签名脚本 |
| `archive/baseline/` | 正式基线三副本（HAP / 源码快照 / 图解），v2.39 |
| `scripts/env/setup_env_26.sh` | 一键重建 HarmonyOS 7.0（OpenHarmony 7.0-Release / API 26）命令行编译环境，免华为账号 |
| `entry/src/main/resources/base/media/app_icon.png` | 应用图标：浅色 / 默认主图标（1024²，去水印） |
| `entry/src/main/resources/dark/media/app_icon.png` | 应用图标：深色模式（1024²，去水印） |
| `docs/应用图标说明.md` | 图标资源布局、深浅色适配原理、去水印方法与规范提醒 |
| `scripts/icon/remove_watermark.py` | 图标去水印脚本，可复现生成上面两张资源 |
| `entry/src/main/resources/base/media/start_window_icon.png` | 启动窗口专用图（径向淡出，浅色），避免启动页出现方形色块 |
| `entry/src/main/resources/dark/media/start_window_icon.png` | 启动窗口专用图（深色）；配套 `dark/element/color.json` 定义深色启动底色 |
| `scripts/icon/make_start_window.py` | 从桌面图标生成两张启动窗口专用图 |
| `scripts/env/env.sh` | 载入 `DEVECO_SDK_HOME` / `DEVECO_NODE_HOME` / `OHOS_SDK_LIB` 等环境变量 |
| `scripts/env/build_release.sh` | 基线复核 + 干净构建 + 签名 + 验签 + 版本核对 + 自检一条龙 |
| `docs/编译环境重建指南（避坑版）.md` | 环境重建说明、五个避坑点、报错速查、验收结果 |
| `docs/参考-编译环境搭建手册.md` | 你提供的原始编译环境搭建手册（签名与 profile 细节以其为准） |
| `signing/` | 签名证书链与 profile：`app-chain.pem` / `profile.p7b` / `profile.json` |
| `scripts/selfcheck.py` | 交付前自检：把历史事故固化成 24 类机器扫描（广播闭环 / 死 Builder / 带参 Builder / 页面订阅 / 回调漏传 / 监听泄漏 / 列表 key / 弹层冲突 / 加载态收口 / 系统任务释放 / 持久化窗口 / 自动路径计数 / 进度落盘 / 恢复进度解耦 / 本地删除安全 / 下载取消闭环 / 重复入口 / 音源就绪门禁与试听拦截 / 启动并发与体检 / 失败面板与音源亲和 / 自检体系 / 左滑删除 / 自检收口与本地导入 / 歌词排版与颜色值），v4.0.39 起每版必跑 |

## 验证状态

- 整页液态玻璃（第十五轮）：用户反馈「装了新包，界面还是原来的，没变化」，按参考图重做 ——
  - **上一版为什么等于没改**：设置页 6 张卡、首页搜索框 / 横幅 / 四宫格全都还是 `backgroundColor(palette.card)` 的纯白，改的只有最底下两条栏；而且新配方是**纯白渐变 + 冷蓝黑投影**，铺在浅紫白背景上几乎看不见，方向也和参考图的浅色外光晕相反。参考图要的是**整页所有卡片**一起变成青绿通透的液态玻璃。
  - **抢背景的元凶**：`.backgroundBlurStyle()` 与 `.linearGradient()` 抢同一个组件背景，模糊材质可能把渐变整层盖掉。底栏两条全部去掉 `backgroundBlurStyle`，并给每张卡加半透明青绿兜底色 `glassCardBase` —— 即使某台机器上渐变不绘制，整页也不会退回白板。
  - **配方**：`glassSurface` 改成纵向 7 段（顶白 .92 → 中段薄荷青绿 .40 → 底白 .90 → 底边青 .72，`angle 180`），把「上沿细亮线 / 中段通透 / 下沿宽反光」压进同一个 background（ArkUI 没有 inset 阴影，只能这么做）；四边描边左右改淡青 `rgba(196,236,226,.60)`、上 1.0 下 1.6 纯白；投影换青绿光晕 `rgba(96,176,164,.26)` / offsetY 12。
  - **覆盖**：设置页 6 卡 + 首页 3 卡 + 底栏栏体 + 悬浮播放条；`glassCardBase` / `glassSurface` / `glassEdge*` / `glassShadow` 全部集中在 `Constants.ets`，一处改全站生效。
  - **版本号升到 `2 / 1.1`**：之前十几轮一直是 `1 / 1.0`，同版本同签名可能被系统当成已安装直接跳过，用户也无从分辨。设置页底部现在显示 `v1.1`，看到它就说明这一版确实覆盖上去了。
  - `selfcheck.py` 新增 AJ 组六条：整页卡片覆盖数、缺兜底色、残留 `backgroundBlurStyle`、青绿染色丢失、渐变段数不足、版本号没升。自检 **38 项 PASS 36 / WARN 2 / FAIL 0**，五组反向注入全部检出（详见 `docs/音栈-液态玻璃整页-图解.html`）
- 我喜欢 / 最近播放的删除（第十四轮）：两个列表页共用 `SheetDetailPage`，以前左滑只挂在「本地音乐 / 自建歌单」上 ——
  - **左滑单条移除**：`canSwipe()` 扩到 `favorites` / `history`；`swipeDelete` 按 kind 分发到 `removeFavoriteOne`（`Library.removeFavorite`）/ `removeHistoryOne`（新增 `Library.removeHistory`）。两者都只改列表本身，**不碰本地文件、下载缓存和播放队列**，和「本地音乐删文件」「歌单移除」三条路径互不借用。
  - **历史去重键**：`removeHistory` 用写入时同一个 `histKeyOf`（歌名 + 歌手），否则同一首歌从别的平台播过一次，用平台键去删是删不掉的，界面表现就是「点了没反应」。
  - **整份清空**：头部按钮行加淡红圆形垃圾桶（36），点开走 `confirmClear` → `AlertDialog` → `clearAll`；`Library` 新增 `clearFavorites()`，`clearHistory()` 复用。清空后补空态文案，不停在一片白。
  - **不放清空的地方**：平台歌单是别人维护的，本地音乐清空等于删光导入的文件，都只给单条左滑，不给一键清空。
  - `selfcheck.py` 新增 AH 组五条：`removeHistory` 缺失、`clearFavorites` 缺失、`canSwipe` 漏掉两种 kind、`swipeDelete` 没分发、`clearAll` 被按钮直连绕过弹窗。自检 **36 项 PASS 34 / WARN 2 / FAIL 0**，四组反向注入全部检出（详见 `docs/音栈-收藏与历史管理-图解.html`）
- 底栏立体通透（第十四轮）：底栏与迷你播放条重做成「有厚度的玻璃」，不再是平涂磨砂 ——
  - **根因是「均匀」**：原来是一层 `rgba(255,255,255,.60)` 加一圈 0.8 等宽同色描边。每个像素都一样，眼睛拿不到厚度线索，读出来就是「一块塑料板贴在页面上」。调色深调色浅都救不了。
  - **四层补齐**：① `glassSurface()` 对角四段渐变（白 .58 → .26 → .30 → 冷蓝 .42），左上受光、右下透出背景色；② `glassEdgeWidth/Color()` 四边分描——上 1.0、左右 0.9、**下 1.4 且最亮**，玻璃下沿的反射本来就比上沿厚；③ `glassDepth()` 只占下沿 26% 的聚光带，光在介质里走到边缘会累积，厚度就长在这；④ `glassShadow()` offsetY 12 / radius 20 / 冷蓝黑 14%，影子落下去才有离地高度。
  - **底沿内高光**：贴底一条 1.4 高的白带，中间实、两端渐隐——参考图里最抓眼的一笔。少了它，四边描边只是一圈线。
  - **选中片独立成小玻璃**：平涂 12% → 渐变 .26/.12/.18 + 一圈亮边 + offsetY 3 的短影，从「印在栏面上」变成「浮在栏面上」。
  - **层次**：两层间距 8 → **12**，播放条左右各收 4，一窄一宽才分得出「小的浮在上面、大的托在下面」（同宽并排会被看成一条被切成两截）。
  - **避开一个坑**：`linearGradient.angle` 在 0 度上的方向语义各版本不一致，聚光改成固定高度带 + `angle: 180`（默认方向），不会出现「光跑到顶部和受光层打架」。
  - `selfcheck.py` 新增 AI 组七条：缺 `glassSurface`、渐变不足四段、首尾白度相同、缺 `glassDepth`、四边等厚、聚光铺满、聚光没挂全、投影贴地、指示器平涂。自检 **37 项 PASS 35 / WARN 2 / FAIL 0**，六组反向注入全部检出（详见 `docs/音栈-底栏立体通透-图解.html`）
- 底栏误触（第十三轮）：展开态点「发现」进了播放页、点「设置」变成下一首/队列，只有设置最右缘能进设置 ——
  - **不是阴影**：`.shadow()` 只参与绘制，radius 18 / offsetY 8 不进命中测试树。
  - **根因是两层完全重叠 + `HitTestMode.None` 语义**：展开态三格标签与收起态播放坞同在 `width('100%')` 的 `Stack` 里，后者展开时 `opacity 0` 却仍参与命中；`None` 只让「这一层自己」不参与，**里面的封面 / 歌名 / 三个控制键各自照样响应**。按 392 屏宽实测，三格中心 x=75/196/317，而播放坞从 x=70 铺到 x=374，三键中心恰在 300/328/356 —— 点「发现」落在歌名区（`enter()`），点「设置」落在播放/下一首个位置，x>374 才是标签栏自己的格。
  - **修法**：`const FORM_SWITCH = 0.34`，两层互补 `.enabled(collapse < / >= 0.34)` 整棵子树互锁；`MiniPlayer` 加 `live()` 守卫（进播放页/播放暂停/下一首/队列四个回调，紧凑版 `bar < 0.34` 直接 return）；外壳那条播放条高度收到 0 后同样整层 `enabled(false)`（`clip` 只裁绘制不裁命中）。
  - `selfcheck.py` 新增 AG 组三条：缺 `FORM_SWITCH`、两层没有 enabled 互锁、`enter()` 未走 `live()`、0 高播放条未禁用。`BUILD SUCCESSFUL`、验签通过、`verifiedPassed = True`、包内 `com.yinzhan.music / 1 / 1.0`，自检 **35 项 PASS 33 / WARN 2 / FAIL 0**；三组反向注入（去掉收起态 enabled / 去掉 live 守卫 / 去掉 0 高条 enabled）全部当场检出（详见 `docs/音栈-底栏误触排查-图解.html`）
- 底栏收起比例与衔接（第十二轮）：慢速滚动下逐帧看，收起过程有三处不协调 ——
  - **两条轮廓**：旧底板 62 高、宽 100%→64%，新胶囊 52 高、宽 100%，0.46 之后两者同时可见，形成「胶囊套胶囊」，右边界还要先缩回去再弹出来，左右本来就不对称。现在**宽度一动不动**，只把同一块底板从 62 收到 52、圆角恒等于半高（`barH()` / `barR()` 取代 `barWidthPct()`），全程只有一条边线。
  - **两层内容**：22 号标签图标退到 0.68 才干净，而封面 0.46 就在同一位置浮现（真机上是「指南针压在『勇气』上」）。接力改成单向：文字 0→0.18、图标与指示器 0.06→0.34、圆按钮 0.28→0.60、封面歌名 0.36→0.66、三个控制键 0.48→0.74，任何一刻只有一层内容在变。
  - **比例不对齐**：52 的实心紫圆独立成块＋一条独立胶囊，重心被拽向左边；三枚控制键热区 28/24/25 不等、实心播放三角 20 对描边图标 16 偏重；封面在收起态是正圆（34/17），展开态却是圆角方形（40/10）；`.overlay()` 的高光直接盖在内容上，白渐变把封面冲成半透明灰。现在圆按钮 44 内嵌进 52 高的栏体（四边各留 4）、三键热区统一 28（图标 20/17/17）、封面统一 36 / 圆角 10、高光改成 Stack 垫底。
  - `selfcheck.py` AF 组重写：`barH`/`barR` 未挂载、宽度又开始缩、紧凑版自带底板、高光用 overlay 盖内容、图标退场晚于胶囊登场，五条任一命中即 FAIL。`BUILD SUCCESSFUL`、验签通过、`verifiedPassed = True`、包内 `com.yinzhan.music / 1 / 1.0`、3.57MB，自检 34 项 PASS 32 / WARN 2 / FAIL 0；四组反向注入（恢复缩宽度 / 高光改回 overlay / 胶囊提前浮现 / 紧凑版画底板）全部当场检出（详见 `docs/音栈-底栏比例与衔接修正-图解.html`）
- 启动页（本次）：`startWindowIcon` 改用径向淡出的专用图、底色改浅青白 / 深蓝并补齐 `dark/element/color.json`，消除启动时的方形色块与深色白底（详见 `docs/应用图标说明.md`）
- 应用图标（本次）：浅色主图标 + 深色模式图标各一套（1024²、已去水印），`base` / `dark` 双限定词目录；产物内两条 PNG 路径与 `resources.index` 登记均已核对，编译、签名、验签、自检全通过（详见 `docs/应用图标说明.md`）
- 设置页整合（本次）：设置页新增「音源」分组与「音源管理」入口行，「当前首选音源」概览、「只用首选音源」「音质不足时自动降级」统一收进音源管理页，设置页「下载」分组移除；编译、签名、验签、自检全通过（PASS 17 / WARN 4 / FAIL 0）
- 编译环境重建（历史记录，v1.1 时期）：`hvigorw 5.8.9` + `SDK 5.0.0.71 / API 12`，全新目录重跑 `setup_env.sh` 后再次构建成功；**v2.7 起已切到 API 26 / hvigor 6.26.4，以 `scripts/env/setup_env_26.sh` 为准**（详见 `docs/编译环境重建指南（避坑版）.md`）
- `hvigorw assembleHap`：**BUILD SUCCESSFUL**
- `hap-sign-tool verify-app`：**verify-app success**
- 包内版本：`4.0.48 / 4000048`
- 歌词解析与并发兜底逻辑测试：9 类返回形态 + 5 个边界用例全部 PASS
- 首选优先竞速逻辑测试：12 项 PASS；桥接页多实例隔离测试：8 项 PASS
- 封面修复（v4.0.26）：5 家封面 CDN 全部 200；酷我榜单按需补 5/5、QQ 拼封面 200、网易云专辑 0→10 首、酷狗 3/3、咪咕 20/20
- 播控中心封面（v4.0.27）：状态机边界测试 17 项 PASS
- 封面/歌词/通知栏（v4.0.28）：逻辑边界测试 23 项 PASS；咪咕补封面实测 20 首、封面 200
- 咪咕歌词（v4.0.29）：解析边界测试 11 项 PASS；真实接口 5 首全部 200，LRC 时间轴 31~68 行
- 一级页切换（v4.0.30）与安全区同步：编译通过，`topSafe` 已写入 `AppStorage`，`App.back()` 判据改为 `size() > 0`
- 榜单缓存（v4.0.31）：缓存逻辑 18 项 PASS、榜单页流程模拟 13 项 PASS；酷我子榜列表由串行 603ms 降为并发
- 酷狗歌单（v4.0.32）：首页 30 条字段完整、封面 HTTP 200；分页去重 4 项 PASS；咪咕详情确认返回 `290001 请先登录`
- 歌单详情（v4.0.33）：本地/平台分流判定 14 项 PASS；酷狗 3 个歌单取到 417/32/40 首且字段齐全
- 歌单全量（v4.0.34）：网易云 4 个歌单 427/197/76/30 首与 trackCount 一致、字段无空；酷我 rn=1000 取 446 首；QQ 1288 首无截断
- 播放队列（v4.0.35）：链路静态自检 11 项全 PASS；`Index` 补 `bindSheet`、播放页复用 `QueueSheet`、打开自动定位当前曲目
- 一级页刷新（v4.0.36）：链路静态自检 13 项 PASS、刷新语义模拟 11 项 PASS（含修复前对照用例）
- 播放页与卡片（v4.0.37）：结构自检 11 项 PASS；队列改自绘浮层、四个入口卡片改 `@Prop` 组件
- 全局迷你条（v4.0.38）：链路自检 20 项 PASS、显隐语义模拟 13 项 PASS；迷你条移出 Navigation，二级页可见，标签栏按栈深显隐
- 主动自检（v4.0.39）：7 类机器扫描（广播闭环 / 死 Builder / 带参 Builder / 页面订阅 / 回调漏传 / 监听泄漏 / 列表 key）+ 行为测试 11 项 PASS；补失败提示、返回键优先级、浮层互斥
- 二次自检（v4.0.40）：自检扩到 12 类（新增加载态收口 / 系统任务释放 / 持久化窗口 / 自动路径计数），16 项 PASS 12 WARN 4 FAIL 0；反向注入 3 个 bug 全部检出；行为测试 33 项 PASS
- 移除握姿（v4.0.41）：全源码 `grep -i grip` 零命中；包内 `Grip` / `gripSide` / `v4_grip_mode` / `智感握姿` 均为 0；12 类自检 16 项 PASS 12 / WARN 4 / FAIL 0
- 续播与进度（v4.0.42）：行为测试 17 项 PASS（含 3 条修复前对照）；自检扩到 14 类 18 项 PASS 14 / WARN 4 / FAIL 0；反向注入 M、N 两类均能检出
- 本地删除（v4.0.43）：行为测试 19 项 PASS（勾选/全选/单删/批删/队列摘除/菜单条件）；自检 15 类 19 项 PASS 15 / WARN 4 / FAIL 0；反向注入「导入不复制副本」被 O 类检出
- 下载取消（v4.0.44）：行为测试 23 项 PASS（取消/中止/不误判成功/批量一次落盘/重试清痕迹）；自检 16 类 20 项 PASS 16 / WARN 4 / FAIL 0；反向注入旧 cancel 写法被 P 类检出
- 重复入口（v4.0.45）：逐页人工核对 + 静态统计（重复图标 / 重复文案 / 同一方法多处绑定 / 同一跳转出现多次），修 7 处；自检 17 类 21 项 PASS 17 / WARN 4 / FAIL 0；反向注入首页时钟图标被 Q 类检出
- 跨页入口（v4.0.46）：设置页删「保存目录」「下载管理」两项，下载入口收敛到音乐库卡片 + 首页图标；Q 类加「同一目标页 3 个以上入口」扫描，反向注入设置页入口即 WARN
- 单页下载入口（v4.0.47）：播放页菜单 `hideDownload`，底排按钮状态化；行为测试 19 项 PASS；Q 类加「单曲入队 + SongMenu 未屏蔽」扫描，反向删 `hideDownload` 即 WARN
- 下线倍速与定时（v4.0.48）：源码断言 12 项 PASS（无残留、顶栏单图标、队列在底排、面板无清空）；包内 `sleepPanel`/`speedPanel`/`定时关闭`/`播放速度`/`clearQueue` 全为 0；自检 17 类 21 项 PASS 17 / WARN 4 / FAIL 0
- 音源协议兼容升级：整合两批音源（本地 20 个 + 仓库 16 种）分析结论，修探测层误杀（headers 传入 + `unknown` 放行）、桥接层 `resp.body` 双兼容、音质档位动态化与别名归一化、补齐 `EVENT_NAMES`/`version`/`description`/`follow_max`；离线协议实验 A/B/C 全通过，HAP 内桥接页与新文案核验通过，自检 21 项 PASS 17 / WARN 4 / FAIL 0（详见 `docs/音源协议兼容分析（整合版）.md`）
- 运行时能力对齐（第三轮）：对齐安卓洛雪「默认 UA + 不二次验货 + 全源并发」——`LxRunner` 补 `lx-music-mobile/1.7.0` UA、8 种 method、`ARRAY_BUFFER`→base64；`lx_bridge.html` 的 `__emit` 遍历所有 handler 并在调用期隔离 `globalThis.lx`；`Resolver` 超时 6s→12s、按「音源+平台」健康度降权、首选连续失败自动补位、失败原因分诊；新增「下载前严格验音质」（默认关）与「首选连续失败时自动补位」（默认开）两个开关；`Downloader` 落盘后读文件头验真实格式并修正扩展名/实际音质。离线回归扩到 A~G 七组全部通过，`BUILD SUCCESSFUL`、验签通过、自检 PASS 17 / WARN 4 / FAIL 0（详见 `docs/音源协议兼容分析（整合版）.md` 第七章）
- 歌词排版对齐参考实现（第十一轮）：
  - **行距**：旧写法 `lineHeight = 字号 + 8` 再叠 9vp 上下 padding，19 号字一行实占 45vp（2.4 倍行距），整屏是一行行竖着散开的 —— 这是「看起来别扭」的最大来源。现在 `lyricLineHeight()` 统一按 `字号 × 1.34` 计算、上下 padding 降到 3，实际行距约 1.6 倍。
  - **字号**：四档基准 17/19/22/26 → 18/21/24/28；当前行只 +1 号（原 +2）、字重 Bold → Medium —— 中文 Bold 会让字形横向变宽，行宽一跳整块像在抖。
  - **层次**：新增 `lyricAlpha(index)` 按离当前行的距离分五档（1.0 / 0.74 / 0.56 / 0.42 / 0.30）。原来非当前行统一 0.84，几乎和当前行一样亮，等于每行都是主角、没有焦点。
  - **修掉一个真 bug**：全工程 17 处 `textShadow` 的颜色写成 `#B30000000`（九位十六进制），ArkUI 不认这个格式，阴影一直没生效。改成合法的 `#B3000000`；歌词处另用更轻的 `#80000000` + radius 6，避免字发虚。
  - `selfcheck.py` 新增 Y 组：`lyricAlpha` / `lyricLineHeight` 被删、行高退回「字号 + 固定值」、颜色不走距离衰减、全工程出现九位十六进制颜色，都会 FAIL。`BUILD SUCCESSFUL`、验签通过、自检 29 项 PASS 25 / WARN 4 / FAIL 0；反向注入两处当场检出（详见 `docs/歌词排版对比-图解.html`）
- 自检收口与本地导入（第十轮）：
  - **去掉「快速体检」**：它每源只试一首、超时 8 秒，结论不可靠——用户按体检结果留下源，点歌照样失败；而且和卡片上的「自检」是两套口径。现在只有单源「自检」和「全部自检」两条路径，`SourceRepo.check(id)` 删除 `quick` 参数，`checkAll(onProgress)` 不再有 `full` 开关，只有一个结论。为控制耗时补了「脚本级错误短路」：`isFatalCheck()` 命中「未注册处理器 / 未加载 / 初始化失败」时不再换平台重试，死源从 3×12s 降到 1×12s，`SourceItem.checkSkipped` 记录跳过数。
  - **自检结果只在卡片上收口**：`checkAll` 改为返回 `CheckSummary`（总数 / 可用 / 失败明细 / 时间 / 跳过数），供音源页手动自检的 toast 与日志使用。启动自检跑完**不弹窗**——它是后台任务，弹窗会打断正在听歌的用户；结果只回写到音源卡片的状态点与原因上。第一版曾用 `AppStorage` + `Index` 弹窗汇报，本轮按需求整段移除，`selfcheck.py` 反向守住（广播或弹窗任一处复活即 FAIL）。
  - **导入脚本 → 本地导入**：按钮、空态、提示文案统一为「本地导入」，一次最多选 20 个（原 4 个）。读取失败时不再笼统报「导入失败」，而是指出具体文件、失败原因，并提示「如果它在云盘请先下载到本机」——picker 能列出云盘文件，但脚本要落盘到沙箱，读不出来是最常见的失败原因。空文件也会单独提示。
  - `selfcheck.py`：V 组重写为「只有一套自检结论 + 启动自检静默收口」，新增 X 组（本地导入文案、系统选择器、云盘提示、批量上限）；A 组补上 `AppStorage.get<T>('key')` 这种「只取值不订阅」的读法。`BUILD SUCCESSFUL`、验签通过、自检 28 项 PASS 24 / WARN 4 / FAIL 0；反向注入（把 `publishCheckReport` 挂回启动自检、把文案改回「导入脚本」）两组当场检出（详见 `docs/自检收口与本地导入-图解.html`）
- 左滑删除音源（第九轮）：音源列表从 `Scroll + Column` 改成 `List + ListItem`，每张卡片挂 `swipeAction({ end: ... })`，左滑露出 76vp 的红色「删除」，点击弹确认后再 `repo.remove()`；菜单里的「删除音源」单点入口移除（两个入口并存时，用户还是会走更容易误触的那个）。选择模式下 `swipeDelete` 返回 0 宽，避免横向手势与多选冲突、也避免挑导出源时误删。页面提示补「左滑卡片可删除」。`selfcheck.py` 新增 W 组：`.swipeAction(` 消失、缺确认弹窗、菜单删除项回来、列表退回 Scroll+Column，都会 FAIL。`BUILD SUCCESSFUL`、验签通过、自检 27 项 PASS 23 / WARN 4 / FAIL 0；反向把手势改名后 W 组当场检出（详见 `docs/音源左滑删除-图解.html`）
- 自检体系（第八轮）：保留原有的单源「自检」（逐平台试三首基准曲），新增两条批量路径 ——「快速体检」每源只试一首、超时 8 秒，用来回答「哪几个源还活着」；「全部自检」对每个源跑完整自检，结论和卡片上的单源自检一致。`SourceRepo.checkAll(onProgress, full)` 用 `full` 区分两种模式（并发 3 / 2），页面两个按钮并排，进度与完成提示都带模式名。新增「启动时自动自检」开关（默认关）：`App.maybeAutoCheck()` 在音源加载完成后延迟 8 秒跑一轮**快速体检**，同一进程只跑一次、距上次不足 30 分钟跳过（`v4_auto_check_at`）—— 自检是真实取链，默认关是为了不让它替用户天天打后端。`selfcheck.py` 新增 V 组：`checkAll` 不传 `full`、少一种批量入口、单源自检被删、启动自检不读开关或没有节流，都会 FAIL。`BUILD SUCCESSFUL`、验签通过、自检 26 项 PASS 22 / WARN 4 / FAIL 0；反向注入（把 `!full` 改成 `true`、去掉开关判断）两条同时被检出（详见 `docs/自检体系-图解.html`）
- 失败面板与歌→源亲和（第七轮 P1）：
  - **失败面板**：以前失败原因是一行拼接长串，播放页只能 `maxLines(1)` 截断，用户既不知道装的那十几个源里谁还活着，也不知道下一步能干什么。现在 `Resolver` 在每次取链失败时留一份完整凭据（`lastNotes` / `getLastFailure()`），`Player.retryWithAnotherSource()` 先消费备用链接池、池空才重新取链，播放页顶栏的错误行变成可点入口，`panel === 7` 用面板逐条列出「音源名 + 各自失败原因」，首选标徽标，底部两个按钮是「换个音源再试（还有 N 条）」和「播放下一首」。凭据为空时（resolve 成功、播放器才失败）才显示「链接取到了、是播放阶段失败」，不会误判。
  - **歌 → 源亲和**：`Resolver` 新增持久化的 `Map<歌id@平台, sourceId>`（`v4_source_affinity`，上限 500 条、按时间淘汰、`putLater` 合写），取链成功时记下是哪个源给的，排序时在同一健康度下把该源提前。它只改「先问谁」，不排斥其它源；渠道失败照样进健康度惩罚，所以不会把坏源钉死。`Settings.rememberSource()` 默认开，音源页新增开关可关；Store 未就绪时不缓存空表，避免整进程学不到东西。
  - `selfcheck.py` 新增 T / U 两组：面板被拆、面板没接进分发、手动换源不走备用池、亲和表没有上限、亲和写入不读开关，都会 FAIL。`BUILD SUCCESSFUL`、验签通过、自检 25 项 PASS 21 / WARN 4 / FAIL 0；反向注入（把 `panel === 7` 改掉、去掉亲和开关判断）两组当场检出（详见 `docs/失败面板与音源亲和-图解.html`）
- 启动并发与批量体检（第六轮 P0）：`SourceRepo.loadAll` 不再「注入一个源就等它 6 秒 inited」——注入保持串行（单 WebView 里 `window.lx` 是单值，并发注入会让脚本的异步初始化回调读到别的实例），但等待改成并发计时，冷启动从「Σ 每个慢源的超时」降为「注入总和 + 最慢一个」，装十几个源时不再要等一两分钟才敢点播放。新增 `SourceRepo.checkAll()` 与音源页「全部体检」：并发 3 个源、每源只试第一首匹配平台、超时 8 秒，跑完给出「可用 X / 失败 Y」，列表里逐个显示状态与原因。`selfcheck.py` 新增 S 组：`loadAll` 里再出现 `await this.loadOne(` 直接 FAIL。`BUILD SUCCESSFUL`、验签通过、自检 23 项 PASS 19 / WARN 4 / FAIL 0；反向把串行写法注回去，S 组当场检出（详见 `docs/启动并发与音源体检-图解.html`）
- 音源就绪门禁（第五轮）：对齐官方「inited 才算就绪」——`LxRunner` 拆出 `loaded` / `inited` 两个状态，新增 `loadedAgo()`、`waitInited()`、`resetSandbox()` 与整页 `__reset()`；`Resolver.trySources` 只把已 inited 的音源当候选，未就绪但在 45s 宽限内的先等最多 8s（独家音源要等 rconfig，此前必然抢跑成「未注册 request 处理器」）；音质档位不再筛源、改为降权排序；取链超时 12s→18s；`fetchFromSource` 拆出 `fetchOnce` 并在「未注册处理器 / 音源未加载 / 调用失败」时重建该源重试一次。同时修掉第三轮引入的回归：`kuwoDirect` 兜底直连先按接口 `duration` 判试听（差 10 秒以上即拒），探测判出「试听片段」时硬拒绝，只有 403 / 超时这类判断不了的失败才继续信任 —— 11 秒提示音不会再被当整首播。`SourceRepo` 新增 `reload(id)` / `reloadAll()`，自检前未就绪则先重建；音源页统计改为「已启用 / 已加载 / 已就绪」，有未就绪源时出现「重建」按钮；`selfcheck.py` 新增 R 组守住这两条。`BUILD SUCCESSFUL`、验签通过、自检 22 项 PASS 18 / WARN 4 / FAIL 0，反向注入试听拦截缺失被 R 组检出（详见 `docs/音源就绪门禁与试听拦截-图解.html`）
- 多源真正参与（第四轮）：修「装了十几个源却只试一个」——`Resolver` 新增备用链接池（所有音源给的链接都留一份、`takeAlternative()` 供失败换链、失败链接清缓存并降权）、`isFatalProbe()` 淘汰 4xx/5xx/HTML/试听片段等明确坏链接（单源时 lenient 不误杀）、失败提示标注「共 N 个音源参与取链」；`Player.handleFail()` 在 AVPlayer prepare 失败时自动换源重试（上限 3 次，顶部显示「· 换源 1/3」）；音源页新增「已启用 X 个 · 已加载 Y 个」统计。离线回归扩到 A~H 八组全部通过（H 组直接抽取 `offerAlternate`/`takeAlternative`/`isFatalProbe` 真实实现执行），`BUILD SUCCESSFUL`、验签通过、自检 PASS 17 / WARN 4 / FAIL 0（详见 `docs/音源协议兼容分析（整合版）.md` 第八章）
